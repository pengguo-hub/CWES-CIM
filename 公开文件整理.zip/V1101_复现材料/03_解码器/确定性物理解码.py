"""Loss-aware deterministic decoder for binary QUBO ESS modes."""

from __future__ import annotations

import math

import numpy as np


def _sent_for_delivery(delivery_kw: float, loss_factor: float) -> float:
    """Small root of delivery = sent - loss_factor * sent**2."""
    delivery_kw = max(0.0, float(delivery_kw))
    if loss_factor <= 1e-15:
        return delivery_kw
    discriminant = max(0.0, 1.0 - 4.0 * loss_factor * delivery_kw)
    return (1.0 - math.sqrt(discriminant)) / (2.0 * loss_factor)


def calculate_transfer_result_physical(config, partition, graph):
    """Decode a QUBO partition with nearest-first, voltage-safe power flows.

    Receiving-side demand is reduced by delivered power (sent power minus I2R
    loss), and ESS discharge losses are included.  This makes the reported
    power-balance equation close to zero.
    """
    voltage_v = float(config.V0) * 1000.0
    physical_min_voltage_v = float(config.V_min) * 1000.0
    dispatch_loss_weight = float(getattr(config, "dispatch_loss_weight", 7.5))
    # For objective grid + waste + w*loss, transfer remains economical while
    # marginal I2R loss is below 2/(w+1), equivalent to limiting the edge
    # voltage-drop fraction to 1/(w+1).
    economic_min_voltage_v = (
        voltage_v * dispatch_loss_weight / (dispatch_loss_weight + 1.0)
        if dispatch_loss_weight > 0.0
        else 0.0
    )
    min_voltage_v = max(physical_min_voltage_v, economic_min_voltage_v)
    ampacity_cap_kw = voltage_v * float(config.I_max)

    brake_nodes = [i for i, kind in enumerate(config.node_types) if kind == 0]
    traction_nodes = [i for i, kind in enumerate(config.node_types) if kind == 1]
    ess_nodes = [i for i, kind in enumerate(config.node_types) if kind == 2]
    ess_index = {node: index for index, node in enumerate(ess_nodes)}

    brake_remaining = {node: max(float(config.P[node]), 0.0) for node in brake_nodes}
    traction_remaining = {node: abs(min(float(config.P[node]), 0.0)) for node in traction_nodes}
    brake_power = sum(brake_remaining.values())
    traction_power = sum(traction_remaining.values())

    room_kwh = np.maximum(0.0, (config.SOC_max - config.SOC_ess) * config.ess_capacity_kWh)
    energy_kwh = np.maximum(0.0, (config.SOC_ess - config.SOC_min) * config.ess_capacity_kWh)
    charge_limit = np.minimum(
        config.P_s_max_ch, room_kwh * 3600.0 / config.dt / config.eta_c
    )
    discharge_limit = np.minimum(
        config.P_s_max_dis, energy_kwh * 3600.0 * config.eta_d / config.dt
    )

    line_loss = 0.0
    transfer_power = 0.0
    direct_sent = 0.0
    absorbed_direct = 0.0
    absorbed_ess = 0.0
    lowest_receiving_voltage = voltage_v
    ess_charge = np.zeros(len(ess_nodes), dtype=float)
    ess_discharge = np.zeros(len(ess_nodes), dtype=float)

    def edge_parameters(source, sink):
        distance = float(config.distance_matrix[source][sink])
        resistance = float(config.Z_unit) * distance
        loss_factor = 1000.0 * resistance / voltage_v**2
        voltage_cap = (
            voltage_v * (voltage_v - min_voltage_v) / resistance / 1000.0
            if resistance > 1e-12
            else float("inf")
        )
        return resistance, loss_factor, min(ampacity_cap_kw, voltage_cap)

    def transfer(
        source_remaining,
        sink_remaining,
        candidates,
        use_graph_weights=True,
    ):
        nonlocal line_loss, lowest_receiving_voltage
        flows = []
        def edge_order(pair):
            source, sink = pair
            distance = float(config.distance_matrix[source][sink])
            if not use_graph_weights:
                return (distance, distance, 0.0)
            weight = float(graph[source][sink].get("weight", 0.0))
            return (distance / max(weight, 1e-12), distance, -weight)

        ordered = sorted(candidates, key=edge_order)
        for source, sink in ordered:
            available = max(0.0, float(source_remaining.get(source, 0.0)))
            demand = max(0.0, float(sink_remaining.get(sink, 0.0)))
            if available <= 1e-12 or demand <= 1e-12:
                continue
            resistance, loss_factor, safe_cap = edge_parameters(source, sink)
            sent = min(available, safe_cap, _sent_for_delivery(demand, loss_factor))
            loss = loss_factor * sent**2
            delivered = max(0.0, sent - loss)
            if sent <= 1e-12 or delivered <= 1e-12:
                continue
            source_remaining[source] -= sent
            sink_remaining[sink] -= delivered
            receiving_voltage = voltage_v - sent * 1000.0 / voltage_v * resistance
            lowest_receiving_voltage = min(lowest_receiving_voltage, receiving_voltage)
            line_loss += loss
            flows.append((source, sink, sent, delivered, loss))
        return flows

    direct_pair_mode = str(
        getattr(config, "direct_pair_mode", "graph")
    ).strip().lower()
    if direct_pair_mode not in {"graph", "all_physical"}:
        raise ValueError("direct_pair_mode must be 'graph' or 'all_physical'")
    bt_candidates = [
        (b, t) for b in brake_nodes for t in traction_nodes
        if partition[b] != partition[t]
        and (direct_pair_mode == "all_physical" or graph.has_edge(b, t))
    ]
    direct_flows = transfer(
        brake_remaining,
        traction_remaining,
        bt_candidates,
        use_graph_weights=direct_pair_mode == "graph",
    )
    for _, _, sent, delivered, _ in direct_flows:
        direct_sent += sent
        transfer_power += sent
        absorbed_direct += delivered

    charge_remaining = {
        node: float(charge_limit[ess_index[node]])
        for node in ess_nodes if int(partition[node]) == 0
    }
    bs_candidates = [
        (b, s) for b in brake_nodes for s in charge_remaining
        if partition[b] != partition[s] and graph.has_edge(b, s)
    ]
    charge_flows = transfer(brake_remaining, charge_remaining, bs_candidates)
    for _, node, sent, delivered, _ in charge_flows:
        index = ess_index[node]
        ess_charge[index] += delivered
        transfer_power += sent
        absorbed_ess += delivered * float(config.eta_c)

    discharge_remaining = {
        node: float(discharge_limit[ess_index[node]])
        for node in ess_nodes if int(partition[node]) == 1
    }
    st_candidates = [
        (s, t) for s in discharge_remaining for t in traction_nodes
        if partition[s] != partition[t] and graph.has_edge(s, t)
    ]
    discharge_flows = transfer(discharge_remaining, traction_remaining, st_candidates)
    for node, _, sent, _, _ in discharge_flows:
        ess_discharge[ess_index[node]] += sent

    direct_line_loss = sum(flow[4] for flow in direct_flows)
    charge_line_loss = sum(flow[4] for flow in charge_flows)
    discharge_line_loss = sum(flow[4] for flow in discharge_flows)
    absorbed_power = absorbed_direct + absorbed_ess
    return {
        "brake_power": brake_power,
        "traction_power": traction_power,
        "p_direct_power": direct_sent,
        "transfer_power": transfer_power,
        "direct_line_loss": direct_line_loss,
        "charge_line_loss": charge_line_loss,
        "discharge_line_loss": discharge_line_loss,
        "line_loss": line_loss,
        "absorbed_power": absorbed_power,
        "discarded_power": max(sum(brake_remaining.values()), 0.0),
        "grid_power": max(sum(traction_remaining.values()), 0.0),
        "ess_charge_power": ess_charge,
        "ess_discharge_power": ess_discharge,
        "absorption_rate": float(np.clip(absorbed_power / brake_power, 0.0, 1.0)) if brake_power > 1e-12 else 0.0,
        "min_voltage_V": lowest_receiving_voltage,
    }
