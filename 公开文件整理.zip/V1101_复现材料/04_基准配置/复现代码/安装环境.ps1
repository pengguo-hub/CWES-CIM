param(
    [switch]$Quantum
)

$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPath = Join-Path $PackageRoot '.venv'
$PythonPath = Join-Path $VenvPath 'Scripts\python.exe'

if (-not (Test-Path -LiteralPath $PythonPath)) {
    python -m venv $VenvPath
}

& $PythonPath -m pip install --upgrade pip
& $PythonPath -m pip install -r (Join-Path $PackageRoot 'requirements-classical.txt')

if ($Quantum) {
    & $PythonPath -m pip install -r (Join-Path $PackageRoot 'requirements-quantum.txt')
    Write-Host '请再按QBoson账户提供的官方方式安装kaiwu SDK。'
}

Write-Host "环境完成：$PythonPath"
