"""Dynamic MAX-CUT k-flip search adapted to the shared 10ESS graph."""

import itertools
import os
import shutil
import sys
import time
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
ROOT = BASE_DIR.parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import ESS_POSITIONS, NUM_BRAKE, NUM_ESS, NUM_TRACTION, SOC_INIT, CASE_FILES, RESULT_ROOT
from data_loader import build_input_t, load_case_data
from edge_builder import build_edges, build_nodes, cut_value
from evaluation import calculate_summary
from reporting import plot_standard_results, save_tabular_outputs
from runtime import (
    allocate_power, charge_limits, discharge_limits, finalize_step, location_scores,
)

# =========================
# Case selection — change CASE_NAME to run different scenarios:
#   "Case1"  "Case2"  "Case3"  "Case4"
# =========================
DEFAULT_CASE_NAME = "Case1"

INPUT_FILE = (
    Path(sys.argv[1]) if len(sys.argv) > 1
    else ROOT / "data" / CASE_FILES[DEFAULT_CASE_NAME]
)
CASE_NAME = os.environ.get("BENCHMARK_CASE_KEY") or next(
    (
        case_key
        for case_key, filename in CASE_FILES.items()
        if Path(filename).name == INPUT_FILE.name
    ),
    INPUT_FILE.stem,
)
OUTPUT_DIR = ROOT / RESULT_ROOT / CASE_NAME / "k_flip"
EXCEL_DIR = OUTPUT_DIR / "excel_result"
FIG_DIR = OUTPUT_DIR / "figure"
TXT_DIR = OUTPUT_DIR / "txt"
for directory in (EXCEL_DIR, FIG_DIR, TXT_DIR):
    directory.mkdir(parents=True, exist_ok=True)
ESS_OFFSET = NUM_BRAKE + NUM_TRACTION
LOSS_WEIGHT = 1.0


def initial_partition(input_t):
    charging = sum(input_t["brake_power"]) >= sum(input_t["traction_power"])
    return [0] * NUM_BRAKE + [1] * NUM_TRACTION + [1 if charging else 0] * NUM_ESS


def repair_partition(partition):
    fixed = list(partition)
    fixed[:NUM_BRAKE] = [0] * NUM_BRAKE
    fixed[NUM_BRAKE:ESS_OFFSET] = [1] * NUM_TRACTION
    return fixed


def dispatch_for_partition(input_t, partition):
    surplus = max(0.0, sum(input_t["brake_power"]) - sum(input_t["traction_power"]))
    deficit = max(0.0, sum(input_t["traction_power"]) - sum(input_t["brake_power"]))
    charge = [0.0] * NUM_ESS
    discharge = [0.0] * NUM_ESS
    if surplus > 0:
        limits = charge_limits(input_t["soc"])
        allowed = [limits[i] if partition[ESS_OFFSET + i] == 1 else 0.0 for i in range(NUM_ESS)]
        scores = location_scores(ESS_POSITIONS, input_t["brake_position"], input_t["brake_power"])
        charge = allocate_power(surplus, allowed, scores)
    elif deficit > 0:
        limits = discharge_limits(input_t["soc"])
        allowed = [limits[i] if partition[ESS_OFFSET + i] == 0 else 0.0 for i in range(NUM_ESS)]
        scores = location_scores(ESS_POSITIONS, input_t["traction_position"], input_t["traction_power"])
        discharge = allocate_power(deficit, allowed, scores)
    return charge, discharge


def partition_objective(input_t, nodes, edges, partition):
    charge, discharge = dispatch_for_partition(input_t, partition)
    result, _, _ = finalize_step(input_t, charge, discharge, 0.0)
    return cut_value(partition, edges) - LOSS_WEIGHT * result["loss_kW"]


def k_flip_local_search(input_t, nodes, edges, x0, k=1, max_iter=20):
    free_nodes = list(range(ESS_OFFSET, ESS_OFFSET + NUM_ESS))
    current = repair_partition(x0)
    current_value = partition_objective(input_t, nodes, edges, current)
    for _ in range(max_iter):
        best = current
        best_value = current_value
        for flip_count in range(1, min(k, len(free_nodes)) + 1):
            for flip_set in itertools.combinations(free_nodes, flip_count):
                candidate = current.copy()
                for index in flip_set:
                    candidate[index] = 1 - candidate[index]
                candidate = repair_partition(candidate)
                value = partition_objective(input_t, nodes, edges, candidate)
                if value > best_value + 1e-9:
                    best, best_value = candidate, value
        if best_value <= current_value + 1e-9:
            break
        current, current_value = best, best_value
    return current, current_value


def run_dynamic_simulation(case_file=None, k=1):
    condition = load_case_data(case_file or INPUT_FILE)
    soc = [SOC_INIT] * NUM_ESS
    previous = None
    records = []
    total_start = time.perf_counter()
    for _, row in condition.iterrows():
        input_t = build_input_t(row, soc)
        nodes = build_nodes(input_t)
        edges = build_edges(nodes)
        x0 = initial_partition(input_t) if previous is None else repair_partition(previous)
        step_start = time.perf_counter()
        partition, objective = k_flip_local_search(input_t, nodes, edges, x0, k=k)
        charge, discharge = dispatch_for_partition(input_t, partition)
        solve_ms = (time.perf_counter() - step_start) * 1000.0
        extras = {
            "partition": "".join(str(bit) for bit in partition),
            "best_objective": objective,
            "best_cut": cut_value(partition, edges),
        }
        result, soc, _ = finalize_step(input_t, charge, discharge, solve_ms, extras)
        records.append(result)
        previous = partition
    return pd.DataFrame(records), time.perf_counter() - total_start


def plot_and_save(result_df):
    plot_standard_results(result_df, FIG_DIR)
    aliases = {
        "Power_Dispatch.png": "Power.png",
        "Cumulative_Energy.png": "Energy.png",
    }
    for source, target in aliases.items():
        shutil.copyfile(FIG_DIR / source, FIG_DIR / target)


def main():
    print(f"工况文件: {INPUT_FILE}")
    print(f"输出目录: {OUTPUT_DIR}")
    result_df, total_runtime = run_dynamic_simulation(k=1)
    summary_df = calculate_summary(result_df, total_runtime, "k-flip动态最大割局部搜索")
    save_tabular_outputs(result_df, summary_df, EXCEL_DIR, TXT_DIR, "k-flip 10ESS统一评价结果")
    plot_and_save(result_df)
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
