
import os
import shutil
import sys
import time
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
ROOT = BASE_DIR.parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import ESS_POSITIONS, NUM_ESS, SOC_INIT, SOC_MAX, SOC_MIN, CASE_FILES, RESULT_ROOT
from data_loader import build_input_t, load_case_data
from evaluation import calculate_summary
from reporting import plot_standard_results, save_tabular_outputs
from runtime import allocate_power, charge_limits, discharge_limits, finalize_step, location_scores

# =========================
# Case selection — change CASE_NAME to run different scenarios:
#   "Case1"  "Case2"  "Case3"  "Case4"
# =========================
DEFAULT_CASE_NAME = "Case1"

INPUT_FILE = (
    Path(sys.argv[1]) if len(sys.argv) > 1
    else ROOT / "data" / CASE_FILES[DEFAULT_CASE_NAME]
)
CASE_NAME = os.environ.get("BENCHMARK_CASE_KEY") or next(
    (
        case_key
        for case_key, filename in CASE_FILES.items()
        if Path(filename).name == INPUT_FILE.name
    ),
    INPUT_FILE.stem,
)
OUTPUT_DIR = ROOT / RESULT_ROOT / CASE_NAME / "Gao2015"
EXCEL_DIR = OUTPUT_DIR / "excel_result"
FIG_DIR = OUTPUT_DIR / "figure"
TXT_DIR = OUTPUT_DIR / "txt"
for directory in (EXCEL_DIR, FIG_DIR, TXT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

U_REF = 1500.0
U_CH_TRIGGER = 1650.0
U_DIS_TRIGGER = 1350.0
SOC_CH_REDUCE = 0.80
SOC_DIS_REDUCE = 0.40


def estimate_dc_voltage(brake_power, traction_power):
    base = max(brake_power, traction_power, 1.0)
    return max(1100.0, min(1900.0, U_REF + 300.0 * (brake_power - traction_power) / base))


def charge_factor(soc):
    if soc >= SOC_MAX:
        return 0.0
    if soc <= SOC_CH_REDUCE:
        return 1.0
    return (SOC_MAX - soc) / (SOC_MAX - SOC_CH_REDUCE)


def discharge_factor(soc):
    if soc <= SOC_MIN:
        return 0.0
    if soc >= SOC_DIS_REDUCE:
        return 1.0
    return (soc - SOC_MIN) / (SOC_DIS_REDUCE - SOC_MIN)


def gao_dispatch(input_t):
    start = time.perf_counter()
    brake = sum(input_t["brake_power"])
    traction = sum(input_t["traction_power"])
    surplus = max(0.0, brake - traction)
    deficit = max(0.0, traction - brake)
    voltage = estimate_dc_voltage(brake, traction)
    charge = [0.0] * NUM_ESS
    discharge = [0.0] * NUM_ESS
    mode = "standby"

    if surplus > 0 and voltage >= U_CH_TRIGGER:
        mode = "charge"
        limits = [limit * charge_factor(soc) for limit, soc in zip(charge_limits(input_t["soc"]), input_t["soc"])]
        scores = location_scores(ESS_POSITIONS, input_t["brake_position"], input_t["brake_power"])
        scores = [score * max(0.0, SOC_MAX - soc) for score, soc in zip(scores, input_t["soc"])]
        charge = allocate_power(surplus, limits, scores)
    elif deficit > 0 and voltage <= U_DIS_TRIGGER:
        mode = "discharge"
        limits = [limit * discharge_factor(soc) for limit, soc in zip(discharge_limits(input_t["soc"]), input_t["soc"])]
        scores = location_scores(ESS_POSITIONS, input_t["traction_position"], input_t["traction_power"])
        scores = [score * max(0.0, soc - SOC_MIN) for score, soc in zip(scores, input_t["soc"])]
        discharge = allocate_power(deficit, limits, scores)

    solve_ms = (time.perf_counter() - start) * 1000.0
    return charge, discharge, solve_ms, {"control_mode": mode, "estimated_bus_voltage_V": voltage}


def run_gao2015_voltage_soc_control(case_file=None):
    condition = load_case_data(case_file or INPUT_FILE)
    soc = [SOC_INIT] * NUM_ESS
    records = []
    total_start = time.perf_counter()
    for _, row in condition.iterrows():
        input_t = build_input_t(row, soc)
        charge, discharge, solve_ms, extras = gao_dispatch(input_t)
        result, soc, _ = finalize_step(input_t, charge, discharge, solve_ms, extras)
        records.append(result)
    return pd.DataFrame(records), time.perf_counter() - total_start


def plot_and_save(result_df):
    plot_standard_results(result_df, FIG_DIR, voltage_column="estimated_bus_voltage_V")
    aliases = {
        "Power_Dispatch.png": "Power.png",
        "Cumulative_Energy.png": "Energy.png",
        "Estimated_DC_Voltage.png": "Voltage.png",
    }
    for source, target in aliases.items():
        shutil.copyfile(FIG_DIR / source, FIG_DIR / target)


def main():
    print(f"工况文件: {INPUT_FILE}")
    print(f"输出目录: {OUTPUT_DIR}")
    result_df, total_runtime = run_gao2015_voltage_soc_control()
    summary_df = calculate_summary(result_df, total_runtime, "Gao2015_电压_SOC规则控制")
    save_tabular_outputs(result_df, summary_df, EXCEL_DIR, TXT_DIR, "Gao2015 10ESS统一评价结果")
    plot_and_save(result_df)
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
