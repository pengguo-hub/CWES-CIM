"""Run and compare all benchmark methods on all 150-second 10ESS cases (Case1-Case4)."""

import subprocess
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import CASE_FILES, RESULT_ROOT
from reporting import style_workbook

CASE_NAMES = list(CASE_FILES.keys())

METHODS = {
    "Ground_SC": ROOT / "Ground_SC_Control" / "ground.sc.py",
    "k_flip": ROOT / "k_flip" / "k-flip.py",
    "MILP": ROOT / "MILP" / "MILP.py",
    "Gao2015": ROOT / "Gao2015_Voltage_SOC" / "gao2015.py",
    "Genetic_Algorithm": ROOT / "Genetic_Algorithm" / "genetic_algorithm.py",
}
COMPARE_DIR = ROOT / "Unified_Comparison"


def selected_cases(pattern=None):
    cases = CASE_NAMES if pattern is None else [c for c in CASE_NAMES if pattern.lower() in c.lower()]
    if not cases:
        raise ValueError(f"No case matches {pattern!r}")
    return cases


def data_files_for(case_names):
    return [ROOT / "data" / CASE_FILES[c] for c in case_names]


def run_one(method, case_file):
    script = METHODS[method]
    print(f"RUN {method}: {case_file.stem}", flush=True)
    completed = subprocess.run([sys.executable, str(script), str(case_file)], cwd=script.parent)
    if completed.returncode != 0:
        raise RuntimeError(f"{method} failed for {case_file.stem} (exit {completed.returncode})")


def run(methods, case_names):
    for method in methods:
        for case_file in data_files_for(case_names):
            run_one(method, case_file)


def collect():
    rows = []
    sheets = {}
    for case_name in CASE_NAMES:
        case_tables = {}
        for method in METHODS:
            path = ROOT / RESULT_ROOT / case_name / method / "excel_result" / "Summary_Result.xlsx"
            if not path.exists():
                continue
            summary = pd.read_excel(path)
            case_tables[method] = summary
            row = {"工况": case_name, "方法": method}
            row.update(dict(zip(summary["指标"], summary["数值"])))
            rows.append(row)
        if case_tables:
            metrics = next(iter(case_tables.values()))["指标"].tolist()
            table = pd.DataFrame({"指标": metrics})
            for method, summary in case_tables.items():
                table[method] = summary["数值"].tolist()
            sheets[case_name] = table
    return pd.DataFrame(rows), sheets


def compare():
    summary, sheets = collect()
    expected = len(METHODS) * len(CASE_NAMES)
    if len(summary) != expected:
        raise RuntimeError(f"Expected {expected} result sets, found {len(summary)}")
    COMPARE_DIR.mkdir(parents=True, exist_ok=True)
    summary.to_csv(COMPARE_DIR / "Summary_All.csv", index=False, encoding="utf-8-sig")

    case_col = "工况"
    method_col = "方法"
    rate_col = "再生消纳率"
    waste_col = "弃能"
    grid_col = "电网补能"
    rate_rank_col = "消纳率排名"
    average_rate_rank_col = "平均消纳率排名"
    core_metrics = [
        "总再生能量", "有效消纳能量", rate_col, waste_col, grid_col, "网损",
        "最终平均SOC", "总求解时间", "平均单步时间", "最大单步时间",
        "电压越限次数", "功率越限次数", "不可行步数",
    ]
    ranking = summary[[case_col, method_col, *core_metrics]].copy()
    ranking[rate_rank_col] = ranking.groupby(case_col)[rate_col].rank(
        method="min", ascending=False
    ).astype(int)
    ranking["弃能排名"] = ranking.groupby(case_col)[waste_col].rank(
        method="min", ascending=True
    ).astype(int)
    ranking["电网补能排名"] = ranking.groupby(case_col)[grid_col].rank(
        method="min", ascending=True
    ).astype(int)
    ranking.sort_values([case_col, rate_rank_col, method_col]).to_csv(
        COMPARE_DIR / "Ranking_By_Case.csv", index=False, encoding="utf-8-sig"
    )

    average = summary.groupby(method_col, as_index=False)[core_metrics].mean(numeric_only=True)
    average[average_rate_rank_col] = average[rate_col].rank(
        method="min", ascending=False
    ).astype(int)
    average.sort_values([average_rate_rank_col, method_col]).to_csv(
        COMPARE_DIR / "Average_By_Method.csv", index=False, encoding="utf-8-sig"
    )

    comparison_path = COMPARE_DIR / "Unified_Comparison.xlsx"
    with pd.ExcelWriter(comparison_path, engine="openpyxl") as writer:
        for case_name, table in sheets.items():
            table.to_excel(writer, sheet_name=case_name[:31], index=False)
    style_workbook(comparison_path)
    print(f"Comparison written to {COMPARE_DIR}")


def main():
    command = sys.argv[1].lower() if len(sys.argv) > 1 else "list"
    if command == "all":
        run(list(METHODS.keys()), CASE_NAMES)
        compare()
    elif command == "method":
        method = sys.argv[2]
        if method not in METHODS:
            raise ValueError(f"Unknown method {method}; choose {list(METHODS)}")
        run([method], selected_cases(sys.argv[3] if len(sys.argv) > 3 else None))
    elif command == "case":
        run(list(METHODS.keys()), selected_cases(sys.argv[2]))
    elif command == "compare":
        compare()
    elif command == "list":
        print("Methods:", ", ".join(METHODS))
        print("Cases:")
        for case_name in CASE_NAMES:
            print(" ", case_name, "->", CASE_FILES[case_name])
    else:
        raise ValueError("Use: all | method <name> [case] | case <pattern> | compare | list")


if __name__ == "__main__":
    main()
