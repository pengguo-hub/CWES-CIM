"""Run and summarize the 3x3 QUBO constraint-penalty cross experiment."""

import argparse
import os
from pathlib import Path
import subprocess
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
RESULT_ROOT = Path(
    os.environ.get(
        "REPRO_PENALTY_RESULT_ROOT",
        EXPERIMENT_ROOT / "results" / "penalty_sensitivity",
    )
).resolve()
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"

BALANCE_WEIGHTS = (0.00025, 0.001, 0.004)
SOC_DYNAMIC_WEIGHTS = (5.0, 20.0, 80.0)
BATCH_SIZE = 10


def value_tag(value):
    return f"{value:g}".replace(".", "p").replace("-", "m")


def experiment_key(balance_weight, soc_dynamic_weight):
    return (
        f"B{value_tag(balance_weight)}_"
        f"SOC{value_tag(soc_dynamic_weight)}"
    )


def result_file(case_key):
    return (
        RESULT_ROOT
        / case_key
        / "Quantum_QUBO"
        / f"TimeSeries_Result_10ESS_{BATCH_SIZE}sBatch.csv"
    )


def experiment_environment(case_key, balance_weight, soc_dynamic_weight):
    environment = os.environ.copy()
    environment.update(
        BENCHMARK_CASE_KEY=case_key,
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND="scip",
        ESS_ALLOW_LOCAL_QUBO_EXPERIMENT="1",
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        ESS_QUBO_BALANCE_WEIGHT=str(balance_weight),
        ESS_QUBO_SOC_DYNAMIC_WEIGHT=str(soc_dynamic_weight),
        ESS_QUBO_SCIP_TIME_LIMIT_S="20",
    )
    return environment


def run_one(balance_weight, soc_dynamic_weight, force=False):
    case_key = experiment_key(balance_weight, soc_dynamic_weight)
    output_file = result_file(case_key)
    if output_file.is_file() and not force:
        print(f"SKIP {case_key}: result already exists")
        return
    command = [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)]
    print(f"RUN {case_key}", flush=True)
    subprocess.run(
        command,
        cwd=QUANTUM_SCRIPT.parent,
        env=experiment_environment(
            case_key, balance_weight, soc_dynamic_weight
        ),
        check=True,
    )


def summarize_one(balance_weight, soc_dynamic_weight):
    case_key = experiment_key(balance_weight, soc_dynamic_weight)
    path = result_file(case_key)
    if not path.is_file():
        return None
    data = pd.read_csv(path)
    total_regen_kWh = data["brake_power_kW"].sum() / 3600.0
    effective_kWh = (
        data["p_direct_kW"].sum()
        + data["ess_charge_kW"].sum()
        - data["loss_kW"].sum()
    ) / 3600.0
    return {
        "experiment": case_key,
        "balance_weight": balance_weight,
        "soc_dynamic_weight": soc_dynamic_weight,
        "raw_balance_violation_steps": int(
            data["qubo_balance_violation"].astype(bool).sum()
        ),
        "raw_mean_abs_balance_error_kW": float(
            data["qubo_mode_balance_error_kW"].abs().mean()
        ),
        "raw_max_abs_balance_error_kW": float(
            data["qubo_mode_balance_error_kW"].abs().max()
        ),
        "raw_soc_violation_steps": int(
            data["qubo_soc_violation"].astype(bool).sum()
        ),
        "raw_substation_violation_steps": int(
            data["qubo_substation_violation"].astype(bool).sum()
        ),
        "postprocess_infeasible_steps": int(
            (~data["feasible"].astype(bool)).sum()
        ),
        "effective_absorbed_kWh": effective_kWh,
        "absorption_rate_percent": (
            effective_kWh / total_regen_kWh * 100.0
            if total_regen_kWh > 0
            else 0.0
        ),
        "wasted_energy_kWh": data["wasted_power_kW"].sum() / 3600.0,
        "grid_energy_kWh": data["grid_power_kW"].sum() / 3600.0,
        "line_loss_kWh": data["loss_kW"].sum() / 3600.0,
        "mean_qubo_objective": float(data["batch_qubo_value"].mean()),
        "total_solver_time_s": data["solve_time_ms"].sum() / 1000.0,
        "solver_optimal_batches": int(
            data.groupby("batch_id")["batch_solver_status"]
            .first()
            .str.lower()
            .eq("optimal")
            .sum()
        ),
    }


def collect():
    rows = [
        summary
        for balance_weight in BALANCE_WEIGHTS
        for soc_dynamic_weight in SOC_DYNAMIC_WEIGHTS
        if (
            summary := summarize_one(balance_weight, soc_dynamic_weight)
        ) is not None
    ]
    if not rows:
        raise RuntimeError("No sensitivity results are available")
    summary = pd.DataFrame(rows)
    summary["raw_constraint_violation_steps"] = (
        summary["raw_balance_violation_steps"]
        + summary["raw_soc_violation_steps"]
        + summary["raw_substation_violation_steps"]
    )
    summary = summary.sort_values(
        [
            "raw_constraint_violation_steps",
            "raw_mean_abs_balance_error_kW",
            "absorption_rate_percent",
            "wasted_energy_kWh",
        ],
        ascending=[True, True, False, True],
    ).reset_index(drop=True)
    summary["recommended"] = False
    summary.loc[0, "recommended"] = True
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    summary.to_csv(
        RESULT_ROOT / "Penalty_Sensitivity_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary.iloc[[0]].to_csv(
        RESULT_ROOT / "Recommended_Hyperparameters.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(summary.to_string(index=False))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("list", "run", "collect"))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.command == "list":
        for balance_weight in BALANCE_WEIGHTS:
            for soc_dynamic_weight in SOC_DYNAMIC_WEIGHTS:
                print(experiment_key(balance_weight, soc_dynamic_weight))
        return
    if args.command == "run":
        if not CASE_FILE.is_file():
            raise FileNotFoundError(
                f"Generate scale cases first: {CASE_FILE}"
            )
        for balance_weight in BALANCE_WEIGHTS:
            for soc_dynamic_weight in SOC_DYNAMIC_WEIGHTS:
                run_one(
                    balance_weight,
                    soc_dynamic_weight,
                    force=args.force,
                )
    collect()


if __name__ == "__main__":
    main()
