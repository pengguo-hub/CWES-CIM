"""Run the line-resistance sensitivity experiment without CIM submissions.

The fixed-policy stage reuses a saved CIM partition sequence.  The full local
stage solves the same QUBO with SCIP at each resistance.  Existing imports and
models are retained; resistance and output isolation are environment-backed.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
RESULTS_ROOT = EXPERIMENT_ROOT / "results"
RESULT_ROOT = RESULTS_ROOT / "line_resistance_sensitivity"
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"
SOURCE_DIR = (
    RESULTS_ROOT / "runtime_breakdown" / "RUNTIME_CIM" / "Quantum_QUBO"
)
SOURCE_FILE = SOURCE_DIR / "TimeSeries_Result_10ESS_10sBatch.csv"
LOCAL_BASE_DIR = (
    RESULTS_ROOT
    / "runtime_breakdown"
    / "RUNTIME_LOCAL_SCIP"
    / "Quantum_QUBO"
)
BATCH_SIZE = 10

LEVELS = {
    "M20": 0.1072,
    "M10": 0.1206,
    "BASE": 0.1340,
    "P10": 0.1474,
    "P20": 0.1608,
}


def local_case_key(level):
    return f"RESIST_LOCAL_{level}"


def local_dir(level):
    if level == "BASE":
        return LOCAL_BASE_DIR
    return RESULT_ROOT / local_case_key(level) / "Quantum_QUBO"


def local_result_file(level):
    return local_dir(level) / "TimeSeries_Result_10ESS_10sBatch.csv"


def replay_file(variant, level):
    return RESULT_ROOT / "fixed_policy" / variant / f"{level}_TimeSeries.csv"


def _snapshot_protected():
    snapshot = {}
    for path in sorted(RESULTS_ROOT.rglob("*")):
        if not path.is_file() or RESULT_ROOT in path.parents:
            continue
        snapshot[str(path.relative_to(RESULTS_ROOT))] = (
            path.stat().st_size,
            hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    return snapshot


def _assert_protected(before):
    after = _snapshot_protected()
    changed = sorted(
        path
        for path in set(before) | set(after)
        if before.get(path) != after.get(path)
    )
    if changed:
        raise RuntimeError("Protected result files changed: " + ", ".join(changed))


def validate():
    for path in (CASE_FILE, QUANTUM_SCRIPT, SOURCE_FILE, local_result_file("BASE")):
        if not path.exists():
            raise FileNotFoundError(path)
    if abs(float(os.environ.get("BENCHMARK_LINE_RESISTANCE_OHM_PER_KM", "0.134")) - 0.134) > 1e-12:
        raise RuntimeError("Validation must run with the default 0.134 ohm/km setting")
    source = pd.read_csv(SOURCE_FILE)
    if len(source) != 30 or source["batch_id"].nunique() != 3:
        raise RuntimeError("The reusable CIM source must contain 30 steps and 3 batches")
    print("Resistance semantics: ohm/km; total edge R = resistance_per_km * distance_km")
    print("Levels: " + ", ".join(f"{key}={value:.4f}" for key, value in LEVELS.items()))
    print("Fixed-policy stage: 0 platform submissions")
    print("Full local SCIP stage: 0 platform submissions; BASE is reused")


def _load_quantum_module():
    os.environ["ESS_USE_QUANTUM_INTERFACE"] = "0"
    os.environ["ESS_QUANTUM_SOLVER_BACKEND"] = "scip"
    os.environ["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
    os.environ.setdefault("BENCHMARK_NUM_BRAKE", "3")
    os.environ.setdefault("BENCHMARK_NUM_TRACTION", "3")
    os.environ.setdefault("BENCHMARK_NUM_ESS", "10")
    os.environ.setdefault("BENCHMARK_SIM_TIME", "30")
    os.environ.setdefault("ESS_QUBO_BATCH_SIZE", "10")
    quantum_dir = ROOT / "Quantum_QUBO"
    sys.path.insert(0, str(quantum_dir))
    saved_argv = sys.argv[:]
    try:
        sys.argv = [sys.argv[0]]
        import quantum_10ess as quantum
    finally:
        sys.argv = saved_argv
    return quantum


def _partition(raw):
    return [int(value) for value in ast.literal_eval(str(raw))]


def _nearest_action_distance(case_row, charge, discharge):
    ess_positions = np.linspace(1.0, 30.0, len(charge))
    brake_positions = np.asarray(
        [case_row[f"brake_train_{i}_pos_km"] for i in range(1, 4)], dtype=float
    )
    brake_power = np.asarray(
        [case_row[f"brake_train_{i}_kW"] for i in range(1, 4)], dtype=float
    )
    traction_positions = np.asarray(
        [case_row[f"traction_train_{i}_pos_km"] for i in range(1, 4)], dtype=float
    )
    traction_power = np.asarray(
        [case_row[f"traction_train_{i}_kW"] for i in range(1, 4)], dtype=float
    )
    active_brake = brake_positions[brake_power > 1e-9]
    active_traction = traction_positions[traction_power > 1e-9]
    numerator = 0.0
    denominator = 0.0
    for position, power in zip(ess_positions, charge):
        if power > 1e-9 and len(active_brake):
            numerator += float(power) * float(np.min(np.abs(active_brake - position)))
            denominator += float(power)
    for position, power in zip(ess_positions, discharge):
        if power > 1e-9 and len(active_traction):
            numerator += float(power) * float(np.min(np.abs(active_traction - position)))
            denominator += float(power)
    return numerator / denominator if denominator > 0.0 else 0.0


def replay_one(level, resistance):
    configured = float(os.environ["BENCHMARK_LINE_RESISTANCE_OHM_PER_KM"])
    if abs(configured - resistance) > 1e-12:
        raise RuntimeError("Worker resistance/environment mismatch")
    quantum = _load_quantum_module()
    case = quantum.load_benchmark_case(CASE_FILE)
    source = pd.read_csv(SOURCE_FILE)
    outputs = {"frozen_dispatch": [], "fixed_cim_modes": []}
    configs = {
        name: quantum.LocalMaxCutConfig()
        for name in outputs
    }
    for name, config in configs.items():
        config.dispatch_decoder_mode = "soft"
        config.dispatch_qubo_priority_boost = 0.05
    for (_, case_row), (_, source_row) in zip(case.iterrows(), source.iterrows()):
        partition = _partition(source_row["partition"])
        for variant, config in configs.items():
            input_t = quantum.build_input_t(case_row, config.SOC_ess)
            quantum.update_config_from_case1_row(config, case_row)
            if variant == "fixed_cim_modes":
                transfer, next_soc = quantum.calculate_transfer_result_shared(
                    config, partition, input_t, 0.0
                )
                charge = np.asarray(transfer["ess_charge_power"], dtype=float)
                discharge = np.asarray(transfer["ess_discharge_power"], dtype=float)
            else:
                requested_charge = np.asarray(
                    [source_row[f"ess{i}_charge_kW"] for i in range(1, 11)],
                    dtype=float,
                )
                requested_discharge = np.asarray(
                    [source_row[f"ess{i}_discharge_kW"] for i in range(1, 11)],
                    dtype=float,
                )
                step, next_soc, _ = quantum.finalize_shared_step(
                    input_t,
                    requested_charge.tolist(),
                    requested_discharge.tolist(),
                    0.0,
                )
                charge = np.asarray(
                    [step[f"ESS{i}_charge_kW"] for i in range(1, 11)], dtype=float
                )
                discharge = np.asarray(
                    [step[f"ESS{i}_discharge_kW"] for i in range(1, 11)], dtype=float
                )
                transfer = {
                    "brake_power": step["brake_power_kW"],
                    "traction_power": step["traction_power_kW"],
                    "p_direct_power": step["p_direct_kW"],
                    "absorbed_power": step["absorbed_brake_power_kW"],
                    "discarded_power": step["wasted_power_kW"],
                    "grid_power": step["grid_power_kW"],
                    "line_loss": step["loss_kW"],
                    "min_voltage_V": step["min_voltage_V"],
                }
            raw_next_soc = np.asarray(next_soc, dtype=float)
            soc_violation = bool(
                np.any(raw_next_soc < config.SOC_min - 1e-9)
                or np.any(raw_next_soc > config.SOC_max + 1e-9)
            )
            config.SOC_ess = np.clip(raw_next_soc, config.SOC_min, config.SOC_max)
            balance_error = (
                float(transfer["brake_power"])
                + float(np.sum(discharge))
                + float(transfer["grid_power"])
                - float(transfer["traction_power"])
                - float(np.sum(charge))
                - float(transfer["discarded_power"])
                - float(transfer["line_loss"])
            )
            record = {
                "variant": variant,
                "level": level,
                "resistance_ohm_per_km": resistance,
                "time_s": int(source_row["time_s"]),
                "batch_id": int(source_row["batch_id"]),
                "brake_power_kW": float(transfer["brake_power"]),
                "traction_power_kW": float(transfer["traction_power"]),
                "p_direct_kW": float(transfer["p_direct_power"]),
                "ess_charge_kW": float(np.sum(charge)),
                "ess_discharge_kW": float(np.sum(discharge)),
                "absorbed_brake_power_kW": float(transfer["absorbed_power"]),
                "wasted_power_kW": float(transfer["discarded_power"]),
                "grid_power_kW": float(transfer["grid_power"]),
                "loss_kW": float(transfer["line_loss"]),
                "min_voltage_V": float(transfer["min_voltage_V"]),
                "power_balance_error_kW": balance_error,
                "soc_violation": soc_violation,
                "feasible": abs(balance_error) <= config.balance_tolerance_kW and not soc_violation,
                "ess_action_distance_km": _nearest_action_distance(
                    case_row, charge, discharge
                ),
                "partition": str(partition),
            }
            for index in range(10):
                record[f"ess{index + 1}_charge_kW"] = float(charge[index])
                record[f"ess{index + 1}_discharge_kW"] = float(discharge[index])
                record[f"ess{index + 1}_soc_percent"] = float(config.SOC_ess[index] * 100.0)
            outputs[variant].append(record)
    for variant, records in outputs.items():
        path = replay_file(variant, level)
        path.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(records).to_csv(path, index=False, encoding="utf-8-sig")


def run_fixed(force=False):
    before = _snapshot_protected()
    for level, resistance in LEVELS.items():
        targets = [replay_file(variant, level) for variant in ("frozen_dispatch", "fixed_cim_modes")]
        if all(path.exists() for path in targets) and not force:
            print(f"SKIP fixed {level}: results exist")
            continue
        env = os.environ.copy()
        env["BENCHMARK_LINE_RESISTANCE_OHM_PER_KM"] = str(resistance)
        subprocess.run(
            [sys.executable, "-u", "-B", str(Path(__file__).resolve()), "replay-one", "--level", level],
            cwd=EXPERIMENT_ROOT,
            env=env,
            check=True,
        )
        _assert_protected(before)


def local_environment(level):
    values = os.environ.copy()
    values.update(
        BENCHMARK_CASE_KEY=local_case_key(level),
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        BENCHMARK_LINE_RESISTANCE_OHM_PER_KM=str(LEVELS[level]),
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND="scip",
        ESS_ALLOW_LOCAL_QUBO_EXPERIMENT="1",
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        ESS_QUBO_BALANCE_WEIGHT="0.004",
        ESS_QUBO_SOC_DYNAMIC_WEIGHT="20.0",
        ESS_QUBO_SCIP_TIME_LIMIT_S="30",
        ESS_QUBO_RESUME="0",
        ESS_ABLATION_GRAPH_MODE="dynamic",
        ESS_ABLATION_ENABLE_MAXCUT="1",
        ESS_DISPATCH_QUBO_PRIORITY_BOOST="0.05",
        ESS_DECODER_MODE="soft",
    )
    return values


def run_local(force=False):
    before = _snapshot_protected()
    for level in LEVELS:
        if level == "BASE":
            print("REUSE local BASE from runtime_breakdown")
            continue
        target = local_result_file(level)
        if target.exists() and not force:
            print(f"SKIP local {level}: result exists")
            continue
        print(f"RUN local {level}: R={LEVELS[level]:.4f} ohm/km")
        subprocess.run(
            [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)],
            cwd=QUANTUM_SCRIPT.parent,
            env=local_environment(level),
            check=True,
        )
        _assert_protected(before)


def _bool_series(frame, column):
    if column not in frame:
        return pd.Series(False, index=frame.index)
    return frame[column].astype(str).str.lower().isin({"1", "true", "yes"})


def summarize(frame, stage, level):
    resistance = LEVELS[level]
    regen = float(frame["brake_power_kW"].sum()) / 3600.0
    if "absorbed_brake_power_kW" in frame:
        effective = float(frame["absorbed_brake_power_kW"].sum()) / 3600.0
    else:
        effective = float(
            (frame["p_direct_kW"] + frame["ess_charge_kW"] - frame["loss_kW"]).sum()
        ) / 3600.0
    min_voltage_column = "min_voltage_V" if "min_voltage_V" in frame else "estimated_min_voltage_kV"
    min_voltage = float(pd.to_numeric(frame[min_voltage_column], errors="coerce").min())
    if min_voltage_column.endswith("_kV"):
        min_voltage *= 1000.0
    feasible = _bool_series(frame, "feasible")
    distance = (
        float(pd.to_numeric(frame["ess_action_distance_km"], errors="coerce").mean())
        if "ess_action_distance_km" in frame
        else np.nan
    )
    if pd.isna(distance):
        case = pd.read_csv(CASE_FILE)
        distances = []
        for (_, case_row), (_, result_row) in zip(case.iterrows(), frame.iterrows()):
            charge = np.asarray(
                [result_row[f"ess{i}_charge_kW"] for i in range(1, 11)], dtype=float
            )
            discharge = np.asarray(
                [result_row[f"ess{i}_discharge_kW"] for i in range(1, 11)], dtype=float
            )
            distances.append(_nearest_action_distance(case_row, charge, discharge))
        distance = float(np.mean(distances))
    if "batch_solver_status" in frame:
        batch_status = frame[["batch_id", "batch_solver_status"]].drop_duplicates()
        statuses = sorted(batch_status["batch_solver_status"].astype(str).unique())
        timelimit_batches = int(
            batch_status["batch_solver_status"].astype(str).str.lower().eq("timelimit").sum()
        )
        solver_status_mix = "+".join(statuses)
    else:
        timelimit_batches = 0
        solver_status_mix = "replay"
    return {
        "stage": stage,
        "level": level,
        "resistance_ohm_per_km": resistance,
        "time_steps": len(frame),
        "final_feasible_steps": int(feasible.sum()),
        "absorption_rate_percent": effective / regen * 100.0,
        "effective_absorbed_kWh": effective,
        "grid_energy_kWh": float(frame["grid_power_kW"].sum()) / 3600.0,
        "wasted_energy_kWh": float(frame["wasted_power_kW"].sum()) / 3600.0,
        "line_loss_kWh": float(frame["loss_kW"].sum()) / 3600.0,
        "minimum_voltage_V": min_voltage,
        "mean_ess_action_distance_km": distance,
        "solver_status_mix": solver_status_mix,
        "timelimit_batches": timelimit_batches,
        "new_platform_submissions": 0,
    }


def collect():
    rows = []
    for variant in ("frozen_dispatch", "fixed_cim_modes"):
        for level in LEVELS:
            path = replay_file(variant, level)
            if path.exists():
                rows.append(summarize(pd.read_csv(path), variant, level))
    for level in LEVELS:
        path = local_result_file(level)
        if path.exists():
            rows.append(summarize(pd.read_csv(path), "full_local_scip", level))
    if not rows:
        raise RuntimeError("No resistance-sensitivity results")
    summary = pd.DataFrame(rows).sort_values(
        ["stage", "resistance_ohm_per_km"]
    )
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    summary.to_csv(
        RESULT_ROOT / "Line_Resistance_Sensitivity_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    report = [
        "# 线路电阻敏感性实验结果",
        "",
        "## 参数定义",
        "",
        "- 电阻参数是单位长度电阻，单位为Ω/km；边电阻等于该参数乘以边长km。",
        "- 基准值0.134 Ω/km，测试上下10%和20%的五个水平。",
        "- 固定调度与固定CIM模式复算均不调用平台；完整优化使用本地SCIP。",
        "",
        "## 汇总",
        "",
        "| 阶段 | 水平 | 电阻(Ω/km) | 可行步 | 消纳率(%) | 有效消纳(kWh) | 网损(kWh) | 最低电压(V) |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary.iterrows():
        report.append(
            f"| {row['stage']} | {row['level']} | {row['resistance_ohm_per_km']:.4f} | "
            f"{int(row['final_feasible_steps'])}/{int(row['time_steps'])} | "
            f"{row['absorption_rate_percent']:.6f} | {row['effective_absorbed_kWh']:.6f} | "
            f"{row['line_loss_kWh']:.6f} | {row['minimum_voltage_V']:.6f} |"
        )
    report.extend(["", "## 物理响应检查", ""])
    for stage, group in summary.groupby("stage", sort=False):
        ordered = group.sort_values("resistance_ohm_per_km")
        loss_monotonic = bool(np.all(np.diff(ordered["line_loss_kWh"]) >= -1e-10))
        voltage_monotonic = bool(np.all(np.diff(ordered["minimum_voltage_V"]) <= 1e-10))
        report.append(
            f"- {stage}：网损随电阻非减={'通过' if loss_monotonic else '未通过'}；"
            f"最低电压随电阻非增={'通过' if voltage_monotonic else '未通过'}。"
        )
    frozen = summary.loc[summary["stage"] == "frozen_dispatch"].set_index("level")
    if {"M20", "BASE", "P20"}.issubset(frozen.index):
        report.extend(
            [
                "",
                "## 端点变化",
                "",
                f"- 相对基准0.1340 Ω/km，−20%电阻使网损变化{(frozen.loc['M20', 'line_loss_kWh'] / frozen.loc['BASE', 'line_loss_kWh'] - 1.0) * 100.0:.6f}%，消纳率变化{frozen.loc['M20', 'absorption_rate_percent'] - frozen.loc['BASE', 'absorption_rate_percent']:.6f}个百分点。",
                f"- 相对基准0.1340 Ω/km，+20%电阻使网损变化{(frozen.loc['P20', 'line_loss_kWh'] / frozen.loc['BASE', 'line_loss_kWh'] - 1.0) * 100.0:.6f}%，消纳率变化{frozen.loc['P20', 'absorption_rate_percent'] - frozen.loc['BASE', 'absorption_rate_percent']:.6f}个百分点。",
                "- 随电阻增加，弃能下降但网侧取电上升；这不是性能改善，而是更多能量在线路损耗中消耗，最终有效消纳仍下降。",
                "- 各档最低电压均为1200 V，说明电压安全限流持续处于激活状态；因此最低电压不会继续下降，损耗和可输送功率承担主要敏感性表现。",
            ]
        )
    local = summary.loc[summary["stage"] == "full_local_scip"]
    if not local.empty:
        report.extend(
            [
                "",
                "## 求解状态",
                "",
                f"- 完整本地优化共{int(local['timelimit_batches'].sum())}/15批达到30秒时间上限，其余批次达到最优；所有批次均返回可行解。",
                "- 因存在限时批次，完整本地优化用于验证趋势和可行性，不宣称所有档位均获得全局最优QUBO解。",
            ]
        )
    fixed_modes = summary.loc[summary["stage"] == "fixed_cim_modes"].set_index("level")
    local_indexed = local.set_index("level") if not local.empty else pd.DataFrame()
    if len(frozen) == 5 and len(fixed_modes) == 5 and len(local_indexed) == 5:
        fixed_vs_frozen = float(
            (fixed_modes["absorption_rate_percent"] - frozen["absorption_rate_percent"])
            .abs()
            .max()
        )
        local_vs_fixed = float(
            (local_indexed["absorption_rate_percent"] - fixed_modes["absorption_rate_percent"])
            .abs()
            .max()
        )
        report.extend(
            [
                "",
                "## 方法响应",
                "",
                f"- 固定CIM模式并重跑物理解码，相对冻结连续调度的最大消纳率差异仅{fixed_vs_frozen:.6f}个百分点。",
                f"- 完整本地QUBO重优化相对固定CIM模式的最大消纳率差异仅{local_vs_fixed:.6f}个百分点。",
                "- 因此当前场景的电阻响应主要来自线路损耗与电压安全限流；在软解码器下，上游二进制模式变化对最终能量指标的影响较小。",
            ]
        )
    report.extend(
        [
            "",
            "## 边界",
            "",
            "- 固定调度用于隔离纯物理响应；固定CIM模式允许连续物理解码重新分配功率。",
            "- 本地SCIP组检验完整QUBO和物理解码是否随电阻变化，不包含新的量子平台提交。",
            "- 数据来自30秒线路运行场景仿真，不是现场实测数据。",
            "",
        ]
    )
    (RESULT_ROOT / "Line_Resistance_Sensitivity_Results.md").write_text(
        "\n".join(report), encoding="utf-8"
    )
    print(summary.to_string(index=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("validate", "run-fixed", "run-local", "replay-one", "collect")
    )
    parser.add_argument("--level", choices=tuple(LEVELS))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.command == "validate":
        validate()
    elif args.command == "run-fixed":
        validate()
        run_fixed(force=args.force)
        collect()
    elif args.command == "run-local":
        validate()
        run_local(force=args.force)
        collect()
    elif args.command == "replay-one":
        if not args.level:
            raise RuntimeError("replay-one requires --level")
        replay_one(args.level, LEVELS[args.level])
    else:
        collect()


if __name__ == "__main__":
    main()
