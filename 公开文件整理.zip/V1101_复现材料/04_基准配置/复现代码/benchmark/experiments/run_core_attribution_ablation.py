"""Run the fixed-decoder core attribution ablation.

The adapter keeps the existing Quantum_QUBO module imports and entry point.
It changes only environment-backed experiment switches, output locations, and
the selected solver backend.
"""

import argparse
import os
from pathlib import Path
import subprocess
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
RESULT_ROOT = Path(
    os.environ.get(
        "CORE_ATTRIBUTION_RESULT_ROOT",
        EXPERIMENT_ROOT / "results" / "core_attribution",
    )
).resolve()
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"
BATCH_SIZE = 10


ARMS = {
    "A": {
        "name": "decoder_only",
        "description": "Decoder only; QUBO preference disabled",
        "graph_mode": "dynamic",
        "maxcut_enabled": False,
        "backend": "scip",
        "decoder_priority_boost": 0.0,
    },
    "B": {
        "name": "static_maxcut_scip",
        "description": "Static t=0 graph + Max-Cut + SCIP",
        "graph_mode": "static",
        "maxcut_enabled": True,
        "backend": "scip",
        "decoder_priority_boost": 0.05,
    },
    "C": {
        "name": "dynamic_maxcut_scip",
        "description": "Dynamic graph + Max-Cut + SCIP",
        "graph_mode": "dynamic",
        "maxcut_enabled": True,
        "backend": "scip",
        "decoder_priority_boost": 0.05,
    },
    "D": {
        "name": "dynamic_maxcut_cim",
        "description": "Dynamic graph + Max-Cut + CIM",
        "graph_mode": "dynamic",
        "maxcut_enabled": True,
        "backend": "cim",
        "decoder_priority_boost": 0.05,
    },
    "E": {
        "name": "dynamic_no_maxcut_scip",
        "description": "Dynamic graph without Max-Cut + SCIP",
        "graph_mode": "dynamic",
        "maxcut_enabled": False,
        "backend": "scip",
        "decoder_priority_boost": 0.05,
    },
}


def experiment_key(arm_id):
    arm = ARMS[arm_id]
    return f"CORE_{arm_id}_{arm['name']}"


def result_file(arm_id):
    return (
        RESULT_ROOT
        / experiment_key(arm_id)
        / "Quantum_QUBO"
        / f"TimeSeries_Result_10ESS_{BATCH_SIZE}sBatch.csv"
    )


def batch_result_file(arm_id):
    return (
        RESULT_ROOT
        / experiment_key(arm_id)
        / "Quantum_QUBO"
        / f"Batch_Summary_10ESS_{BATCH_SIZE}sBatch.csv"
    )


def platform_timing_file(arm_id):
    return (
        RESULT_ROOT
        / experiment_key(arm_id)
        / "Quantum_QUBO"
        / "Platform_Result_Timing.csv"
    )


def experiment_environment(arm_id):
    arm = ARMS[arm_id]
    environment = os.environ.copy()
    environment.update(
        BENCHMARK_CASE_KEY=experiment_key(arm_id),
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND=arm["backend"],
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        ESS_QUBO_BALANCE_WEIGHT="0.004",
        ESS_QUBO_SOC_DYNAMIC_WEIGHT="20.0",
        ESS_QUBO_SCIP_TIME_LIMIT_S="30",
        ESS_QUBO_RESUME="0",
        ESS_ABLATION_GRAPH_MODE=arm["graph_mode"],
        ESS_ABLATION_ENABLE_MAXCUT=(
            "1" if arm["maxcut_enabled"] else "0"
        ),
        ESS_DISPATCH_QUBO_PRIORITY_BOOST=str(
            arm["decoder_priority_boost"]
        ),
    )
    if arm["backend"] == "scip":
        environment["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
    else:
        environment.pop("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT", None)
    return environment


def validate_configuration():
    if not CASE_FILE.is_file():
        raise FileNotFoundError(f"Missing ablation case: {CASE_FILE}")
    if not QUANTUM_SCRIPT.is_file():
        raise FileNotFoundError(f"Missing quantum entry point: {QUANTUM_SCRIPT}")
    if len(ARMS) != 5:
        raise RuntimeError("The attribution design must contain arms A-E")
    cim_arms = [key for key, arm in ARMS.items() if arm["backend"] == "cim"]
    if cim_arms != ["D"]:
        raise RuntimeError("Only arm D may use CIM in the default design")
    print(f"Case: {CASE_FILE}")
    print(f"Result root: {RESULT_ROOT}")
    print("Local arms: A, B, C, E")
    print("CIM arm: D (3 submissions for the 30-step case)")


def run_one(arm_id, force=False):
    arm = ARMS[arm_id]
    output_file = result_file(arm_id)
    if output_file.is_file() and not force:
        print(f"SKIP {arm_id}: result already exists at {output_file}")
        return
    command = [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)]
    print(f"RUN {arm_id}: {arm['description']}", flush=True)
    subprocess.run(
        command,
        cwd=QUANTUM_SCRIPT.parent,
        env=experiment_environment(arm_id),
        check=True,
    )


def _bool_series(data, column):
    if column not in data:
        return pd.Series(False, index=data.index)
    return data[column].astype(str).str.lower().isin({"1", "true", "yes"})


def _numeric_sum(data, column):
    if column not in data:
        return 0.0
    return float(pd.to_numeric(data[column], errors="coerce").fillna(0.0).sum())


def summarize_one(arm_id):
    path = result_file(arm_id)
    if not path.is_file():
        return None
    arm = ARMS[arm_id]
    data = pd.read_csv(path)
    total_regen_kwh = _numeric_sum(data, "brake_power_kW") / 3600.0
    if "p_direct_received_kW" in data:
        effective_kwh = _numeric_sum(data, "absorbed_brake_power_kW") / 3600.0
    else:
        effective_kwh = (
            _numeric_sum(data, "p_direct_kW")
            + _numeric_sum(data, "ess_charge_kW")
            - _numeric_sum(data, "loss_kW")
        ) / 3600.0
    total_ess_action = (
        _numeric_sum(data, "ess_charge_kW")
        + _numeric_sum(data, "ess_discharge_kW")
    )
    fallback_power = _numeric_sum(data, "decoder_fallback_power_kW")
    backends = (
        sorted(data["batch_solver_backend"].astype(str).unique())
        if "batch_solver_backend" in data
        else [arm["backend"].upper()]
    )
    batch_file = batch_result_file(arm_id)
    batch_data = pd.read_csv(batch_file) if batch_file.exists() else pd.DataFrame()
    timing_file = platform_timing_file(arm_id)
    if timing_file.exists():
        platform_timing = pd.read_csv(timing_file)
        backend_solve_time_s = (
            pd.to_numeric(
                platform_timing["platform_runtime_ms"], errors="coerce"
            ).fillna(0.0).sum()
            / 1000.0
        )
        time_basis = "platform_reported_runtime"
    elif arm["backend"] == "cim":
        backend_solve_time_s = float("nan")
        time_basis = "platform_report_unavailable"
    elif "cim_call_time_s" in batch_data:
        backend_solve_time_s = pd.to_numeric(
            batch_data["cim_call_time_s"], errors="coerce"
        ).fillna(0.0).sum()
        time_basis = "local_solver_call_wall_time"
    else:
        backend_solve_time_s = float("nan")
        time_basis = "unavailable"

    return {
        "arm": arm_id,
        "experiment": arm["name"],
        "description": arm["description"],
        "graph_mode": arm["graph_mode"],
        "maxcut_enabled": arm["maxcut_enabled"],
        "configured_backend": arm["backend"].upper(),
        "observed_backend_mix": "+".join(backends),
        "decoder_priority_boost": arm["decoder_priority_boost"],
        "time_steps": int(len(data)),
        "platform_or_solver_batches": (
            int(data["batch_id"].nunique()) if "batch_id" in data else 0
        ),
        "absorption_rate_percent": (
            effective_kwh / total_regen_kwh * 100.0
            if total_regen_kwh > 0.0
            else 0.0
        ),
        "effective_absorbed_kWh": effective_kwh,
        "grid_energy_kWh": _numeric_sum(data, "grid_power_kW") / 3600.0,
        "wasted_energy_kWh": _numeric_sum(data, "wasted_power_kW") / 3600.0,
        "line_loss_kWh": _numeric_sum(data, "loss_kW") / 3600.0,
        "infeasible_steps": int((~_bool_series(data, "feasible")).sum()),
        "raw_balance_violation_steps": int(
            _bool_series(data, "qubo_balance_violation").sum()
        ),
        "raw_soc_violation_steps": int(
            _bool_series(data, "qubo_soc_violation").sum()
        ),
        "raw_substation_violation_steps": int(
            _bool_series(data, "qubo_substation_violation").sum()
        ),
        "decoder_fallback_power_kW_sum": fallback_power,
        "power_weighted_mode_retention_percent": (
            max(0.0, 1.0 - fallback_power / total_ess_action) * 100.0
            if total_ess_action > 0.0
            else 100.0
        ),
        "backend_solve_time_s": backend_solve_time_s,
        "time_basis": time_basis,
    }


def collect():
    rows = [
        summary
        for arm_id in ARMS
        if (summary := summarize_one(arm_id)) is not None
    ]
    if not rows:
        raise RuntimeError("No core-attribution results are available")
    summary = pd.DataFrame(rows).sort_values("arm").reset_index(drop=True)
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    output_file = RESULT_ROOT / "Core_Attribution_Ablation_Summary.csv"
    summary.to_csv(output_file, index=False, encoding="utf-8-sig")

    indexed = summary.set_index("arm")
    comparisons = (
        ("dynamic_graph", "C", "B"),
        ("maxcut_objective", "C", "E"),
        ("cim_backend", "D", "C"),
        ("complete_method_vs_decoder", "D", "A"),
    )
    effect_metrics = (
        "absorption_rate_percent",
        "effective_absorbed_kWh",
        "grid_energy_kWh",
        "wasted_energy_kWh",
        "line_loss_kWh",
        "infeasible_steps",
        "raw_balance_violation_steps",
        "power_weighted_mode_retention_percent",
        "backend_solve_time_s",
    )
    effect_rows = []
    for effect, treatment, control in comparisons:
        if treatment not in indexed.index or control not in indexed.index:
            continue
        row = {
            "effect": effect,
            "treatment_arm": treatment,
            "control_arm": control,
        }
        for metric in effect_metrics:
            treatment_value = float(indexed.loc[treatment, metric])
            control_value = float(indexed.loc[control, metric])
            row[f"treatment_{metric}"] = treatment_value
            row[f"control_{metric}"] = control_value
            row[f"delta_{metric}"] = treatment_value - control_value
        effect_rows.append(row)
    effects = pd.DataFrame(effect_rows)
    effects_file = RESULT_ROOT / "Core_Attribution_Effect_Deltas.csv"
    effects.to_csv(effects_file, index=False, encoding="utf-8-sig")

    report_file = RESULT_ROOT / "Core_Attribution_Results.md"
    report_lines = [
        "# 核心方法归因消融结果",
        "",
        "## 实验完成情况",
        "",
        "- A、B、C、E组使用本地SCIP；D组使用Kaiwu CIM。",
        "- 每组包含30个时间步，每10秒构建一个100变量QUBO。",
        "- D组实际提交3个CIM批次，未发生本地求解回退。",
        "- 所有组的30个时间步均通过最终物理可行性检查。",
        "",
        "## 主要结果",
        "",
        "| 组别 | 图模型 | Max-Cut | 后端 | 消纳率(%) | 有效消纳(kWh) | 网侧取电(kWh) | 网损(kWh) | 后端计算时间(s) | 计时依据 |",
        "|---|---|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for _, row in summary.iterrows():
        report_lines.append(
            f"| {row['arm']} | {row['graph_mode']} | "
            f"{'开启' if bool(row['maxcut_enabled']) else '关闭'} | "
            f"{row['observed_backend_mix']} | "
            f"{row['absorption_rate_percent']:.6f} | "
            f"{row['effective_absorbed_kWh']:.6f} | "
            f"{row['grid_energy_kWh']:.6f} | "
            f"{row['line_loss_kWh']:.6f} | "
            f"{row['backend_solve_time_s']:.6f} | "
            f"{row['time_basis']} |"
        )
    report_lines.extend([
        "",
        "## 归因差值",
        "",
        "差值均按“处理组减对照组”计算。消纳率差值单位为百分点。",
        "",
        "| 归因项 | 比较 | 消纳率差值 | 有效消纳差值(kWh) | 网侧取电差值(kWh) | 网损差值(kWh) | 时间差值(s) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ])
    effect_labels = {
        "dynamic_graph": "动态图贡献",
        "maxcut_objective": "Max-Cut贡献",
        "cim_backend": "CIM后端差异",
        "complete_method_vs_decoder": "完整方法相对纯解码器",
    }
    for _, row in effects.iterrows():
        report_lines.append(
            f"| {effect_labels[row['effect']]} | "
            f"{row['treatment_arm']}-{row['control_arm']} | "
            f"{row['delta_absorption_rate_percent']:.6f} | "
            f"{row['delta_effective_absorbed_kWh']:.6f} | "
            f"{row['delta_grid_energy_kWh']:.6f} | "
            f"{row['delta_line_loss_kWh']:.6f} | "
            f"{row['delta_backend_solve_time_s']:.6f} |"
        )
    report_lines.extend([
        "",
        "## 解释边界",
        "",
        "- 当前仅为单次消融运行，不能据此给出统计显著性结论。",
        "- SCIP部分批次达到30秒时间上限，后端比较应同时参考求解状态和最优间隙。",
        "- 各组最终能量指标非常接近，说明当前软物理解码器对上游二进制模式具有较强修复作用。",
        "- D组时间采用QBoson任务结果报告中的“运行时长”，3批合计25.4459 ms；不计SDK提交、排队等待、结果解析、物理解码和文件写入时间。",
        "- A、B、C、E组采用本地SCIP求解器调用墙钟时间；因此跨后端时间比较反映各自后端报告/调用口径，不是完整应用端到端耗时。",
        "- 本结果来自仿真算例，不是线路现场实测数据。",
        "",
    ])
    report_file.write_text("\n".join(report_lines), encoding="utf-8")
    print(summary.to_string(index=False))
    print(f"Saved: {output_file}")
    print(f"Saved: {effects_file}")
    print(f"Saved: {report_file}")
    return summary


def list_arms():
    for arm_id, arm in ARMS.items():
        submissions = 3 if arm["backend"] == "cim" else 0
        print(
            f"{arm_id}: {arm['description']} | "
            f"backend={arm['backend']} | platform_submissions={submissions}"
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=("list", "validate", "run-local", "run-cim", "collect"),
    )
    parser.add_argument("--arm", choices=tuple(ARMS))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    if args.command == "list":
        list_arms()
        return
    validate_configuration()
    if args.command == "validate":
        return
    if args.command == "run-local":
        selected = [args.arm] if args.arm else ["A", "B", "C", "E"]
        invalid = [arm_id for arm_id in selected if ARMS[arm_id]["backend"] != "scip"]
        if invalid:
            raise ValueError(f"run-local cannot execute CIM arms: {invalid}")
        for arm_id in selected:
            run_one(arm_id, force=args.force)
        return
    if args.command == "run-cim":
        if args.arm not in {None, "D"}:
            raise ValueError("run-cim is restricted to arm D")
        run_one("D", force=args.force)
        return
    collect()


if __name__ == "__main__":
    main()
