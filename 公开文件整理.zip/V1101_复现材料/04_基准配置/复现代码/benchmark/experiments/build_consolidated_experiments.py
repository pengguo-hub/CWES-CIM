"""Build a non-destructive four-experiment archive from completed results."""

from __future__ import annotations

import hashlib
from pathlib import Path
import shutil

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
SOURCE_ROOT = HERE / "results"
OUT = SOURCE_ROOT / "final_consolidated_experiments"


def read_csv(*parts):
    return pd.read_csv(SOURCE_ROOT.joinpath(*parts))


def scalar(row, key, default=np.nan):
    if row is None or key not in row.index:
        return default
    return row[key]


def row_by(frame, column, value):
    matched = frame.loc[frame[column] == value]
    if len(matched) != 1:
        raise RuntimeError(f"Expected one {column}={value!r}, found {len(matched)}")
    return matched.iloc[0]


def write_csv(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def copy_source(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def build_experiment_1():
    folder = OUT / "01_方法贡献与物理有效性"
    core = read_csv("core_attribution", "Core_Attribution_Ablation_Summary.csv")
    decoder = read_csv("cim_decoder_contribution", "CIM_Decoder_Contribution_Summary.csv")
    energy = read_csv("energy_conservation_audit", "Energy_SOC_Audit_Summary.csv")

    specs = [
        ("M01", "raw_cim_modes", None, "raw_cim_modes", None, "原始CIM二进制模式，尚未经过物理解码"),
        ("M02", "hard_cim_decoder", None, "hard_cim_modes", "decoder_hard_cim_modes", "CIM模式加硬约束物理解码"),
        ("M03", "soft_cim_guided", "D", "soft_cim_guided", "D_dynamic_maxcut_cim", "动态图、Max-Cut、CIM和软物理解码"),
        ("M04", "physical_decoder_only", "A", "pure_physical_decoder", "A_decoder_only", "关闭QUBO偏好，仅保留物理解码"),
        ("M05", "static_maxcut_scip", "B", None, "B_static_maxcut_scip", "静态图、Max-Cut和SCIP"),
        ("M06", "dynamic_maxcut_scip", "C", None, "C_dynamic_maxcut_scip", "动态图、Max-Cut和SCIP"),
        ("M07", "dynamic_no_maxcut_scip", "E", None, "E_dynamic_no_maxcut_scip", "动态图、无Max-Cut和SCIP"),
    ]
    rows = []
    for config_id, name, core_arm, decoder_variant, energy_dataset, description in specs:
        c = row_by(core, "arm", core_arm) if core_arm else None
        d = row_by(decoder, "variant", decoder_variant) if decoder_variant else None
        e = row_by(energy, "dataset", energy_dataset) if energy_dataset else None
        rows.append({
            "configuration_id": config_id,
            "configuration": name,
            "description": description,
            "graph_mode": scalar(c, "graph_mode", "dynamic" if "cim" in name else np.nan),
            "maxcut_enabled": scalar(c, "maxcut_enabled", np.nan),
            "backend": scalar(c, "configured_backend", "CIM" if "cim" in name else np.nan),
            "decoder_mode": scalar(d, "decoder_mode", "soft" if core_arm else np.nan),
            "qubo_priority_boost": scalar(d, "qubo_priority_boost", scalar(c, "decoder_priority_boost")),
            "time_steps": scalar(c, "time_steps", scalar(d, "time_steps", scalar(e, "time_steps"))),
            "raw_feasible_steps": scalar(d, "raw_feasible_steps", np.nan),
            "raw_balance_violation_steps": scalar(d, "raw_balance_violation_steps", scalar(c, "raw_balance_violation_steps")),
            "final_feasible_steps": scalar(d, "final_feasible_steps", scalar(e, "audit_pass_steps", 30 if c is not None else np.nan)),
            "final_feasibility_percent": scalar(d, "final_feasibility_percent", scalar(e, "audit_pass_percent", 100.0 if c is not None else np.nan)),
            "absorption_rate_percent": scalar(d, "absorption_rate_percent", scalar(c, "absorption_rate_percent")),
            "effective_absorbed_kWh": scalar(d, "effective_absorbed_kWh", scalar(c, "effective_absorbed_kWh")),
            "grid_energy_kWh": scalar(d, "grid_energy_kWh", scalar(c, "grid_energy_kWh")),
            "wasted_energy_kWh": scalar(d, "wasted_energy_kWh", scalar(c, "wasted_energy_kWh")),
            "line_loss_kWh": scalar(d, "line_loss_kWh", scalar(c, "line_loss_kWh")),
            "repair_steps": scalar(d, "repair_steps", np.nan),
            "count_mode_retention_percent": scalar(d, "count_mode_retention_percent", np.nan),
            "power_mode_retention_percent": scalar(d, "power_mode_retention_percent", scalar(c, "power_weighted_mode_retention_percent")),
            "decoder_time_s": scalar(d, "decoder_time_s", np.nan),
            "platform_runtime_ms": scalar(d, "source_platform_runtime_s", scalar(c, "backend_solve_time_s")) * 1000.0 if (d is not None and str(scalar(c, "configured_backend", "CIM")) == "CIM") else (scalar(c, "backend_solve_time_s") * 1000.0 if c is not None and scalar(c, "configured_backend") == "CIM" else np.nan),
            "power_balance_max_abs_error_kW": scalar(e, "max_power_balance_abs_error_kW"),
            "soc_recurrence_max_abs_error_percent": scalar(e, "max_soc_recurrence_abs_error_percent"),
            "cumulative_energy_closure_error_kWh": scalar(e, "cumulative_energy_closure_error_kWh"),
            "new_unique_platform_submissions": 3 if config_id == "M03" else 0,
        })
    master = pd.DataFrame(rows)
    write_csv(master, folder / "Experiment_01_Master_Comparison.csv")
    sources = pd.DataFrame([
        {"source_experiment": "core_attribution", "role": "core method ablation", "new_platform_submissions": 3},
        {"source_experiment": "cim_decoder_contribution", "role": "decoder contribution decomposition; reuses M03", "new_platform_submissions": 0},
        {"source_experiment": "energy_conservation_audit", "role": "independent power/SOC closure audit", "new_platform_submissions": 0},
    ])
    write_csv(sources, folder / "Source_Manifest.csv")
    (folder / "README.md").write_text(
        "# 实验1：方法贡献与物理有效性\n\n"
        "合并原核心方法归因、CIM/物理解码贡献拆分和逐时能量守恒审计。主表按7个不重复配置统一列出原始可行性、最终物理可行性、能量指标、模式保留率及能量闭合误差。\n\n"
        "原始CIM模式行没有最终能量指标，因为它尚未经过物理解码；空值不是数据缺失。\n",
        encoding="utf-8",
    )
    for source in [
        SOURCE_ROOT / "core_attribution" / "Core_Attribution_Results.md",
        SOURCE_ROOT / "cim_decoder_contribution" / "CIM_Decoder_Contribution_Results.md",
        SOURCE_ROOT / "energy_conservation_audit" / "Energy_SOC_Audit_Results.md",
    ]:
        copy_source(source, folder / "source_reports" / source.name)


def build_experiment_2():
    folder = OUT / "02_运行时间与提交策略"
    runtime = read_csv("runtime_breakdown", "Runtime_Phase_Summary.csv")
    interval = read_csv("batch_interval_comparison", "Batch_Interval_CIM_Summary.csv")
    repeat = read_csv("independent_repeats", "Independent_Repeat_Summary.csv")
    local = row_by(runtime, "arm", "LOCAL_SCIP")
    cim = row_by(runtime, "arm", "CIM")
    reused_cim = row_by(repeat, "repeat_id", "R02")
    one = row_by(interval, "arm", "1s")
    two = row_by(interval, "arm", "2s")
    five = row_by(interval, "arm", "5s")
    ten = row_by(interval, "arm", "10s")
    rows = [
        {
            "configuration": "local_scip_10s",
            "run_context": "runtime_phase_baseline",
            "backend": "SCIP",
            "batch_size_s": 10,
            "batches_or_submissions": int(local["batches"]),
            "platform_runtime_total_ms": np.nan,
            "sdk_platform_wall_s": local["phase_sdk_platform_wall_s"],
            "backend_solve_time_s": local["phase_backend_solve_s"],
            "decoder_time_s": local["phase_decoder_s"],
            "end_to_end_s": local["phase_batch_end_to_end_s"],
            "feasible_steps": 30,
            "absorption_rate_percent": np.nan,
            "quantization_retention_percent": np.nan,
            "new_unique_platform_submissions": 0,
        },
        {
            "configuration": "cim_10s_runtime_baseline",
            "run_context": "runtime_phase_baseline",
            "backend": "CIM",
            "batch_size_s": 10,
            "batches_or_submissions": int(cim["batches"]),
            "platform_runtime_total_ms": cim["platform_reported_runtime_s"] * 1000.0,
            "sdk_platform_wall_s": cim["phase_sdk_platform_wall_s"],
            "backend_solve_time_s": np.nan,
            "decoder_time_s": cim["phase_decoder_s"],
            "end_to_end_s": cim["phase_batch_end_to_end_s"],
            "feasible_steps": int(reused_cim["final_feasible_steps"]),
            "absorption_rate_percent": reused_cim["absorption_rate_percent"],
            "quantization_retention_percent": np.nan,
            "new_unique_platform_submissions": 3,
        },
        {
            "configuration": "cim_1s_cross_batch",
            "run_context": "submission_interval_comparison",
            "backend": "CIM",
            "batch_size_s": 1,
            "batches_or_submissions": int(one["platform_submissions"]),
            "platform_runtime_total_ms": one["platform_runtime_total_ms"],
            "sdk_platform_wall_s": one["sdk_platform_wall_total_s"],
            "backend_solve_time_s": np.nan,
            "decoder_time_s": np.nan,
            "end_to_end_s": one["end_to_end_total_s"],
            "feasible_steps": int(one["feasible_steps"]),
            "absorption_rate_percent": one["absorption_rate_percent"],
            "quantization_retention_percent": one["mean_quantization_retention_percent"],
            "new_unique_platform_submissions": 30,
        },
        {
            "configuration": "cim_2s_cross_batch",
            "run_context": "submission_interval_comparison",
            "backend": "CIM",
            "batch_size_s": 2,
            "batches_or_submissions": int(two["platform_submissions"]),
            "platform_runtime_total_ms": two["platform_runtime_total_ms"],
            "sdk_platform_wall_s": two["sdk_platform_wall_total_s"],
            "backend_solve_time_s": np.nan,
            "decoder_time_s": np.nan,
            "end_to_end_s": two["end_to_end_total_s"],
            "feasible_steps": int(two["feasible_steps"]),
            "absorption_rate_percent": two["absorption_rate_percent"],
            "quantization_retention_percent": two["mean_quantization_retention_percent"],
            "new_unique_platform_submissions": 15,
        },
        {
            "configuration": "cim_5s_cross_batch",
            "run_context": "submission_interval_comparison",
            "backend": "CIM",
            "batch_size_s": 5,
            "batches_or_submissions": int(five["platform_submissions"]),
            "platform_runtime_total_ms": five["platform_runtime_total_ms"],
            "sdk_platform_wall_s": five["sdk_platform_wall_total_s"],
            "backend_solve_time_s": np.nan,
            "decoder_time_s": np.nan,
            "end_to_end_s": five["end_to_end_total_s"],
            "feasible_steps": int(five["feasible_steps"]),
            "absorption_rate_percent": five["absorption_rate_percent"],
            "quantization_retention_percent": five["mean_quantization_retention_percent"],
            "new_unique_platform_submissions": 6,
        },
        {
            "configuration": "cim_10s_cross_batch",
            "run_context": "submission_interval_comparison",
            "backend": "CIM",
            "batch_size_s": 10,
            "batches_or_submissions": int(ten["platform_submissions"]),
            "platform_runtime_total_ms": ten["platform_runtime_total_ms"],
            "sdk_platform_wall_s": ten["sdk_platform_wall_total_s"],
            "backend_solve_time_s": np.nan,
            "decoder_time_s": np.nan,
            "end_to_end_s": ten["end_to_end_total_s"],
            "feasible_steps": int(ten["feasible_steps"]),
            "absorption_rate_percent": ten["absorption_rate_percent"],
            "quantization_retention_percent": ten["mean_quantization_retention_percent"],
            "new_unique_platform_submissions": 3,
        },
    ]
    write_csv(pd.DataFrame(rows), folder / "Experiment_02_Master_Comparison.csv")
    write_csv(pd.DataFrame([
        {"source_experiment": "runtime_breakdown", "role": "SCIP/CIM phase timing", "new_platform_submissions": 3},
        {"source_experiment": "batch_interval_comparison", "role": "1s/2s/5s/10s platform submission strategy", "new_platform_submissions": 54},
    ]), folder / "Source_Manifest.csv")
    (folder / "README.md").write_text(
        "# 实验2：运行时间与提交策略\n\n"
        "合并原运行时间分阶段实验和1秒/2秒/5秒/10秒平台提交比较。平台主时间统一为平台返回的纯计算时间；SDK等待和端到端时间单列，不混为平台计算时间。\n\n"
        "两次10秒CIM属于不同运行上下文，均保留，用于展示平台运行波动，不把它们误写成同一次测量。\n",
        encoding="utf-8",
    )
    for source in [
        SOURCE_ROOT / "runtime_breakdown" / "Runtime_Phase_Results.md",
        SOURCE_ROOT / "batch_interval_comparison" / "Batch_Interval_Comparison_Results.md",
    ]:
        copy_source(source, folder / "source_reports" / source.name)


def build_experiment_3():
    folder = OUT / "03_独立重复与稳定性"
    summary = read_csv("independent_repeats", "Independent_Repeat_Summary.csv")
    statistics = read_csv("independent_repeats", "Independent_Repeat_Statistics.csv")
    write_csv(summary, folder / "Experiment_03_Master_Comparison.csv")
    write_csv(statistics, folder / "Experiment_03_Statistics.csv")
    write_csv(pd.DataFrame([{
        "source_experiment": "independent_repeats",
        "repetitions": len(summary),
        "source_platform_submissions": int(summary["platform_successful_batches"].sum()),
        "new_unique_platform_submissions": int(summary["new_platform_submissions"].sum()),
        "note": "R01 and R02 reuse experiments 1 and 2; R03-R05 are new",
    }]), folder / "Source_Manifest.csv")
    (folder / "README.md").write_text(
        "# 实验3：独立重复与稳定性\n\n"
        "保留5次独立CIM运行的逐次汇总和均值、样本标准差、95%置信区间。R01和R02复用已完成任务，R03-R05新增9次平台提交。\n",
        encoding="utf-8",
    )
    copy_source(
        SOURCE_ROOT / "independent_repeats" / "Independent_Repeat_Results.md",
        folder / "source_reports" / "Independent_Repeat_Results.md",
    )


def build_experiment_4():
    folder = OUT / "04_线路电阻敏感性"
    summary = read_csv("line_resistance_sensitivity", "Line_Resistance_Sensitivity_Summary.csv")
    write_csv(summary, folder / "Experiment_04_Master_Comparison.csv")
    write_csv(pd.DataFrame([{
        "source_experiment": "line_resistance_sensitivity",
        "resistance_levels": summary["resistance_ohm_per_km"].nunique(),
        "analysis_stages": summary["stage"].nunique(),
        "new_unique_platform_submissions": int(summary["new_platform_submissions"].sum()),
        "note": "CIM modes are replayed; complete re-optimization uses local SCIP",
    }]), folder / "Source_Manifest.csv")
    (folder / "README.md").write_text(
        "# 实验4：线路电阻敏感性\n\n"
        "保留0.134 Ω/km附近上下10%和20%的五档敏感性结果，包括冻结调度、固定CIM模式复算和完整本地SCIP重优化。该实验没有新增平台提交。\n",
        encoding="utf-8",
    )
    copy_source(
        SOURCE_ROOT / "line_resistance_sensitivity" / "Line_Resistance_Sensitivity_Results.md",
        folder / "source_reports" / "Line_Resistance_Sensitivity_Results.md",
    )


def build_catalog():
    catalog = pd.DataFrame([
        {"final_experiment_id": 1, "name": "方法贡献与物理有效性", "merged_original_experiments": 3, "master_rows": 7, "new_unique_platform_submissions": 3},
        {"final_experiment_id": 2, "name": "运行时间与提交策略", "merged_original_experiments": 2, "master_rows": 6, "new_unique_platform_submissions": 57},
        {"final_experiment_id": 3, "name": "独立重复与稳定性", "merged_original_experiments": 1, "master_rows": 5, "new_unique_platform_submissions": 9},
        {"final_experiment_id": 4, "name": "线路电阻敏感性", "merged_original_experiments": 1, "master_rows": 15, "new_unique_platform_submissions": 0},
    ])
    write_csv(catalog, OUT / "Final_Experiment_Catalog.csv")
    repeat_stats = read_csv("independent_repeats", "Independent_Repeat_Statistics.csv")
    resistance = read_csv("line_resistance_sensitivity", "Line_Resistance_Sensitivity_Summary.csv")
    fixed_resistance = resistance.loc[resistance["stage"] == "fixed_cim_modes"]
    key_metrics = pd.DataFrame([
        {"final_experiment_id": 1, "metric": "unique_configurations", "value": 7, "unit": "configurations", "note": "raw CIM plus six decoded/solver configurations"},
        {"final_experiment_id": 1, "metric": "decoded_final_feasibility", "value": 100.0, "unit": "percent", "note": "all decoded configurations pass 30/30 physical steps"},
        {"final_experiment_id": 1, "metric": "raw_cim_feasibility", "value": 33.333333, "unit": "percent", "note": "before physical decoding"},
        {"final_experiment_id": 1, "metric": "soft_cim_absorption_rate", "value": 72.921220, "unit": "percent", "note": "dynamic Max-Cut CIM plus soft decoder"},
        {"final_experiment_id": 2, "metric": "cim_1s_platform_runtime_total", "value": 46.970128, "unit": "ms", "note": "30 platform submissions"},
        {"final_experiment_id": 2, "metric": "cim_2s_platform_runtime_total", "value": 33.180896, "unit": "ms", "note": "15 platform submissions"},
        {"final_experiment_id": 2, "metric": "cim_5s_platform_runtime_total", "value": 46.454704, "unit": "ms", "note": "6 platform submissions"},
        {"final_experiment_id": 2, "metric": "cim_10s_platform_runtime_total", "value": 3.327672, "unit": "ms", "note": "3 platform submissions; paired interval comparison"},
        {"final_experiment_id": 2, "metric": "paired_10s_speed_ratio", "value": 46.970128 / 3.327672, "unit": "times", "note": "1s total divided by 10s total"},
        {"final_experiment_id": 2, "metric": "paired_final_feasibility", "value": 100.0, "unit": "percent", "note": "all four intervals pass 30/30 physical steps"},
        {"final_experiment_id": 3, "metric": "independent_repetitions", "value": 5, "unit": "runs", "note": "R01-R05"},
        {"final_experiment_id": 3, "metric": "absorption_rate_mean", "value": row_by(repeat_stats, "metric", "absorption_rate_percent")["mean"], "unit": "percent", "note": "five-run mean"},
        {"final_experiment_id": 3, "metric": "absorption_rate_sample_std", "value": row_by(repeat_stats, "metric", "absorption_rate_percent")["sample_std"], "unit": "percentage points", "note": "five-run sample standard deviation"},
        {"final_experiment_id": 3, "metric": "platform_runtime_mean", "value": row_by(repeat_stats, "metric", "platform_runtime_total_ms")["mean"], "unit": "ms", "note": "five-run mean of platform-reported total"},
        {"final_experiment_id": 4, "metric": "resistance_min", "value": fixed_resistance["resistance_ohm_per_km"].min(), "unit": "ohm/km", "note": "minus 20 percent"},
        {"final_experiment_id": 4, "metric": "resistance_max", "value": fixed_resistance["resistance_ohm_per_km"].max(), "unit": "ohm/km", "note": "plus 20 percent"},
        {"final_experiment_id": 4, "metric": "absorption_rate_at_resistance_min", "value": fixed_resistance.loc[fixed_resistance["resistance_ohm_per_km"].idxmin(), "absorption_rate_percent"], "unit": "percent", "note": "fixed CIM modes"},
        {"final_experiment_id": 4, "metric": "absorption_rate_at_resistance_max", "value": fixed_resistance.loc[fixed_resistance["resistance_ohm_per_km"].idxmax(), "absorption_rate_percent"], "unit": "percent", "note": "fixed CIM modes"},
        {"final_experiment_id": 4, "metric": "line_loss_at_resistance_min", "value": fixed_resistance.loc[fixed_resistance["resistance_ohm_per_km"].idxmin(), "line_loss_kWh"], "unit": "kWh", "note": "fixed CIM modes"},
        {"final_experiment_id": 4, "metric": "line_loss_at_resistance_max", "value": fixed_resistance.loc[fixed_resistance["resistance_ohm_per_km"].idxmax(), "line_loss_kWh"], "unit": "kWh", "note": "fixed CIM modes"},
    ])
    write_csv(key_metrics, OUT / "Final_Key_Metrics.csv")
    (OUT / "README.md").write_text(
        "# 已完成实验最终归并\n\n"
        "原7个已完成实验按可比较性归并为4个最终实验。原始结果目录未移动、未删除、未覆盖；本目录仅保存统一主表、来源清单和报告副本。\n\n"
        "| 最终编号 | 实验 | 原实验数 | 主表行数 | 新增且不重复的平台提交 |\n"
        "|---:|---|---:|---:|---:|\n"
        "| 1 | 方法贡献与物理有效性 | 3 | 7 | 3 |\n"
        "| 2 | 运行时间与提交策略 | 2 | 6 | 57 |\n"
        "| 3 | 独立重复与稳定性 | 1 | 5 | 9 |\n"
        "| 4 | 线路电阻敏感性 | 1 | 15 | 0 |\n"
        "| 合计 | 4个最终实验 | 7 | 33 | 69 |\n\n"
        "所有数据均为算法验证环境中的仿真结果，不是现场实测数据。扩大规模比较已取消，不计入已完成实验。\n",
        encoding="utf-8",
    )


def integrity_manifest():
    rows = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.name != "Integrity_Manifest.csv":
            rows.append({
                "relative_path": str(path.relative_to(OUT)),
                "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            })
    write_csv(pd.DataFrame(rows), OUT / "Integrity_Manifest.csv")


def validate():
    catalog = pd.read_csv(OUT / "Final_Experiment_Catalog.csv")
    if len(catalog) != 4:
        raise RuntimeError("Expected four consolidated experiments")
    if int(catalog["new_unique_platform_submissions"].sum()) != 69:
        raise RuntimeError("Unique platform submission total is not 69")
    if len(pd.read_csv(OUT / "Final_Key_Metrics.csv")) != 20:
        raise RuntimeError("Expected 20 final key metrics")
    expected_rows = {1: 7, 2: 6, 3: 5, 4: 15}
    for number, expected in expected_rows.items():
        path = next(OUT.glob(f"{number:02d}_*/Experiment_{number:02d}_Master_Comparison.csv"))
        actual = len(pd.read_csv(path))
        if actual != expected:
            raise RuntimeError(f"Experiment {number} rows: {actual}, expected {expected}")


def main():
    build_experiment_1()
    build_experiment_2()
    build_experiment_3()
    build_experiment_4()
    build_catalog()
    integrity_manifest()
    validate()
    print(OUT)
    print("Final experiments: 4; original completed experiments: 7; unique platform submissions: 69")


if __name__ == "__main__":
    main()
