from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
EXPECTED_SCALES = {"S01_1B1T2ESS", "S02_2B2T5ESS", "S03_3B3T10ESS", "S04_5B5T20ESS", "S05_8B8T40ESS"}
CLASSIC_METHODS = {"Ground_SC", "Gao2015", "k_flip", "MILP", "Genetic_Algorithm"}
ALL_METHODS = CLASSIC_METHODS | {"Quantum_QUBO"}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-platform", action="store_true")
    args = parser.parse_args()

    penalty = pd.read_csv(RESULTS / "penalty_sensitivity" / "Penalty_Sensitivity_Summary.csv")
    recommended = pd.read_csv(RESULTS / "penalty_sensitivity" / "Recommended_Hyperparameters.csv")
    require(len(penalty) == 9, f"expected 9 penalty combinations, found {len(penalty)}")
    require(len(recommended) == 1, f"expected one recommendation, found {len(recommended)}")
    ranked_penalty = penalty.sort_values(
        [
            "raw_constraint_violation_steps",
            "raw_mean_abs_balance_error_kW",
            "absorption_rate_percent",
            "wasted_energy_kWh",
        ],
        ascending=[True, True, False, True],
    )
    require(
        str(recommended.iloc[0]["experiment"])
        == str(ranked_penalty.iloc[0]["experiment"]),
        "recommendation does not follow the declared lexicographic rule",
    )
    require((penalty["postprocess_infeasible_steps"] == 0).all(), "post-processed penalty result contains infeasible steps")

    scales = pd.read_csv(RESULTS / "scale_ablation" / "Scale_Ablation_All_Results.csv")
    classic = scales[scales["method"].isin(CLASSIC_METHODS)]
    classic_pairs = set(zip(classic["scale"], classic["method"]))
    expected_classic = {(scale, method) for scale in EXPECTED_SCALES for method in CLASSIC_METHODS}
    require(classic_pairs == expected_classic, f"missing or duplicate classic scale-method pairs: {expected_classic ^ classic_pairs}")
    require(len(classic) == 25, f"expected 25 classic results, found {len(classic)}")
    require((classic[["infeasible_steps", "voltage_violations", "power_violations"]].fillna(0) == 0).all().all(), "classic result contains a constraint violation")

    manifest = pd.read_csv(ROOT / "scale_cases" / "scale_manifest.csv")
    require(set(manifest["scale"]) == EXPECTED_SCALES, "scale manifest does not contain the five expected scales")
    regen_values = classic.groupby("scale")["total_regen_kWh"].first()
    require(float(regen_values.max() - regen_values.min()) < 1e-9, "total regenerative energy differs between scales")

    if args.require_platform:
        quantum = scales[scales["method"] == "Quantum_QUBO"]
        require(len(quantum) == 5, f"expected 5 platform Quantum QUBO results, found {len(quantum)}")
        require(set(quantum["scale"]) == EXPECTED_SCALES, "platform results do not cover all scales")
        require((quantum["platform_submissions"] > 0).all(), "a Quantum QUBO result has no platform submission")
        require((quantum[["infeasible_steps", "voltage_violations", "power_violations"]].fillna(0) == 0).all().all(), "Quantum QUBO result contains a post-process constraint violation")
        all_pairs = set(zip(scales["scale"], scales["method"]))
        expected_pairs = {
            (scale, method)
            for scale in EXPECTED_SCALES
            for method in ALL_METHODS
        }
        require(
            len(scales) == 30 and all_pairs == expected_pairs,
            f"expected 30 complete scale-method pairs, found {len(scales)}",
        )
        require(
            scales[
                [
                    "total_regen_kWh",
                    "effective_absorbed_kWh",
                    "absorption_rate_percent",
                    "wasted_energy_kWh",
                    "total_solve_time_s",
                ]
            ].notna().all().all(),
            "a required scale metric is missing",
        )
        largest = quantum.loc[quantum["ess_stations"].idxmax()]
        require(
            int(largest["platform_submissions"]) == 22
            and int(largest["local_fallback_batches"]) == 8
            and str(largest["solver_backend_mix"]) == "CIM+QUBO_SCIP",
            "40 ESS backend provenance is not explicitly preserved",
        )
        require(
            not list(RESULTS.glob("scale_ablation/**/.*.partial.csv")),
            "a partial Quantum QUBO checkpoint remains after completion",
        )
        required_artifacts = [
            ROOT / "Experiment_Report_5_2_5_3.md",
            ROOT / "figures" / "Figure_5_2_Penalty_Sensitivity.png",
            ROOT / "figures" / "Figure_5_3_Scale_Ablation.png",
            ROOT.parent
            / "outputs"
            / "019f8796-224a-7cc3-a725-93f2e28383eb"
            / "QUBO_Sensitivity_and_Scale_Ablation.xlsx",
        ]
        require(
            all(path.is_file() and path.stat().st_size > 0 for path in required_artifacts),
            "a required final report, figure, or workbook is missing",
        )

    print("PASS: 9 penalty combinations and one constraint-minimal recommendation")
    print("PASS: five scale cases preserve total regenerative energy")
    print("PASS: 25 classic scale results are complete and post-process feasible")
    if args.require_platform:
        print("PASS: 30 all-algorithm scale results are complete and post-process feasible")
        print("PASS: 40 ESS provenance records 22 CIM and 8 SCIP fallback batches")
        print("PASS: final report, figures, and workbook exist")


if __name__ == "__main__":
    main()
