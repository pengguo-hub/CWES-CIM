"""Compare one-, two-, five-, and ten-second CIM submission intervals fairly.

Both arms use the same 30-second case, weights, decoder, and cross-batch
mode-switch objective.  Local SCIP is used for preflight only.  The platform
extension creates 15 + 6 uniquely named CIM tasks for the new two- and
five-second arms and requires an exact-count confirmation flag. Existing
one- and ten-second results are reused read-only.
"""

from __future__ import annotations

import argparse
from getpass import getpass
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
RESULTS_ROOT = EXPERIMENT_ROOT / "results"
RESULT_ROOT = RESULTS_ROOT / "batch_interval_comparison"
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"

ARMS = {
    "1s": {"batch_size": 1, "cim_key": "BATCH_COMPARE_1S", "local_key": "BATCH_LOCAL_1S"},
    "2s": {"batch_size": 2, "cim_key": "BATCH_COMPARE_2S", "local_key": "BATCH_LOCAL_2S"},
    "5s": {"batch_size": 5, "cim_key": "BATCH_COMPARE_5S", "local_key": "BATCH_LOCAL_5S"},
    "10s": {"batch_size": 10, "cim_key": "BATCH_COMPARE_10S", "local_key": "BATCH_LOCAL_10S"},
}
NEW_ARMS = ("2s", "5s")
REUSED_ARMS = ("1s", "10s")
EXPECTED_PLATFORM_SUBMISSIONS = 21


def result_dir(case_key):
    return RESULT_ROOT / case_key / "Quantum_QUBO"


def time_series_file(case_key, batch_size):
    return result_dir(case_key) / f"TimeSeries_Result_10ESS_{batch_size}sBatch.csv"


def batch_file(case_key, batch_size):
    return result_dir(case_key) / f"Batch_Summary_10ESS_{batch_size}sBatch.csv"


def timing_file(case_key):
    return result_dir(case_key) / "Platform_Result_Timing.csv"


def _snapshot_protected():
    snapshot = {}
    for path in sorted(RESULTS_ROOT.rglob("*")):
        if not path.is_file() or RESULT_ROOT in path.parents:
            continue
        snapshot[str(path.relative_to(RESULTS_ROOT))] = (
            path.stat().st_size,
            hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    return snapshot


def _check_protected(before):
    after = _snapshot_protected()
    changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
    if changed:
        raise RuntimeError("Protected result files changed: " + ", ".join(changed))


def _snapshot_reused_interval_results():
    snapshot = {}
    for arm in REUSED_ARMS:
        spec = ARMS[arm]
        for case_key in (spec["cim_key"], spec["local_key"]):
            base = RESULT_ROOT / case_key
            if not base.exists():
                continue
            for path in sorted(base.rglob("*")):
                if path.is_file():
                    snapshot[str(path.relative_to(RESULT_ROOT))] = (
                        path.stat().st_size,
                        hashlib.sha256(path.read_bytes()).hexdigest(),
                    )
    return snapshot


def _check_reused_interval_results(before):
    after = _snapshot_reused_interval_results()
    changed = sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path))
    if changed:
        raise RuntimeError("Existing 1s/10s result files changed: " + ", ".join(changed))


def environment(arm, backend, user_id=None, sdk_code=None):
    spec = ARMS[arm]
    case_key = spec["cim_key"] if backend == "cim" else spec["local_key"]
    values = os.environ.copy()
    values.update(
        BENCHMARK_CASE_KEY=case_key,
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND=backend,
        ESS_QUBO_BATCH_SIZE=str(spec["batch_size"]),
        ESS_QUBO_CROSS_BATCH_SWITCH="1",
        ESS_QUBO_BALANCE_WEIGHT="0.004",
        ESS_QUBO_SOC_DYNAMIC_WEIGHT="20.0",
        ESS_QUBO_SCIP_TIME_LIMIT_S="30",
        ESS_QUBO_RESUME="0",
        ESS_ABLATION_GRAPH_MODE="dynamic",
        ESS_ABLATION_ENABLE_MAXCUT="1",
        ESS_DISPATCH_QUBO_PRIORITY_BOOST="0.05",
        ESS_DECODER_MODE="soft",
    )
    if backend == "scip":
        values["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
        values.pop("KAIWU_USER_ID", None)
        values.pop("KAIWU_SDK_CODE", None)
    else:
        values.pop("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT", None)
        values["KAIWU_USER_ID"] = user_id
        values["KAIWU_SDK_CODE"] = sdk_code
    return values


def validate():
    missing = [path for path in (CASE_FILE, QUANTUM_SCRIPT) if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing input: " + ", ".join(map(str, missing)))
    case = pd.read_csv(CASE_FILE)
    if len(case) != 30:
        raise RuntimeError(f"Expected 30 time steps, found {len(case)}")
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    manifest = []
    for arm, spec in ARMS.items():
        batches = 30 // spec["batch_size"]
        manifest.append({
            "arm": arm,
            "batch_size_s": spec["batch_size"],
            "steps": 30,
            "variables_per_full_batch": spec["batch_size"] * 10,
            "source_platform_submissions": batches,
            "new_platform_submissions_this_extension": batches if arm in NEW_ARMS else 0,
            "result_origin": "new_extension" if arm in NEW_ARMS else "reused_existing_complete",
            "cross_batch_switch_enabled": True,
            "cim_case_key": spec["cim_key"],
            "local_case_key": spec["local_key"],
        })
    pd.DataFrame(manifest).to_csv(
        RESULT_ROOT / "Batch_Interval_Experiment_Manifest.csv", index=False, encoding="utf-8-sig"
    )
    print("Fairness control: cross-batch mode-switch penalty enabled for all four arms")
    print("Local preflight: 0 platform submissions")
    print("CIM extension: exactly 21 new submissions (15 two-second + 6 five-second)")
    print("Existing 1s and 10s results are reused read-only")


def run_local():
    protected = _snapshot_protected()
    reused = _snapshot_reused_interval_results()
    for arm in NEW_ARMS:
        spec = ARMS[arm]
        output = time_series_file(spec["local_key"], spec["batch_size"])
        if output.exists():
            frame = pd.read_csv(output)
            if len(frame) == 30:
                print(f"SKIP local {arm}: complete result exists")
                continue
        print(f"RUN local {arm} preflight")
        subprocess.run(
            [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)],
            cwd=QUANTUM_SCRIPT.parent,
            env=environment(arm, "scip"),
            check=True,
        )
        _check_protected(protected)
        _check_reused_interval_results(reused)
    collect("local")


def _task_name(arm, batch_id):
    spec = ARMS[arm]
    return (
        f"{spec['cim_key']}_{CASE_FILE.stem}_{spec['batch_size']}s_"
        f"unified_modules_qubo_numeric_B{batch_id:02d}"
    )


def _find_matrix_hash(task_name):
    candidates = sorted(
        Path("C:/tmp").glob(f"{task_name}_*_results.pkl"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"Kaiwu checkpoint not found for {task_name}")
    match = re.search(r"_([0-9a-f]{32})_results\.pkl$", candidates[0].name)
    if not match:
        raise RuntimeError(f"Cannot parse matrix hash: {candidates[0].name}")
    return match.group(1)


def _find_nested(value, key):
    if isinstance(value, dict):
        if key in value:
            return value[key]
        for child in value.values():
            found = _find_nested(child, key)
            if found is not None:
                return found
    elif isinstance(value, (list, tuple)):
        for child in value:
            found = _find_nested(child, key)
            if found is not None:
                return found
    return None


def query_platform_timing(arm, user_id, sdk_code):
    import kaiwu

    spec = ARMS[arm]
    batch_count = 30 // spec["batch_size"]
    kaiwu.license.init(user_id=user_id, sdk_code=sdk_code)
    rows = []
    kaiwu.common.CheckpointManager.save_dir = "C:/tmp"
    try:
        for batch_id in range(1, batch_count + 1):
            task_name = _task_name(arm, batch_id)
            matrix_hash = _find_matrix_hash(task_name)
            optimizer = kaiwu.cim.CIMOptimizer(task_name=task_name, wait=False)
            status = optimizer._query_task_status(task_name, matrix_hash)
            time_consume = _find_nested(status, "time_consume")
            if time_consume is None:
                raise RuntimeError(f"No platform time_consume for {task_name}")
            runtime_us = float(time_consume)
            rows.append({
                "batch_id": batch_id,
                "task_name": task_name,
                "matrix_hash": matrix_hash,
                "platform_time_consume_us": runtime_us,
                "platform_runtime_ms": runtime_us / 1000.0,
                "time_source": "sdk_task_status",
            })
    finally:
        kaiwu.common.CheckpointManager.save_dir = None
    pd.DataFrame(rows).to_csv(timing_file(spec["cim_key"]), index=False, encoding="utf-8-sig")


def run_cim(user_id, sdk_code):
    protected = _snapshot_protected()
    reused = _snapshot_reused_interval_results()
    for arm in NEW_ARMS:
        spec = ARMS[arm]
        output = time_series_file(spec["cim_key"], spec["batch_size"])
        expected_batches = 30 // spec["batch_size"]
        if output.exists():
            frame = pd.read_csv(output)
            if len(frame) != 30 or frame["batch_id"].nunique() != expected_batches:
                raise RuntimeError(f"Incomplete existing CIM result requires review: {arm}")
            print(f"SKIP CIM {arm}: complete result exists")
        else:
            print(f"RUN CIM {arm}: {expected_batches} unique platform tasks", flush=True)
            subprocess.run(
                [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)],
                cwd=QUANTUM_SCRIPT.parent,
                env=environment(arm, "cim", user_id, sdk_code),
                check=True,
            )
        query_platform_timing(arm, user_id, sdk_code)
        _check_protected(protected)
        _check_reused_interval_results(reused)
    collect("cim")


def _bool(frame, column):
    if column not in frame:
        return pd.Series(False, index=frame.index)
    values = frame[column]
    if values.dtype == bool:
        return values.fillna(False)
    return values.astype(str).str.lower().isin({"true", "1", "yes"})


def summarize(arm, backend):
    spec = ARMS[arm]
    case_key = spec["cim_key"] if backend == "cim" else spec["local_key"]
    frame = pd.read_csv(time_series_file(case_key, spec["batch_size"]))
    batches = pd.read_csv(batch_file(case_key, spec["batch_size"]))
    states = frame[[f"ess{i}_state" for i in range(1, 11)]].to_numpy(dtype=int)
    switches = int(np.count_nonzero(states[1:] != states[:-1]))
    violations = [
        "qubo_balance_violation", "qubo_substation_violation", "qubo_soc_violation",
        "soc_violation", "substation_violation", "loss_violation",
        "voltage_violation", "power_violation",
    ]
    platform_ms = np.nan
    platform_mean_ms = np.nan
    platform_median_ms = np.nan
    platform_max_ms = np.nan
    if backend == "cim":
        timing = pd.read_csv(timing_file(case_key))
        platform_values = pd.to_numeric(timing["platform_runtime_ms"], errors="raise")
        platform_ms = float(platform_values.sum())
        platform_mean_ms = float(platform_values.mean())
        platform_median_ms = float(platform_values.median())
        platform_max_ms = float(platform_values.max())
    continuity = []
    for index in range(len(batches) - 1):
        for ess in range(1, 11):
            continuity.append(abs(
                float(batches.iloc[index][f"end_soc_{ess}_percent"])
                - float(batches.iloc[index + 1][f"start_soc_{ess}_percent"])
            ))
    regen = float(frame["brake_power_kW"].sum()) / 3600.0
    effective = (
        float(frame["p_direct_kW"].sum())
        + float(frame["ess_charge_kW"].sum())
        - float(frame["loss_kW"].sum())
    ) / 3600.0
    qubo_total = float(batches["qubo_value"].sum())
    return {
        "backend": backend,
        "arm": arm,
        "batch_size_s": spec["batch_size"],
        "platform_submissions": len(batches) if backend == "cim" else 0,
        "variables_per_full_batch": int(batches["qubo_variable_count"].max()),
        "mean_qubo_density_percent": float(batches["qubo_density_percent"].mean()),
        "qubo_abs_coefficient_min": float(batches["qubo_abs_coefficient_min"].min()),
        "qubo_abs_coefficient_max": float(batches["qubo_abs_coefficient_max"].max()),
        "mean_quantization_retention_percent": float(batches["quantization_retention_percent"].mean()),
        "qubo_value_total": qubo_total,
        "qubo_value_per_step": qubo_total / 30.0,
        "mode_switch_count": switches,
        "mode_switch_rate_percent": switches / (29 * 10) * 100.0,
        "soc_boundary_max_abs_error_percent": max(continuity, default=0.0),
        "feasible_steps": int(_bool(frame, "feasible").sum()),
        "qubo_balance_violation_steps": int(_bool(frame, "qubo_balance_violation").sum()),
        "final_physical_violation_steps": int((~_bool(frame, "feasible")).sum()),
        "raw_violation_flags": int(sum(_bool(frame, name).sum() for name in violations)),
        "absorption_rate_percent": effective / regen * 100.0 if regen else 0.0,
        "effective_absorbed_kWh": effective,
        "grid_energy_kWh": float(frame["grid_power_kW"].sum()) / 3600.0,
        "wasted_energy_kWh": float(frame["wasted_power_kW"].sum()) / 3600.0,
        "line_loss_kWh": float(frame["loss_kW"].sum()) / 3600.0,
        "platform_runtime_total_ms": platform_ms,
        "platform_runtime_mean_per_task_ms": platform_mean_ms,
        "platform_runtime_median_per_task_ms": platform_median_ms,
        "platform_runtime_max_per_task_ms": platform_max_ms,
        "platform_runtime_per_step_ms": platform_ms / 30.0 if not pd.isna(platform_ms) else np.nan,
        "sdk_platform_wall_total_s": float(batches["phase_sdk_platform_wall_s"].sum()),
        "end_to_end_total_s": float(batches["phase_batch_end_to_end_s"].sum()),
    }


def collect(backend):
    rows = []
    for arm in ARMS:
        spec = ARMS[arm]
        key = spec["cim_key"] if backend == "cim" else spec["local_key"]
        if time_series_file(key, spec["batch_size"]).exists():
            rows.append(summarize(arm, backend))
    if not rows:
        raise RuntimeError(f"No {backend} results found")
    summary = pd.DataFrame(rows).sort_values("batch_size_s")
    output = RESULT_ROOT / f"Batch_Interval_{backend.upper()}_Summary.csv"
    summary.to_csv(output, index=False, encoding="utf-8-sig")
    if backend == "cim" and len(summary) == len(ARMS):
        indexed = summary.set_index("arm")
        one = indexed.loc["1s"]
        two = indexed.loc["2s"]
        five = indexed.loc["5s"]
        ten = indexed.loc["10s"]
        frames = {
            arm: pd.read_csv(time_series_file(spec["cim_key"], spec["batch_size"]))
            for arm, spec in ARMS.items()
        }
        state_columns = [f"ess{i}_state" for i in range(1, 11)]
        agreements = {
            arm: float(
                (
                    frames["1s"][state_columns].to_numpy(dtype=int)
                    == frames[arm][state_columns].to_numpy(dtype=int)
                ).mean() * 100.0
            )
            for arm in ARMS
        }
        platform_speed_ratio = one["platform_runtime_total_ms"] / ten["platform_runtime_total_ms"]
        absorption_delta = ten["absorption_rate_percent"] - one["absorption_rate_percent"]
        effective_delta = ten["effective_absorbed_kWh"] - one["effective_absorbed_kWh"]
        report = [
            "# 1秒、2秒、5秒与10秒量子平台提交间隔比较",
            "",
            "四组使用同一30秒仿真算例、同一QUBO权重、同一物理解码器，并统一计入跨批次模式切换惩罚。主时间指标采用平台返回的纯计算时间；SDK等待和端到端时间仅作补充。",
            "",
            "| 指标 | 1秒一批 | 2秒一批 | 5秒一批 | 10秒一批 |",
            "|---|---:|---:|---:|---:|",
        ]
        metrics = [
            ("平台提交次数", "platform_submissions", "count"),
            ("单批变量数", "variables_per_full_batch", "count"),
            ("平台纯计算总时间(ms)", "platform_runtime_total_ms", "float"),
            ("平台纯计算折算每步(ms)", "platform_runtime_per_step_ms", "float"),
            ("单任务平台时间中位数(ms)", "platform_runtime_median_per_task_ms", "float"),
            ("单任务平台时间最大值(ms)", "platform_runtime_max_per_task_ms", "float"),
            ("可行时间步", "feasible_steps", "steps"),
            ("QUBO代理平衡违约步数", "qubo_balance_violation_steps", "count"),
            ("模式切换次数", "mode_switch_count", "count"),
            ("消纳率(%)", "absorption_rate_percent", "float"),
            ("有效消纳(kWh)", "effective_absorbed_kWh", "float"),
            ("网侧取电(kWh)", "grid_energy_kWh", "float"),
            ("弃能(kWh)", "wasted_energy_kWh", "float"),
            ("量化非零项平均保留率(%)", "mean_quantization_retention_percent", "float"),
            ("与1秒组ESS状态一致率(%)", None, "agreement"),
        ]
        for label, key, kind in metrics:
            values = []
            for arm in ARMS:
                if kind == "agreement":
                    values.append(f"{agreements[arm]:.6f}")
                elif kind == "count":
                    values.append(str(int(indexed.loc[arm, key])))
                elif kind == "steps":
                    values.append(f"{int(indexed.loc[arm, key])}/30")
                else:
                    values.append(f"{indexed.loc[arm, key]:.6f}")
            report.append(f"| {label} | " + " | ".join(values) + " |")
        report.extend([
            "",
            "## 主要现象",
            "",
            f"- 10秒组的平台纯计算总时间为1秒组的{1.0 / platform_speed_ratio * 100.0:.3f}%，按本次平台记录约快{platform_speed_ratio:.3f}倍；2秒和5秒组给出提交频率与单任务规模之间的中间点。",
            f"- 平台纯计算时间未随批长单调下降：2秒组总计{two['platform_runtime_total_ms']:.6f} ms，5秒组总计{five['platform_runtime_total_ms']:.6f} ms。5秒组单任务中位数和最大值均高于2秒组，说明任务规模与单次平台波动共同影响总时间；单次实验不足以建立严格的批长—时间单调关系。",
            f"- 四组均使用统一物理解码器。1秒与10秒端点的消纳率差为{absorption_delta:.6f}个百分点、有效消纳差为{effective_delta:.6f} kWh。",
            "- ESS状态一致率用于判断批长增加后离散模式轨迹的变化；最终能量与可行性指标用于判断物理解码后的工程影响。",
            "- QUBO代理平衡违约不是最终物理违约；应同时核对最终可行步数和各类物理约束标志。",
            "",
            "## 解释边界",
            "",
            "- 这是同一30秒算例上的单次配对比较，不替代多次独立重复的统计推断。",
            "- 较短间隔提供更高控制刷新频率但产生更多平台任务；较长间隔在单个QUBO内联合优化更多相邻时刻。",
            "- 平台时间以SDK任务状态中的time_consume为准，不以端到端等待时间作为主结论。",
        ])
        (RESULT_ROOT / "Batch_Interval_Comparison_Results.md").write_text(
            "\n".join(report) + "\n", encoding="utf-8"
        )
    print(output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("validate", "run-local", "run-cim", "collect-local", "collect-cim"))
    parser.add_argument("--confirm-platform-submissions", type=int)
    parser.add_argument("--prompt-credentials", action="store_true")
    args = parser.parse_args()
    if args.command == "validate":
        validate()
    elif args.command == "run-local":
        validate()
        run_local()
    elif args.command == "run-cim":
        if args.confirm_platform_submissions != EXPECTED_PLATFORM_SUBMISSIONS:
            raise RuntimeError("CIM run requires --confirm-platform-submissions 21")
        if not args.prompt_credentials:
            raise RuntimeError("Use --prompt-credentials; credentials are never stored")
        user_id = input("Kaiwu user_id: ").strip()
        sdk_code = getpass("Kaiwu sdk_code: ").strip()
        if not user_id or not sdk_code:
            raise RuntimeError("Both Kaiwu credentials are required")
        validate()
        run_cim(user_id, sdk_code)
    elif args.command == "collect-local":
        collect("local")
    else:
        collect("cim")


if __name__ == "__main__":
    main()
