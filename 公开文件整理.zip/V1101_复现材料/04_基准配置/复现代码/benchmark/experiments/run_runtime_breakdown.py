"""Run and collect phase timing for one SCIP and one CIM configuration."""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
RESULTS_ROOT = EXPERIMENT_ROOT / "results"
RESULT_ROOT = RESULTS_ROOT / "runtime_breakdown"
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"
BATCH_SIZE = 10

ARMS = {
    "LOCAL_SCIP": "scip",
    "CIM": "cim",
}


def experiment_key(arm):
    return f"RUNTIME_{arm}"


def output_dir(arm):
    return RESULT_ROOT / experiment_key(arm) / "Quantum_QUBO"


def result_file(arm):
    return output_dir(arm) / "TimeSeries_Result_10ESS_10sBatch.csv"


def batch_file(arm):
    return output_dir(arm) / "Batch_Summary_10ESS_10sBatch.csv"


def _snapshot_protected():
    snapshot = {}
    for path in sorted(RESULTS_ROOT.rglob("*")):
        if not path.is_file() or RESULT_ROOT in path.parents:
            continue
        snapshot[str(path.relative_to(RESULTS_ROOT))] = (
            path.stat().st_size,
            hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    return snapshot


def environment(arm):
    backend = ARMS[arm]
    values = os.environ.copy()
    values.update(
        BENCHMARK_CASE_KEY=experiment_key(arm),
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND=backend,
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        ESS_QUBO_BALANCE_WEIGHT="0.004",
        ESS_QUBO_SOC_DYNAMIC_WEIGHT="20.0",
        ESS_QUBO_SCIP_TIME_LIMIT_S="30",
        ESS_QUBO_RESUME="0",
        ESS_ABLATION_GRAPH_MODE="dynamic",
        ESS_ABLATION_ENABLE_MAXCUT="1",
        ESS_DISPATCH_QUBO_PRIORITY_BOOST="0.05",
        ESS_DECODER_MODE="soft",
    )
    if backend == "scip":
        values["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
    else:
        values.pop("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT", None)
    return values


def run_one(arm, force=False):
    target = result_file(arm)
    if target.exists() and not force:
        print(f"SKIP {arm}: {target}")
        return
    protected_before = _snapshot_protected()
    subprocess.run(
        [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)],
        cwd=QUANTUM_SCRIPT.parent,
        env=environment(arm),
        check=True,
    )
    protected_after = _snapshot_protected()
    changed = sorted(
        path
        for path in set(protected_before) | set(protected_after)
        if protected_before.get(path) != protected_after.get(path)
    )
    if changed:
        raise RuntimeError("Protected result files changed: " + ", ".join(changed))


def collect():
    rows = []
    detail_rows = []
    phase_columns = [
        "phase_qubo_build_s",
        "phase_qubo_to_model_s",
        "phase_quantization_s",
        "phase_solver_framework_overhead_s",
        "phase_sdk_platform_wall_s",
        "phase_backend_solve_s",
        "phase_result_parse_s",
        "phase_graph_build_s",
        "phase_decoder_s",
        "phase_validation_s",
        "phase_batch_end_to_end_s",
    ]
    for arm, backend in ARMS.items():
        path = batch_file(arm)
        if not path.exists():
            continue
        batch = pd.read_csv(path)
        for column in phase_columns:
            if column not in batch:
                batch[column] = np.nan
        platform_path = output_dir(arm) / "Platform_Result_Timing.csv"
        platform_by_batch = {}
        if platform_path.exists():
            platform = pd.read_csv(platform_path)
            platform_by_batch = dict(
                zip(
                    pd.to_numeric(platform["batch_id"], errors="raise").astype(int),
                    pd.to_numeric(
                        platform["platform_runtime_ms"], errors="raise"
                    )
                    / 1000.0,
                )
            )
        for _, item in batch.iterrows():
            detail = {
                "arm": arm,
                "backend": backend.upper(),
                "batch_id": int(item["batch_id"]),
                "platform_reported_runtime_s": platform_by_batch.get(
                    int(item["batch_id"]), np.nan
                ),
            }
            detail.update({column: item[column] for column in phase_columns})
            detail_rows.append(detail)
        row = {
            "arm": arm,
            "backend": backend.upper(),
            "batches": len(batch),
            "platform_reported_runtime_s": (
                float(sum(platform_by_batch.values()))
                if platform_by_batch
                else np.nan
            ),
        }
        for column in phase_columns:
            row[column] = float(
                pd.to_numeric(batch[column], errors="coerce").sum(min_count=1)
            )
        rows.append(row)

    if not rows:
        raise RuntimeError("No runtime-breakdown results are available")
    summary = pd.DataFrame(rows)
    detail = pd.DataFrame(detail_rows)
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    summary.to_csv(
        RESULT_ROOT / "Runtime_Phase_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    detail.to_csv(
        RESULT_ROOT / "Runtime_Phase_By_Batch.csv",
        index=False,
        encoding="utf-8-sig",
    )
    report = [
        "# 运行时间分阶段拆分结果",
        "",
        "## 计时口径",
        "",
        "- QUBO构建、转换、量化、SDK/平台墙钟、结果解析、物理解码和物理校验分别计时。",
        "- CIM纯计算时间仅采用平台任务结果中的运行时长，不以SDK/平台墙钟或端到端时间替代。",
        "- SDK/平台墙钟包含通信、上传、排队和等待；当前SDK不提供这些子阶段的独立时间戳，因此合并报告。",
        "",
        "## 汇总",
        "",
        "| 后端 | 批数 | QUBO构建(s) | 量化(s) | 求解器/平台墙钟(s) | 平台报告计算(s) | 解码(s) | 校验(s) | 端到端(s) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary.iterrows():
        solver_wall = (
            row["phase_backend_solve_s"]
            if row["backend"] == "SCIP"
            else row["phase_sdk_platform_wall_s"]
        )
        platform_text = (
            "—"
            if pd.isna(row["platform_reported_runtime_s"])
            else f"{row['platform_reported_runtime_s']:.6f}"
        )
        report.append(
            f"| {row['backend']} | {int(row['batches'])} | "
            f"{row['phase_qubo_build_s']:.6f} | "
            f"{row['phase_quantization_s']:.6f} | "
            f"{solver_wall:.6f} | {platform_text} | "
            f"{row['phase_decoder_s']:.6f} | "
            f"{row['phase_validation_s']:.6f} | "
            f"{row['phase_batch_end_to_end_s']:.6f} |"
        )
    indexed = summary.set_index("arm")
    if "LOCAL_SCIP" in indexed.index and "CIM" in indexed.index:
        local = indexed.loc["LOCAL_SCIP"]
        cim = indexed.loc["CIM"]
        if not pd.isna(cim["platform_reported_runtime_s"]):
            compute_ratio = (
                local["phase_backend_solve_s"]
                / cim["platform_reported_runtime_s"]
            )
            wall_share = (
                cim["phase_sdk_platform_wall_s"]
                / cim["phase_batch_end_to_end_s"]
                * 100.0
            )
            decoder_share = (
                cim["phase_decoder_s"]
                / cim["phase_batch_end_to_end_s"]
                * 100.0
            )
            end_to_end_ratio = (
                cim["phase_batch_end_to_end_s"]
                / local["phase_batch_end_to_end_s"]
            )
            cim_detail = detail.loc[detail["arm"] == "CIM"]
            platform_values_ms = (
                cim_detail["platform_reported_runtime_s"] * 1000.0
            ).tolist()
            report.extend(
                [
                    "",
                    "## 派生结果",
                    "",
                    "- CIM三批平台计算时间分别为"
                    + "、".join(f"{value:.6f} ms" for value in platform_values_ms)
                    + f"，合计{cim['platform_reported_runtime_s'] * 1000.0:.6f} ms，平均{cim['platform_reported_runtime_s'] * 1000.0 / cim['batches']:.6f} ms/批。",
                    f"- 按各后端核心求解计时口径，SCIP求解器时间/CIM平台计算时间为{compute_ratio:.2f}倍；该数值不是完整应用加速比。",
                    f"- CIM运行的SDK/平台墙钟占端到端时间{wall_share:.2f}%，物理解码占{decoder_share:.2f}%。",
                    f"- CIM端到端时间是本地SCIP端到端时间的{end_to_end_ratio:.2f}倍，主要由平台通信、排队等待和物理解码造成。",
                ]
            )
    report.extend(
        [
            "",
            "## 解释边界",
            "",
            "- 平台计算时间取自Kaiwu任务状态的time_consume字段；通过第一实验QBoson PDF逐批交叉校准，确认该字段除以1000后为毫秒。",
            "- 平台计算时间与SDK/平台墙钟属于不同时间口径，应分别呈现。",
            "- 本结果来自单次30秒仿真算例，不用于推断长期平台排队分布。",
            "- 本结果来自仿真环境，不是线路现场实测数据。",
            "",
        ]
    )
    (RESULT_ROOT / "Runtime_Phase_Results.md").write_text(
        "\n".join(report), encoding="utf-8"
    )
    print(summary.to_string(index=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("validate", "run-local", "run-cim", "collect")
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--confirm-platform-submissions", type=int, default=0)
    args = parser.parse_args()
    if not CASE_FILE.exists() or not QUANTUM_SCRIPT.exists():
        raise FileNotFoundError("Runtime experiment inputs are incomplete")
    if args.command == "validate":
        print(f"Case: {CASE_FILE}")
        print("Local run: 0 platform submissions")
        print("CIM run: exactly 3 platform submissions")
        return
    if args.command == "run-local":
        run_one("LOCAL_SCIP", force=args.force)
        return
    if args.command == "run-cim":
        if args.confirm_platform_submissions != 3:
            raise RuntimeError(
                "CIM execution is locked. Pass --confirm-platform-submissions 3 "
                "only after explicit user confirmation."
            )
        run_one("CIM", force=args.force)
        return
    collect()


if __name__ == "__main__":
    main()
