from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

COLORS = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#000000"]
MARKERS = ["o", "s", "^", "D", "v", "P"]


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Microsoft YaHei", "SimHei", "Arial"],
            "axes.unicode_minus": False,
            "font.size": 8,
            "axes.labelsize": 9,
            "axes.titlesize": 9,
            "legend.fontsize": 7,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "pdf.fonttype": 42,
        }
    )


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIGURES / f"{stem}.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def penalty_figure() -> None:
    data = pd.read_csv(RESULTS / "penalty_sensitivity" / "Penalty_Sensitivity_Summary.csv")
    balances = sorted(data["balance_weight"].unique())
    socs = sorted(data["soc_dynamic_weight"].unique())
    metrics = [
        ("raw_constraint_violation_steps", "原始约束违例步数", "viridis_r", ".0f"),
        ("raw_mean_abs_balance_error_kW", "平均绝对平衡残差 (kW)", "cividis", ".0f"),
        ("absorption_rate_percent", "消纳率 (%)", "viridis", ".3f"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.35), constrained_layout=True)
    for panel, (ax, (metric, title, cmap, fmt)) in enumerate(zip(axes, metrics), start=1):
        matrix = data.pivot(index="soc_dynamic_weight", columns="balance_weight", values=metric).loc[socs, balances]
        image_options = {"cmap": cmap, "aspect": "auto"}
        if metric == "absorption_rate_percent":
            center = float(matrix.to_numpy().mean())
            image_options.update(vmin=center - 0.001, vmax=center + 0.001)
        image = ax.imshow(matrix.to_numpy(), **image_options)
        for row in range(len(socs)):
            for col in range(len(balances)):
                value = matrix.iloc[row, col]
                ax.text(col, row, format(value, fmt), ha="center", va="center", fontsize=7)
        ax.set_xticks(range(len(balances)), [f"{value:g}" for value in balances])
        ax.set_yticks(range(len(socs)), [f"{value:g}" for value in socs])
        ax.set_xlabel("平衡罚系数")
        if panel == 1:
            ax.set_ylabel("SOC 动态罚系数")
        ax.set_title(title)
        ax.text(-0.12, 1.08, chr(64 + panel), transform=ax.transAxes, fontweight="bold", fontsize=10)
        fig.colorbar(image, ax=ax, fraction=0.045, pad=0.03)
    save(fig, "Figure_5_2_Penalty_Sensitivity")


def scale_figure() -> None:
    data = pd.read_csv(RESULTS / "scale_ablation" / "Scale_Ablation_All_Results.csv")
    order = ["Ground_SC", "Gao2015", "k_flip", "MILP", "Genetic_Algorithm", "Quantum_QUBO"]
    available = [method for method in order if method in set(data["method"])]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    for index, method in enumerate(available):
        subset = data[data["method"] == method].sort_values("ess_stations")
        kwargs = dict(color=COLORS[index], marker=MARKERS[index], linewidth=1.3, markersize=4, label=method)
        axes[0].plot(subset["ess_stations"], subset["absorption_rate_percent"], **kwargs)
        axes[1].plot(subset["ess_stations"], subset["wasted_energy_kWh"], **kwargs)
        axes[2].plot(subset["ess_stations"], subset["total_solve_time_s"], **kwargs)
        if method == "Quantum_QUBO" and int(subset.iloc[-1]["ess_stations"]) == 40:
            axes[2].annotate(
                "22 CIM + 8 SCIP",
                xy=(40, subset.iloc[-1]["total_solve_time_s"]),
                xytext=(-58, -18),
                textcoords="offset points",
                fontsize=6.5,
                arrowprops={"arrowstyle": "-", "color": "#555555", "lw": 0.6},
            )
    axes[0].set_ylabel("消纳率 (%)")
    axes[1].set_ylabel("浪费能量 (kWh)")
    axes[2].set_ylabel("求解时间 (s, log)")
    axes[2].set_yscale("log")
    for panel, ax in enumerate(axes, start=1):
        ax.set_xlabel("ESS 站数量")
        ax.grid(True, which="major", color="#D9D9D9", linewidth=0.5)
        ax.spines[["top", "right"]].set_visible(False)
        ax.text(-0.14, 1.06, chr(64 + panel), transform=ax.transAxes, fontweight="bold", fontsize=10)
    axes[0].set_ylim(0, 105)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=3, frameon=False)
    save(fig, "Figure_5_3_Scale_Ablation")


if __name__ == "__main__":
    configure_style()
    penalty_figure()
    scale_figure()
    print(f"Figures written to {FIGURES}")
