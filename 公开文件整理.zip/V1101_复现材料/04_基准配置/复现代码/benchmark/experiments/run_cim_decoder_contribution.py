"""Replay one saved CIM solution through controlled decoder variants.

The experiment reuses the three CIM batches from the core-attribution run.
No platform task is submitted.  Existing module imports and physical models are
kept unchanged; this file is an experiment adapter and result collector only.
"""

from __future__ import annotations

import ast
import hashlib
import os
from pathlib import Path
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
CORE_RESULT_ROOT = Path(os.environ.get(
    "CIM_DECODER_SOURCE_ROOT",
    EXPERIMENT_ROOT / "results" / "core_attribution",
)).resolve()
SOURCE_DIR = (
    CORE_RESULT_ROOT
    / "CORE_D_dynamic_maxcut_cim"
    / "Quantum_QUBO"
)
SOURCE_FILE = SOURCE_DIR / "TimeSeries_Result_10ESS_10sBatch.csv"
SOURCE_PLATFORM_TIMING = SOURCE_DIR / "Platform_Result_Timing.csv"
RESULT_ROOT = Path(os.environ.get(
    "CIM_DECODER_RESULT_ROOT",
    EXPERIMENT_ROOT / "results" / "cim_decoder_contribution",
)).resolve()


def _load_quantum_module():
    # This is a strict offline replay.  Force-disable the SDK even when the
    # parent shell retains credentials or quantum-mode environment settings.
    os.environ["ESS_USE_QUANTUM_INTERFACE"] = "0"
    os.environ["ESS_QUANTUM_SOLVER_BACKEND"] = "scip"
    os.environ["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
    os.environ.setdefault("BENCHMARK_NUM_BRAKE", "3")
    os.environ.setdefault("BENCHMARK_NUM_TRACTION", "3")
    os.environ.setdefault("BENCHMARK_NUM_ESS", "10")
    os.environ.setdefault("BENCHMARK_SIM_TIME", "30")
    os.environ.setdefault("ESS_QUBO_BATCH_SIZE", "10")
    quantum_dir = ROOT / "Quantum_QUBO"
    sys.path.insert(0, str(quantum_dir))
    saved_argv = sys.argv[:]
    try:
        sys.argv = [sys.argv[0]]
        import quantum_10ess as quantum
    finally:
        sys.argv = saved_argv
    return quantum


def _bool_series(frame, column):
    if column not in frame:
        return pd.Series(False, index=frame.index)
    values = frame[column]
    if values.dtype == bool:
        return values.fillna(False)
    return values.astype(str).str.strip().str.lower().isin(
        {"1", "true", "yes"}
    )


def _snapshot_files(root, excluded):
    snapshot = {}
    if not root.exists():
        return snapshot
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == excluded or excluded in path.parents:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        snapshot[str(path.relative_to(root))] = (path.stat().st_size, digest)
    return snapshot


def _partition_from_row(row):
    partition = ast.literal_eval(str(row["partition"]))
    return [int(value) for value in partition]


def _replay_variant(quantum, case_data, source_data, variant, mode, boost):
    config = quantum.LocalMaxCutConfig()
    config.dispatch_decoder_mode = mode
    config.dispatch_qubo_priority_boost = float(boost)
    records = []

    for step_index, ((_, case_row), (_, source_row)) in enumerate(
        zip(case_data.iterrows(), source_data.iterrows())
    ):
        input_t = quantum.build_input_t(case_row, config.SOC_ess)
        quantum.update_config_from_case1_row(config, case_row)
        partition = _partition_from_row(source_row)
        transfer, next_soc = quantum.calculate_transfer_result_shared(
            config,
            partition,
            input_t,
            0.0,
        )

        ess_charge = np.asarray(transfer["ess_charge_power"], dtype=float)
        ess_discharge = np.asarray(transfer["ess_discharge_power"], dtype=float)
        actual_power = ess_charge + ess_discharge
        active_mask = actual_power > 1e-9
        raw_soc = np.asarray(next_soc, dtype=float)
        soc_violation = bool(
            np.any(raw_soc < config.SOC_min - 1e-9)
            or np.any(raw_soc > config.SOC_max + 1e-9)
        )
        config.SOC_ess = np.clip(raw_soc, config.SOC_min, config.SOC_max)

        power_balance_error = (
            float(transfer["brake_power"])
            + float(np.sum(ess_discharge))
            + float(transfer["grid_power"])
            - float(transfer["traction_power"])
            - float(np.sum(ess_charge))
            - float(transfer["discarded_power"])
            - float(transfer["line_loss"])
        )
        power_violation = bool(
            np.any(ess_charge > config.P_s_max_ch + 1e-9)
            or np.any(ess_discharge > config.P_s_max_dis + 1e-9)
        )
        substation_violation = bool(
            transfer["grid_power"] > config.substation_max_power_kW + 1e-9
        )
        loss_violation = bool(transfer["line_loss"] > config.P_loss_max + 1e-9)
        voltage_kv = float(transfer["min_voltage_V"]) / 1000.0
        voltage_violation = bool(
            voltage_kv < config.V_min - 1e-9
            or voltage_kv > config.V_max + 1e-9
        )
        feasible = bool(
            abs(power_balance_error) <= config.balance_tolerance_kW
            and not soc_violation
            and not power_violation
            and not substation_violation
            and not loss_violation
            and not voltage_violation
        )
        fallback_count = int(transfer["decoder_fallback_ess_count"])
        fallback_power = float(transfer["decoder_fallback_power_kW"])

        record = {
            "variant": variant,
            "time_s": int(source_row["time_s"]),
            "batch_id": int(source_row["batch_id"]),
            "decoder_mode": mode,
            "qubo_priority_boost": float(boost),
            "brake_power_kW": float(transfer["brake_power"]),
            "traction_power_kW": float(transfer["traction_power"]),
            "p_direct_kW": float(transfer["p_direct_power"]),
            "p_direct_received_kW": float(transfer.get("p_direct_received_kW", 0.0)),
            "ess_charge_sent_kW": float(transfer.get("ess_charge_sent_kW", 0.0)),
            "ess_discharge_received_kW": float(
                transfer.get("ess_discharge_received_kW", 0.0)
            ),
            "source_balance_error_kW": float(
                transfer.get("source_balance_error_kW", 0.0)
            ),
            "traction_balance_error_kW": float(
                transfer.get("traction_balance_error_kW", 0.0)
            ),
            "absorbed_brake_power_kW": float(transfer["absorbed_power"]),
            "wasted_power_kW": float(transfer["discarded_power"]),
            "grid_power_kW": float(transfer["grid_power"]),
            "line_loss_kW": float(transfer["line_loss"]),
            "ess_charge_kW": float(np.sum(ess_charge)),
            "ess_discharge_kW": float(np.sum(ess_discharge)),
            "active_ess_count": int(np.count_nonzero(active_mask)),
            "repaired_ess_count": fallback_count,
            "repaired_power_kW": fallback_power,
            "repair_step": fallback_count > 0,
            "power_balance_error_kW": power_balance_error,
            "soc_violation": soc_violation,
            "power_violation": power_violation,
            "substation_violation": substation_violation,
            "loss_violation": loss_violation,
            "voltage_violation": voltage_violation,
            "feasible": feasible,
            "soc_average_percent": float(np.mean(config.SOC_ess) * 100.0),
            "decoder_time_ms": float(
                transfer.get("decoder_optimizer_time_ms", 0.0)
            ),
            "slsqp_attempts": int(
                transfer.get("decoder_optimizer_attempts", 0)
            ),
            "slsqp_successes": int(
                transfer.get("decoder_successful_optimizations", 0)
            ),
            "slsqp_failures": int(
                transfer.get("decoder_optimizer_failures", 0)
            ),
            "slsqp_iterations": int(
                transfer.get("decoder_optimizer_iterations", 0)
            ),
            "slsqp_statuses": str(
                transfer.get("decoder_optimizer_statuses", "")
            ),
            "slsqp_messages": str(
                transfer.get("decoder_optimizer_messages", "")
            ),
            "partition": str(partition),
        }
        for ess_index in range(config.ess_count):
            ess_no = ess_index + 1
            record[f"ess{ess_no}_cim_mode"] = int(
                source_row[f"ess{ess_no}_state"]
            )
            record[f"ess{ess_no}_charge_kW"] = float(ess_charge[ess_index])
            record[f"ess{ess_no}_discharge_kW"] = float(
                ess_discharge[ess_index]
            )
            record[f"ess{ess_no}_soc_percent"] = float(
                config.SOC_ess[ess_index] * 100.0
            )
        records.append(record)

    return pd.DataFrame(records)


def _summarize_decoded(frame, dt):
    total_regen = float(frame["brake_power_kW"].sum()) * dt / 3600.0
    effective = float(frame["absorbed_brake_power_kW"].sum()) * dt / 3600.0
    active_count = int(frame["active_ess_count"].sum())
    repaired_count = int(frame["repaired_ess_count"].sum())
    total_ess_power = float(
        (frame["ess_charge_kW"] + frame["ess_discharge_kW"]).sum()
    )
    repaired_power = float(frame["repaired_power_kW"].sum())
    return {
        "time_steps": int(len(frame)),
        "final_feasible_steps": int(_bool_series(frame, "feasible").sum()),
        "final_feasibility_percent": float(
            _bool_series(frame, "feasible").mean() * 100.0
        ),
        "absorption_rate_percent": (
            effective / total_regen * 100.0 if total_regen > 0.0 else 0.0
        ),
        "effective_absorbed_kWh": effective,
        "grid_energy_kWh": float(frame["grid_power_kW"].sum()) * dt / 3600.0,
        "wasted_energy_kWh": float(frame["wasted_power_kW"].sum()) * dt / 3600.0,
        "line_loss_kWh": float(frame["line_loss_kW"].sum()) * dt / 3600.0,
        "repair_steps": int(_bool_series(frame, "repair_step").sum()),
        "repair_step_percent": float(
            _bool_series(frame, "repair_step").mean() * 100.0
        ),
        "active_ess_actions": active_count,
        "repaired_ess_actions": repaired_count,
        "count_mode_retention_percent": (
            max(0.0, 1.0 - repaired_count / active_count) * 100.0
            if active_count > 0
            else 100.0
        ),
        "total_ess_action_power_kW": total_ess_power,
        "repaired_power_kW": repaired_power,
        "power_mode_retention_percent": (
            max(0.0, 1.0 - repaired_power / total_ess_power) * 100.0
            if total_ess_power > 0.0
            else 100.0
        ),
        "slsqp_attempts": int(frame["slsqp_attempts"].sum()),
        "slsqp_successes": int(frame["slsqp_successes"].sum()),
        "slsqp_failures": int(frame["slsqp_failures"].sum()),
        "slsqp_iterations": int(frame["slsqp_iterations"].sum()),
        "decoder_time_s": float(frame["decoder_time_ms"].sum()) / 1000.0,
    }


def _raw_summary(source_data):
    balance_violations = int(
        _bool_series(source_data, "qubo_balance_violation").sum()
    )
    soc_violations = int(_bool_series(source_data, "qubo_soc_violation").sum())
    substation_violations = int(
        _bool_series(source_data, "qubo_substation_violation").sum()
    )
    raw_feasible = int(
        (
            ~_bool_series(source_data, "qubo_balance_violation")
            & ~_bool_series(source_data, "qubo_soc_violation")
            & ~_bool_series(source_data, "qubo_substation_violation")
        ).sum()
    )
    return {
        "variant": "raw_cim_modes",
        "decoder_mode": "none",
        "qubo_priority_boost": np.nan,
        "time_steps": int(len(source_data)),
        "raw_feasible_steps": raw_feasible,
        "raw_feasibility_percent": raw_feasible / len(source_data) * 100.0,
        "raw_balance_violation_steps": balance_violations,
        "raw_soc_violation_steps": soc_violations,
        "raw_substation_violation_steps": substation_violations,
        "final_feasible_steps": np.nan,
        "final_feasibility_percent": np.nan,
        "absorption_rate_percent": np.nan,
        "effective_absorbed_kWh": np.nan,
        "grid_energy_kWh": np.nan,
        "wasted_energy_kWh": np.nan,
        "line_loss_kWh": np.nan,
        "repair_steps": np.nan,
        "repair_step_percent": np.nan,
        "active_ess_actions": np.nan,
        "repaired_ess_actions": np.nan,
        "count_mode_retention_percent": np.nan,
        "total_ess_action_power_kW": np.nan,
        "repaired_power_kW": np.nan,
        "power_mode_retention_percent": np.nan,
        "slsqp_attempts": 0,
        "slsqp_successes": 0,
        "slsqp_failures": 0,
        "slsqp_iterations": 0,
        "decoder_time_s": 0.0,
    }


def main():
    if not SOURCE_FILE.exists():
        raise FileNotFoundError(f"Saved CIM result is missing: {SOURCE_FILE}")
    if not CASE_FILE.exists():
        raise FileNotFoundError(f"Benchmark case is missing: {CASE_FILE}")

    protected_before = _snapshot_files(
        EXPERIMENT_ROOT / "results", RESULT_ROOT
    )
    quantum = _load_quantum_module()
    case_data = quantum.load_benchmark_case(CASE_FILE)
    source_data = pd.read_csv(SOURCE_FILE)
    if len(case_data) != len(source_data):
        raise ValueError(
            f"Case/source length mismatch: {len(case_data)} vs {len(source_data)}"
        )

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    variants = (
        ("hard_cim_modes", "hard", 0.05),
        ("soft_cim_guided", "soft", 0.05),
        ("pure_physical_decoder", "soft", 0.0),
    )
    summary_rows = [_raw_summary(source_data)]
    decoded_frames = {}
    for variant, mode, boost in variants:
        frame = _replay_variant(
            quantum, case_data, source_data, variant, mode, boost
        )
        decoded_frames[variant] = frame
        frame.to_csv(
            RESULT_ROOT / f"{variant}_TimeSeries.csv",
            index=False,
            encoding="utf-8-sig",
        )
        row = {
            "variant": variant,
            "decoder_mode": mode,
            "qubo_priority_boost": boost,
            "raw_feasible_steps": np.nan,
            "raw_feasibility_percent": np.nan,
            "raw_balance_violation_steps": np.nan,
            "raw_soc_violation_steps": np.nan,
            "raw_substation_violation_steps": np.nan,
        }
        row.update(_summarize_decoded(frame, float(quantum.DT)))
        summary_rows.append(row)

    summary = pd.DataFrame(summary_rows)
    platform_time_s = np.nan
    if SOURCE_PLATFORM_TIMING.exists():
        timing = pd.read_csv(SOURCE_PLATFORM_TIMING)
        platform_time_s = float(
            pd.to_numeric(
                timing["platform_runtime_ms"], errors="coerce"
            ).fillna(0.0).sum()
            / 1000.0
        )
    summary["source_platform_submissions"] = 3
    summary["new_platform_submissions"] = 0
    summary["source_platform_runtime_s"] = platform_time_s
    summary.to_csv(
        RESULT_ROOT / "CIM_Decoder_Contribution_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    indexed = summary.set_index("variant")
    comparisons = (
        ("soft_minus_hard", "soft_cim_guided", "hard_cim_modes"),
        (
            "cim_guidance_soft_minus_pure",
            "soft_cim_guided",
            "pure_physical_decoder",
        ),
    )
    metrics = (
        "final_feasibility_percent",
        "absorption_rate_percent",
        "effective_absorbed_kWh",
        "grid_energy_kWh",
        "wasted_energy_kWh",
        "line_loss_kWh",
        "repair_step_percent",
        "count_mode_retention_percent",
        "power_mode_retention_percent",
        "decoder_time_s",
    )
    difference_rows = []
    for label, treatment, control in comparisons:
        row = {
            "comparison": label,
            "treatment": treatment,
            "control": control,
        }
        for metric in metrics:
            treatment_value = float(indexed.loc[treatment, metric])
            control_value = float(indexed.loc[control, metric])
            row[f"treatment_{metric}"] = treatment_value
            row[f"control_{metric}"] = control_value
            row[f"delta_{metric}"] = treatment_value - control_value
        difference_rows.append(row)
    differences = pd.DataFrame(difference_rows)
    differences.to_csv(
        RESULT_ROOT / "CIM_Decoder_Contribution_Deltas.csv",
        index=False,
        encoding="utf-8-sig",
    )

    source_soft = source_data
    replay_soft = decoded_frames["soft_cim_guided"]
    reproducibility = {
        "absorption_rate_percent_max_abs_diff": float(
            np.max(
                np.abs(
                    pd.to_numeric(
                        source_soft["absorption_rate_percent"], errors="coerce"
                    ).to_numpy()
                    - (
                        replay_soft["absorbed_brake_power_kW"].to_numpy()
                        / np.maximum(
                            replay_soft["brake_power_kW"].to_numpy(), 1e-12
                        )
                        * 100.0
                    )
                )
            )
        ),
        "grid_power_kW_max_abs_diff": float(
            np.max(
                np.abs(
                    pd.to_numeric(
                        source_soft["grid_power_kW"], errors="coerce"
                    ).to_numpy()
                    - replay_soft["grid_power_kW"].to_numpy()
                )
            )
        ),
        "line_loss_kW_max_abs_diff": float(
            np.max(
                np.abs(
                    pd.to_numeric(source_soft["loss_kW"], errors="coerce").to_numpy()
                    - replay_soft["line_loss_kW"].to_numpy()
                )
            )
        ),
    }
    pd.DataFrame([reproducibility]).to_csv(
        RESULT_ROOT / "Soft_Decoder_Replay_Verification.csv",
        index=False,
        encoding="utf-8-sig",
    )

    protected_after = _snapshot_files(
        EXPERIMENT_ROOT / "results", RESULT_ROOT
    )
    changed = sorted(
        path
        for path in set(protected_before) | set(protected_after)
        if protected_before.get(path) != protected_after.get(path)
    )
    audit_lines = [
        "# CIM与物理解码贡献拆分覆盖审计",
        "",
        f"- 新增量子平台提交：0；复用既有平台批次：3。",
        f"- 实验前受保护文件数：{len(protected_before)}。",
        f"- 实验后受保护文件数：{len(protected_after)}。",
        f"- 受保护文件变化数：{len(changed)}。",
        "- 新结果仅写入 `results/cim_decoder_contribution/`。",
        "- 平台运行时间沿用原QBoson任务报告，3批合计25.4459 ms。",
        "",
    ]
    if changed:
        audit_lines.extend(["## 发生变化的受保护文件", ""])
        audit_lines.extend(f"- `{path}`" for path in changed)
    else:
        audit_lines.append("结论：未覆盖或修改任何既有实验结果文件。")
    (RESULT_ROOT / "CIM_Decoder_No_Overwrite_Audit.md").write_text(
        "\n".join(audit_lines) + "\n", encoding="utf-8"
    )

    report_lines = [
        "# CIM与物理解码贡献拆分结果",
        "",
        "## 实验设置",
        "",
        "- 使用核心归因消融D组保存的同一组CIM原始分区。",
        "- 未新增量子平台提交；源平台3批运行时间合计25.4459 ms。",
        "- 硬模式解码禁止使用与CIM模式相反的ESS动作。",
        "- 软模式解码允许物理解码器修复CIM模式。",
        "- 纯物理解码将QUBO模式优先权重设为0，但仍以CIM模式计算保留率。",
        "",
        "## 结果汇总",
        "",
        "| 处理方式 | 原始/最终可行率(%) | 消纳率(%) | 网侧取电(kWh) | 网损(kWh) | 修复步数 | 数量保留率(%) | 功率保留率(%) | SLSQP失败/尝试 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    def display(value, digits=6):
        return "—" if pd.isna(value) else f"{float(value):.{digits}f}"

    for _, row in summary.iterrows():
        feasibility = (
            row["raw_feasibility_percent"]
            if row["variant"] == "raw_cim_modes"
            else row["final_feasibility_percent"]
        )
        report_lines.append(
            f"| {row['variant']} | {display(feasibility)} | "
            f"{display(row['absorption_rate_percent'])} | "
            f"{display(row['grid_energy_kWh'])} | "
            f"{display(row['line_loss_kWh'])} | "
            f"{display(row['repair_steps'], 0)} | "
            f"{display(row['count_mode_retention_percent'])} | "
            f"{display(row['power_mode_retention_percent'])} | "
            f"{int(row['slsqp_failures'])}/{int(row['slsqp_attempts'])} |"
        )
    hard = indexed.loc["hard_cim_modes"]
    soft = indexed.loc["soft_cim_guided"]
    pure = indexed.loc["pure_physical_decoder"]
    report_lines.extend([
        "",
        "注：原始CIM模式尚未映射为连续功率流，因此不报告其最终能量指标；其可行率仅按QUBO代理功率平衡、SOC和变电所约束判定。",
        "",
        "## 主要发现",
        "",
        f"- 原始CIM代理约束有10/30步通过，20步存在代理功率平衡违反。",
        f"- 硬模式连续解码后30/30步最终可行，但软模式使消纳率提高{soft['absorption_rate_percent'] - hard['absorption_rate_percent']:.6f}个百分点，并使网侧取电和网损各减少{hard['grid_energy_kWh'] - soft['grid_energy_kWh']:.6f} kWh。",
        f"- 软模式在{int(soft['repair_steps'])}/30步修复CIM模式，共修复{int(soft['repaired_ess_actions'])}个ESS动作；数量保留率为{soft['count_mode_retention_percent']:.6f}%，功率加权保留率为{soft['power_mode_retention_percent']:.6f}%。",
        f"- 软CIM引导与纯物理解码的消纳率仅相差{soft['absorption_rate_percent'] - pure['absorption_rate_percent']:.6f}个百分点；当前算例的最终能量性能主要由物理解码与连续优化决定。",
        "- 硬模式和软模式各出现1次SLSQP状态8（Positive directional derivative for linesearch），均发生在t=17；保留候选起点后该时间步最终仍通过物理可行性检查。",
        "",
        "## 解释边界",
        "",
        "- 本实验是对同一份CIM输出的确定性离线重放，不代表独立平台重复实验。",
        "- 当前数据来自仿真算例，不是线路现场实测数据。",
        "- 能量性能差异应结合硬模式可行率、修复比例和SLSQP诊断共同解释。",
        "",
    ])
    (RESULT_ROOT / "CIM_Decoder_Contribution_Results.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )

    print(summary.to_string(index=False))
    print(f"Saved results to: {RESULT_ROOT}")
    if changed:
        raise RuntimeError(
            "Protected experiment files changed: " + ", ".join(changed)
        )


if __name__ == "__main__":
    main()
