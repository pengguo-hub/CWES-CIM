import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";


const root = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.join(root, "..", "outputs", "019f8796-224a-7cc3-a725-93f2e28383eb");
const resultDir = path.join(root, "results");
const outputPath = path.join(outputDir, "QUBO_Sensitivity_and_Scale_Ablation.xlsx");

const COLORS = {
  navy: "#17365D",
  blue: "#2F75B5",
  teal: "#00A6A6",
  green: "#70AD47",
  orange: "#ED7D31",
  paleBlue: "#D9EAF7",
  paleGreen: "#E2F0D9",
  paleOrange: "#FCE4D6",
  lightGray: "#F2F2F2",
  white: "#FFFFFF",
  dark: "#1F1F1F",
};

function parseCsvLine(line) {
  const values = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    if (char === '"') {
      if (quoted && line[index + 1] === '"') {
        value += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      values.push(value);
      value = "";
    } else {
      value += char;
    }
  }
  values.push(value);
  return values;
}

function coerce(value) {
  if (value === "") return null;
  if (/^-?(?:\d+\.?\d*|\.\d+)(?:[Ee][+-]?\d+)?$/.test(value)) return Number(value);
  if (value === "True") return true;
  if (value === "False") return false;
  return value;
}

async function readCsv(relativePath) {
  const text = await fs.readFile(path.join(resultDir, relativePath), "utf8");
  const rows = text.replace(/^\uFEFF/, "").trim().split(/\r?\n/).map(parseCsvLine);
  return rows.map((row, rowIndex) => row.map((value) => (rowIndex === 0 ? value : coerce(value))));
}

function styleTitle(sheet, range, title) {
  sheet.mergeCells(range);
  const cell = sheet.getRange(range.split(":")[0]);
  cell.values = [[title]];
  cell.format = {
    fill: COLORS.navy,
    font: { bold: true, color: COLORS.white, size: 16 },
    verticalAlignment: "center",
  };
}

function styleHeader(range) {
  range.format = {
    fill: COLORS.blue,
    font: { bold: true, color: COLORS.white },
    wrapText: true,
    verticalAlignment: "center",
  };
}

function addDataSheet(workbook, name, title, rows, numberFormats = {}) {
  const sheet = workbook.worksheets.add(name);
  const columnCount = rows[0].length;
  styleTitle(sheet, `A1:${columnName(columnCount)}2`, title);
  sheet.getRangeByIndexes(3, 0, rows.length, columnCount).values = rows;
  styleHeader(sheet.getRangeByIndexes(3, 0, 1, columnCount));
  sheet.freezePanes.freezeRows(4);
  for (let column = 0; column < columnCount; column += 1) {
    sheet.getRangeByIndexes(3, column, rows.length, 1).format.columnWidth = column === 0 ? 22 : 16;
  }
  for (const [header, format] of Object.entries(numberFormats)) {
    const column = rows[0].indexOf(header);
    if (column >= 0 && rows.length > 1) {
      sheet.getRangeByIndexes(4, column, rows.length - 1, 1).format.numberFormat = format;
    }
  }
  return sheet;
}

function columnName(count) {
  let name = "";
  let value = count;
  while (value > 0) {
    value -= 1;
    name = String.fromCharCode(65 + (value % 26)) + name;
    value = Math.floor(value / 26);
  }
  return name;
}

const penaltyRows = await readCsv(path.join("penalty_sensitivity", "Penalty_Sensitivity_Summary.csv"));
const scaleRows = await readCsv(path.join("scale_ablation", "Scale_Ablation_All_Results.csv"));
const trendRows = await readCsv(path.join("scale_ablation", "Scale_Time_Trends.csv"));
const platformRows = await readCsv(path.join("scale_ablation", "Platform_Capacity_Observations.csv"));
const headers = scaleRows[0];
const scaleData = scaleRows.slice(1).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index]])));
const methods = ["Ground_SC", "Gao2015", "k_flip", "MILP", "Genetic_Algorithm", "Quantum_QUBO"];
const scales = [...new Set(scaleData.map((row) => row.scale))];

await fs.mkdir(outputDir, { recursive: true });
const workbook = Workbook.create();

const summary = workbook.worksheets.add("Key_Findings");
styleTitle(summary, "A1:L2", "QUBO 超参数敏感性与系统规模消融 — 关键结论");
summary.getRange("A4:D4").values = [["指标", "结果", "单位", "说明"]];
styleHeader(summary.getRange("A4:D4"));
const recommended = penaltyRows.slice(1).find((row) => row[penaltyRows[0].indexOf("recommended")] === true);
const bestScale = scaleData.filter((row) => row.ess_stations === 40).sort((a, b) => b.absorption_rate_percent - a.absorption_rate_percent)[0];
const quantumTrend = trendRows.slice(1).find((row) => row[0] === "Quantum_QUBO");
summary.getRange("A5:D11").values = [
  ["推荐功率平衡罚系数", recommended?.[1] ?? 0.004, "-", "原始约束违例优先"],
  ["推荐 SOC 动态罚系数", recommended?.[2] ?? 20, "-", "30 s 窗口中 SOC 未触界"],
  ["推荐组合原始违例", recommended?.[17] ?? 19, "步", "物理后处理后为 0"],
  ["40 ESS 最高消纳率", bestScale.absorption_rate_percent, "%", bestScale.method],
  ["Quantum QUBO 平台提交", scaleData.filter((row) => row.method === "Quantum_QUBO").reduce((sum, row) => sum + row.platform_submissions, 0), "次", "10 s/1 s 自适应批长"],
  ["40 ESS 本地后备批次", scaleData.find((row) => row.method === "Quantum_QUBO" && row.ess_stations === 40)?.local_fallback_batches ?? 0, "次", "平台持续 processing 后使用 SCIP"],
  ["Quantum 时间增长比", quantumTrend?.[4] ?? null, "倍", "40 ESS / 2 ESS 端到端时间"],
];
summary.getRange("B5:B6").format.numberFormat = "0.000000";
summary.getRange("B8:B9").format.numberFormat = "0.000";
summary.getRange("B11").format.numberFormat = "0.00";
summary.getRange("A4:D11").format.wrapText = true;
summary.getRange("A4:A11").format.columnWidth = 24;
summary.getRange("B4:B11").format.columnWidth = 16;
summary.getRange("C4:C11").format.columnWidth = 12;
summary.getRange("D4:D11").format.columnWidth = 34;

const chartStartRow = 13;
const absorptionTable = [["ESS", ...methods]];
const timeTable = [["ESS", ...methods]];
for (const scale of scales) {
  const rows = scaleData.filter((row) => row.scale === scale);
  const ess = rows[0]?.ess_stations;
  absorptionTable.push([ess, ...methods.map((method) => rows.find((row) => row.method === method)?.absorption_rate_percent ?? null)]);
  timeTable.push([
    ess,
    ...methods.map((method) => {
      const seconds = rows.find((row) => row.method === method)?.total_solve_time_s;
      return seconds == null ? null : Math.log10(Math.max(seconds, 1e-6));
    }),
  ]);
}
summary.getRangeByIndexes(chartStartRow - 1, 0, absorptionTable.length, absorptionTable[0].length).values = absorptionTable;
summary.getRangeByIndexes(chartStartRow - 1, 8, timeTable.length, timeTable[0].length).values = timeTable;
styleHeader(summary.getRangeByIndexes(chartStartRow - 1, 0, 1, absorptionTable[0].length));
styleHeader(summary.getRangeByIndexes(chartStartRow - 1, 8, 1, timeTable[0].length));
summary.getRangeByIndexes(chartStartRow, 1, absorptionTable.length - 1, methods.length).format.numberFormat = "0.000";
summary.getRangeByIndexes(chartStartRow, 9, timeTable.length - 1, methods.length).format.numberFormat = "0.000";
const absorptionChart = summary.charts.add("line", summary.getRangeByIndexes(chartStartRow - 1, 0, absorptionTable.length, absorptionTable[0].length));
absorptionChart.title = "消纳率随 ESS 规模变化";
absorptionChart.hasLegend = true;
absorptionChart.xAxis = { axisType: "textAxis" };
absorptionChart.yAxis = { numberFormatCode: "0.0", min: 0, max: 105 };
absorptionChart.setPosition("A21", "F38");
const timeChart = summary.charts.add("line", summary.getRangeByIndexes(chartStartRow - 1, 8, timeTable.length, timeTable[0].length));
timeChart.title = "求解时间随 ESS 规模变化 [log10(s)]";
timeChart.hasLegend = true;
timeChart.xAxis = { axisType: "textAxis" };
timeChart.yAxis = { numberFormatCode: "0.000" };
timeChart.setPosition("G21", "L38");
summary.mergeCells("A40:L41");
summary.getRange("A40").values = [[
  "注：40 ESS 的 Quantum QUBO 由 22 个平台 CIM 批次与 8 个本地 SCIP 后备批次构成；时间为端到端交付时间，不代表纯芯片计算时间。",
]];
summary.getRange("A40:L41").format = {
  fill: COLORS.paleOrange,
  font: { color: COLORS.dark, italic: true },
  wrapText: true,
  verticalAlignment: "center",
};

const protocol = workbook.worksheets.add("Protocol");
styleTitle(protocol, "A1:H2", "实验协议与指标定义");
protocol.getRange("A4:B4").values = [["项目", "设置或定义"]];
styleHeader(protocol.getRange("A4:B4"));
protocol.getRange("A5:B16").values = [
  ["数据来源", "Case4 前 30 s；不同规模保持各步制动/牵引总功率一致"],
  ["规模", "1B/1T/2ESS，2B/2T/5ESS，3B/3T/10ESS，5B/5T/20ESS，8B/8T/40ESS"],
  ["时间步长", "1 s，共 30 步"],
  ["QUBO 批长度", "2/5/10 ESS 用 10 s；20/40 ESS 在平台大批任务超时后改用 1 s"],
  ["QUBO 变量数/批", "20、50、100、20、40；20 ESS 为 30 个 CIM 批次，40 ESS 为 22 CIM + 8 SCIP"],
  ["有效消纳能量", "牵引直接利用与 ESS 有效充电之和"],
  ["消纳率", "有效消纳能量 / 再生制动总能量 × 100%"],
  ["浪费能量", "未被牵引负荷或 ESS 利用的再生制动能量"],
  ["求解时间", "经典算法为核心计算时间；Quantum QUBO 为端到端时间，40 ESS 包含后备求解"],
  ["罚系数推荐规则", "先最少原始约束违例，再最小平均平衡残差、最大消纳率、最小浪费"],
  ["数据性质", "算法仿真验证数据，不是现场实测数据"],
  ["解释原则", "平台排队/通信开销与核心计算时间不可直接等同"],
];
protocol.getRange("A4:A16").format.columnWidth = 24;
protocol.getRange("B4:B16").format.columnWidth = 80;
protocol.getRange("A4:B16").format.wrapText = true;

addDataSheet(workbook, "Penalty_Sensitivity", "5.2 QUBO 罚系数 3×3 交叉实验", penaltyRows, {
  balance_weight: "0.00000",
  soc_dynamic_weight: "0.0",
  raw_mean_abs_balance_error_kW: "0.00",
  absorption_rate_percent: "0.000000",
  total_solver_time_s: "0.000",
});
addDataSheet(workbook, "Scale_Ablation", "5.3 全算法系统规模消融结果", scaleRows, {
  total_regen_kWh: "0.000000",
  effective_absorbed_kWh: "0.000000",
  absorption_rate_percent: "0.000000",
  wasted_energy_kWh: "0.000000",
  grid_energy_kWh: "0.000000",
  line_loss_kWh: "0.000000",
  total_solve_time_s: "0.000",
});
addDataSheet(workbook, "Time_Trends", "求解时间规模趋势", trendRows, {
  observed_time_scaling_exponent: "0.000",
  smallest_scale_time_s: "0.000",
  largest_scale_time_s: "0.000",
  largest_to_smallest_time_ratio: "0.00",
});
const platformSheet = addDataSheet(workbook, "Platform_Limits", "平台容量与可恢复性观测", platformRows, {
  coupling_density_percent: "0.0",
  observation_limit_s: "0",
});
platformSheet.getRange("E4:E8").format.columnWidth = 22;
platformSheet.getRange("G4:G8").format.columnWidth = 34;
platformSheet.getRange("H4:H8").format.columnWidth = 38;

for (const sheetName of ["Key_Findings", "Protocol", "Penalty_Sensitivity", "Scale_Ablation", "Time_Trends", "Platform_Limits"]) {
  const preview = await workbook.render({
    sheetName,
    autoCrop: "all",
    scale: sheetName === "Scale_Ablation" ? 0.65 : 0.9,
    format: "png",
  });
  await fs.writeFile(
    path.join(outputDir, `${sheetName}_preview.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}
const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
console.log(outputPath);
