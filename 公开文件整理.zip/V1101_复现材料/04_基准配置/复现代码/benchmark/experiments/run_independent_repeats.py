"""Run and summarize five independent CIM repetitions.

R01 and R02 reuse completed CIM runs with the same configuration.  R03-R05
create uniquely named platform tasks.  The adapter keeps the existing model,
decoder, and module imports unchanged and only selects environment-backed
configuration and an isolated output directory.
"""

from __future__ import annotations

import argparse
from getpass import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import numpy as np
import pandas as pd
from scipy import stats


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
RESULTS_ROOT = EXPERIMENT_ROOT / "results"
RESULT_ROOT = RESULTS_ROOT / "independent_repeats"
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"
QUANTUM_SCRIPT = ROOT / "Quantum_QUBO" / "quantum_10ess.py"
BATCH_SIZE = 10
NEW_REPEATS = ("R03", "R04", "R05")

REPEATS = {
    "R01": {
        "origin": "reused_core_attribution",
        "case_key": "CORE_D_dynamic_maxcut_cim",
        "directory": RESULTS_ROOT
        / "core_attribution"
        / "CORE_D_dynamic_maxcut_cim"
        / "Quantum_QUBO",
        "new_submissions": 0,
    },
    "R02": {
        "origin": "reused_runtime_breakdown",
        "case_key": "RUNTIME_CIM",
        "directory": RESULTS_ROOT
        / "runtime_breakdown"
        / "RUNTIME_CIM"
        / "Quantum_QUBO",
        "new_submissions": 0,
    },
    **{
        repeat: {
            "origin": "new_independent_task",
            "case_key": f"INDEPENDENT_{repeat}",
            "directory": RESULT_ROOT / f"INDEPENDENT_{repeat}" / "Quantum_QUBO",
            "new_submissions": 3,
        }
        for repeat in NEW_REPEATS
    },
}


def time_series_file(repeat):
    return REPEATS[repeat]["directory"] / "TimeSeries_Result_10ESS_10sBatch.csv"


def batch_file(repeat):
    return REPEATS[repeat]["directory"] / "Batch_Summary_10ESS_10sBatch.csv"


def timing_file(repeat):
    return REPEATS[repeat]["directory"] / "Platform_Result_Timing.csv"


def _snapshot_protected():
    snapshot = {}
    for path in sorted(RESULTS_ROOT.rglob("*")):
        if not path.is_file() or RESULT_ROOT in path.parents:
            continue
        snapshot[str(path.relative_to(RESULTS_ROOT))] = (
            path.stat().st_size,
            hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    return snapshot


def _check_protected(before):
    after = _snapshot_protected()
    changed = sorted(
        path
        for path in set(before) | set(after)
        if before.get(path) != after.get(path)
    )
    if changed:
        raise RuntimeError("Protected result files changed: " + ", ".join(changed))


def environment(repeat, user_id=None, sdk_code=None):
    values = os.environ.copy()
    values.update(
        BENCHMARK_CASE_KEY=REPEATS[repeat]["case_key"],
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_SIM_TIME="30",
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND="cim",
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        ESS_QUBO_BALANCE_WEIGHT="0.004",
        ESS_QUBO_SOC_DYNAMIC_WEIGHT="20.0",
        ESS_QUBO_SCIP_TIME_LIMIT_S="30",
        ESS_QUBO_RESUME="0",
        ESS_ABLATION_GRAPH_MODE="dynamic",
        ESS_ABLATION_ENABLE_MAXCUT="1",
        ESS_DISPATCH_QUBO_PRIORITY_BOOST="0.05",
        ESS_DECODER_MODE="soft",
    )
    values.pop("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT", None)
    if user_id:
        values["KAIWU_USER_ID"] = user_id
    if sdk_code:
        values["KAIWU_SDK_CODE"] = sdk_code
    return values


def validate():
    missing = [path for path in (CASE_FILE, QUANTUM_SCRIPT) if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required input: " + ", ".join(map(str, missing)))
    for repeat in ("R01", "R02"):
        for path in (time_series_file(repeat), batch_file(repeat), timing_file(repeat)):
            if not path.exists():
                raise FileNotFoundError(f"Reusable {repeat} input is missing: {path}")
    case = pd.read_csv(CASE_FILE)
    if len(case) != 30:
        raise RuntimeError(f"Expected 30 time steps, found {len(case)}")
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    manifest = []
    for repeat, spec in REPEATS.items():
        manifest.append(
            {
                "repeat_id": repeat,
                "origin": spec["origin"],
                "case_key": spec["case_key"],
                "result_directory": str(spec["directory"]),
                "planned_batches": 3,
                "new_platform_submissions": spec["new_submissions"],
                "result_available": time_series_file(repeat).exists(),
                "platform_timing_available": timing_file(repeat).exists(),
            }
        )
    pd.DataFrame(manifest).to_csv(
        RESULT_ROOT / "Repeat_Source_Manifest.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("Configuration: dynamic graph + Max-Cut + CIM + soft decoder")
    complete = [repeat for repeat in REPEATS if time_series_file(repeat).exists()]
    pending = [repeat for repeat in NEW_REPEATS if not time_series_file(repeat).exists()]
    print("Reusable independent repetitions: R01, R02 (6 historical tasks)")
    print("Complete repetitions: " + ", ".join(complete))
    print("Pending repetitions: " + (", ".join(pending) if pending else "none"))
    print("Authorized new platform submissions for R03-R05: exactly 9")


def _task_prefix(repeat, batch_id):
    return (
        f"{REPEATS[repeat]['case_key']}_{CASE_FILE.stem}_{BATCH_SIZE}s_"
        f"unified_modules_qubo_numeric_B{batch_id:02d}"
    )


def _find_matrix_hash(task_name):
    cache_root = Path("C:/tmp")
    candidates = sorted(
        cache_root.glob(f"{task_name}_*_results.pkl"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"Kaiwu checkpoint not found for {task_name}")
    match = re.search(r"_([0-9a-f]{32})_results\.pkl$", candidates[0].name)
    if not match:
        raise RuntimeError(f"Cannot parse matrix hash: {candidates[0].name}")
    return match.group(1)


def _find_nested(value, key):
    if isinstance(value, dict):
        if key in value:
            return value[key]
        for child in value.values():
            found = _find_nested(child, key)
            if found is not None:
                return found
    elif isinstance(value, (list, tuple)):
        for child in value:
            found = _find_nested(child, key)
            if found is not None:
                return found
    return None


def query_platform_timing(repeat, user_id, sdk_code):
    import kaiwu

    kaiwu.license.init(user_id=user_id, sdk_code=sdk_code)
    rows = []
    kaiwu.common.CheckpointManager.save_dir = "C:/tmp"
    try:
        for batch_id in range(1, 4):
            task_name = _task_prefix(repeat, batch_id)
            matrix_hash = _find_matrix_hash(task_name)
            optimizer = kaiwu.cim.CIMOptimizer(task_name=task_name, wait=False)
            status = optimizer._query_task_status(task_name, matrix_hash)
            time_consume = _find_nested(status, "time_consume")
            if time_consume is None:
                raise RuntimeError(
                    f"Kaiwu task status has no time_consume for {task_name}: {status!r}"
                )
            runtime_us = float(time_consume)
            rows.append(
                {
                    "batch_id": batch_id,
                    "task_name": task_name,
                    "matrix_hash": matrix_hash,
                    "platform_time_consume_us": runtime_us,
                    "platform_runtime_ms": runtime_us / 1000.0,
                    "time_source": "sdk_task_status",
                }
            )
    finally:
        kaiwu.common.CheckpointManager.save_dir = None
    timing_file(repeat).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(
        timing_file(repeat), index=False, encoding="utf-8-sig"
    )


def run_new(user_id, sdk_code):
    protected_before = _snapshot_protected()
    for repeat in NEW_REPEATS:
        if time_series_file(repeat).exists():
            existing = pd.read_csv(time_series_file(repeat))
            if len(existing) != 30 or existing["batch_id"].nunique() != 3:
                raise RuntimeError(
                    f"Incomplete existing result requires manual review: {repeat}"
                )
            print(f"SKIP {repeat}: complete result already exists", flush=True)
        else:
            print(f"RUN {repeat}: 3 uniquely named CIM batches", flush=True)
            subprocess.run(
                [sys.executable, "-u", "-B", str(QUANTUM_SCRIPT), str(CASE_FILE)],
                cwd=QUANTUM_SCRIPT.parent,
                env=environment(repeat, user_id, sdk_code),
                check=True,
            )
        if not timing_file(repeat).exists():
            query_platform_timing(repeat, user_id, sdk_code)
        _check_protected(protected_before)
    collect()


def _bool_series(frame, column):
    if column not in frame:
        return pd.Series(False, index=frame.index)
    values = frame[column]
    if values.dtype == bool:
        return values.fillna(False)
    return values.astype(str).str.strip().str.lower().isin({"1", "true", "yes"})


def _numeric_sum(frame, column):
    if column not in frame:
        return 0.0
    return float(pd.to_numeric(frame[column], errors="coerce").fillna(0.0).sum())


def _partition_vector(frame):
    columns = [f"ess{index}_state" for index in range(1, 11)]
    missing = [column for column in columns if column not in frame]
    if missing:
        raise RuntimeError("Missing ESS mode columns: " + ", ".join(missing))
    return frame[columns].to_numpy(dtype=np.int8).reshape(-1)


def summarize_repeat(repeat):
    path = time_series_file(repeat)
    if not path.exists():
        return None, None
    frame = pd.read_csv(path)
    batch = pd.read_csv(batch_file(repeat))
    dt = 1.0
    if len(frame) > 1 and "time_s" in frame:
        diffs = np.diff(pd.to_numeric(frame["time_s"], errors="raise"))
        positive = diffs[diffs > 0]
        if len(positive):
            dt = float(np.median(positive))
    regen = _numeric_sum(frame, "brake_power_kW") * dt / 3600.0
    effective = (
        _numeric_sum(frame, "p_direct_kW")
        + _numeric_sum(frame, "ess_charge_kW")
        - _numeric_sum(frame, "loss_kW")
    ) * dt / 3600.0
    total_action_power = _numeric_sum(frame, "ess_charge_kW") + _numeric_sum(
        frame, "ess_discharge_kW"
    )
    repaired_power = _numeric_sum(frame, "decoder_fallback_power_kW")
    active_actions = 0
    for index in range(1, 11):
        action = pd.to_numeric(frame[f"ess{index}_charge_kW"], errors="coerce").fillna(0.0)
        action += pd.to_numeric(frame[f"ess{index}_discharge_kW"], errors="coerce").fillna(0.0)
        active_actions += int((action > 1e-9).sum())
    repaired_actions = int(round(_numeric_sum(frame, "decoder_fallback_ess_count")))
    batch_backends = batch["solver_backend"].astype(str).str.upper()
    backends = sorted(batch_backends.unique())
    platform = pd.read_csv(timing_file(repeat)) if timing_file(repeat).exists() else None
    platform_ms = (
        float(pd.to_numeric(platform["platform_runtime_ms"], errors="raise").sum())
        if platform is not None
        else np.nan
    )
    sdk_wall_s = (
        float(pd.to_numeric(batch["phase_sdk_platform_wall_s"], errors="coerce").sum(min_count=1))
        if "phase_sdk_platform_wall_s" in batch
        else float(pd.to_numeric(batch["cim_call_time_s"], errors="coerce").sum())
    )
    final_feasible = int(_bool_series(frame, "feasible").sum())
    row = {
        "repeat_id": repeat,
        "origin": REPEATS[repeat]["origin"],
        "time_steps": len(frame),
        "batches": int(frame["batch_id"].nunique()),
        "observed_backend_mix": "+".join(backends),
        "platform_successful_batches": int(len(platform)) if platform is not None else 0,
        "fallback_batches": int((batch_backends != "CIM").sum()),
        "final_feasible_steps": final_feasible,
        "final_feasibility_percent": final_feasible / len(frame) * 100.0,
        "raw_balance_violation_steps": int(_bool_series(frame, "qubo_balance_violation").sum()),
        "raw_soc_violation_steps": int(_bool_series(frame, "qubo_soc_violation").sum()),
        "raw_substation_violation_steps": int(_bool_series(frame, "qubo_substation_violation").sum()),
        "absorption_rate_percent": effective / regen * 100.0 if regen > 0 else 0.0,
        "effective_absorbed_kWh": effective,
        "grid_energy_kWh": _numeric_sum(frame, "grid_power_kW") * dt / 3600.0,
        "wasted_energy_kWh": _numeric_sum(frame, "wasted_power_kW") * dt / 3600.0,
        "line_loss_kWh": _numeric_sum(frame, "loss_kW") * dt / 3600.0,
        "repair_steps": int((_numeric_series(frame, "decoder_fallback_ess_count") > 0).sum()),
        "active_ess_actions": active_actions,
        "repaired_ess_actions": repaired_actions,
        "count_mode_retention_percent": max(0.0, 1.0 - repaired_actions / active_actions) * 100.0 if active_actions else 100.0,
        "power_mode_retention_percent": max(0.0, 1.0 - repaired_power / total_action_power) * 100.0 if total_action_power > 0 else 100.0,
        "slsqp_attempts": int(round(_numeric_sum(frame, "decoder_optimizer_attempts"))),
        "slsqp_failures": int(round(_numeric_sum(frame, "decoder_optimizer_failures"))),
        "platform_runtime_total_ms": platform_ms,
        "sdk_platform_wall_s": sdk_wall_s,
        "new_platform_submissions": REPEATS[repeat]["new_submissions"],
    }
    return row, _partition_vector(frame)


def _numeric_series(frame, column):
    if column not in frame:
        return pd.Series(0.0, index=frame.index)
    return pd.to_numeric(frame[column], errors="coerce").fillna(0.0)


def _statistics(summary, metrics):
    rows = []
    n = len(summary)
    for metric in metrics:
        values = pd.to_numeric(summary[metric], errors="coerce").dropna()
        if values.empty:
            continue
        mean = float(values.mean())
        std = float(values.std(ddof=1)) if len(values) > 1 else np.nan
        half_width = (
            float(stats.t.ppf(0.975, len(values) - 1) * std / np.sqrt(len(values)))
            if len(values) > 1
            else np.nan
        )
        rows.append(
            {
                "metric": metric,
                "n": len(values),
                "mean": mean,
                "sample_std": std,
                "ci95_lower": mean - half_width if len(values) > 1 else np.nan,
                "ci95_upper": mean + half_width if len(values) > 1 else np.nan,
                "median": float(values.median()),
                "q1": float(values.quantile(0.25)),
                "q3": float(values.quantile(0.75)),
                "minimum": float(values.min()),
                "maximum": float(values.max()),
            }
        )
    return pd.DataFrame(rows)


def collect():
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    partitions = {}
    for repeat in REPEATS:
        row, partition = summarize_repeat(repeat)
        if row is not None:
            summary_rows.append(row)
            partitions[repeat] = partition
    if not summary_rows:
        raise RuntimeError("No independent-repeat results are available")
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(
        RESULT_ROOT / "Independent_Repeat_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    metrics = [
        "final_feasibility_percent",
        "absorption_rate_percent",
        "effective_absorbed_kWh",
        "grid_energy_kWh",
        "wasted_energy_kWh",
        "line_loss_kWh",
        "count_mode_retention_percent",
        "power_mode_retention_percent",
        "platform_runtime_total_ms",
    ]
    aggregate = _statistics(summary, metrics)
    aggregate.to_csv(
        RESULT_ROOT / "Independent_Repeat_Statistics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    hamming_rows = []
    repeat_ids = list(partitions)
    for left_index, left in enumerate(repeat_ids):
        for right in repeat_ids[left_index + 1 :]:
            if len(partitions[left]) != len(partitions[right]):
                raise RuntimeError(f"Partition length mismatch: {left} vs {right}")
            distance = int(np.count_nonzero(partitions[left] != partitions[right]))
            hamming_rows.append(
                {
                    "repeat_a": left,
                    "repeat_b": right,
                    "different_bits": distance,
                    "total_bits": len(partitions[left]),
                    "normalized_hamming_distance": distance / len(partitions[left]),
                }
            )
    hamming = pd.DataFrame(hamming_rows)
    hamming.to_csv(
        RESULT_ROOT / "Independent_Repeat_Hamming.csv",
        index=False,
        encoding="utf-8-sig",
    )
    completed = len(summary)
    report = [
        "# 独立重复实验结果",
        "",
        "## 完成状态",
        "",
        f"- 已完成 {completed}/5 次独立重复。",
        f"- 当前纳入 {int(summary['batches'].sum())} 个CIM批次；平台计时完整批次为 {int(summary['platform_successful_batches'].sum())} 个。",
        f"- 新实验目录之外的既有结果受哈希保护，不允许覆盖。",
        "- R01与R02复用相同配置的既有独立任务；R03-R05使用唯一任务名重新提交。",
        "",
        "## 逐次结果",
        "",
        "| 重复 | 来源 | 可行率(%) | 消纳率(%) | 有效消纳(kWh) | 模式数量保留率(%) | 功率保留率(%) | 平台计算(ms) |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary.iterrows():
        platform_text = "—" if pd.isna(row["platform_runtime_total_ms"]) else f"{row['platform_runtime_total_ms']:.6f}"
        report.append(
            f"| {row['repeat_id']} | {row['origin']} | {row['final_feasibility_percent']:.6f} | "
            f"{row['absorption_rate_percent']:.6f} | {row['effective_absorbed_kWh']:.6f} | "
            f"{row['count_mode_retention_percent']:.6f} | {row['power_mode_retention_percent']:.6f} | {platform_text} |"
        )
    aggregate_indexed = aggregate.set_index("metric")
    labels = {
        "final_feasibility_percent": "最终可行率(%)",
        "absorption_rate_percent": "消纳率(%)",
        "effective_absorbed_kWh": "有效消纳(kWh)",
        "count_mode_retention_percent": "模式数量保留率(%)",
        "power_mode_retention_percent": "功率保留率(%)",
        "platform_runtime_total_ms": "平台计算时间(ms/次重复)",
    }
    report.extend(
        [
            "",
            "## 五次重复统计",
            "",
            "| 指标 | 均值 | 样本标准差 | 95%CI | 中位数 | 最小值 | 最大值 |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for metric, label in labels.items():
        row = aggregate_indexed.loc[metric]
        report.append(
            f"| {label} | {row['mean']:.6f} | {row['sample_std']:.6f} | "
            f"[{row['ci95_lower']:.6f}, {row['ci95_upper']:.6f}] | "
            f"{row['median']:.6f} | {row['minimum']:.6f} | {row['maximum']:.6f} |"
        )
    if not hamming.empty:
        hamming_values = hamming["normalized_hamming_distance"] * 100.0
        report.extend(
            [
                "",
                "## 稳定性观察",
                "",
                f"- 10组两两比较的ESS模式Hamming距离均值为{hamming_values.mean():.6f}%，范围为{hamming_values.min():.6f}%–{hamming_values.max():.6f}%。",
                f"- 尽管CIM二进制模式存在波动，消纳率样本标准差仅为{aggregate_indexed.loc['absorption_rate_percent', 'sample_std']:.6f}个百分点，有效消纳能量样本标准差仅为{aggregate_indexed.loc['effective_absorbed_kWh', 'sample_std']:.6f} kWh。",
                "- 这表明当前软物理解码器能够吸收一部分CIM模式随机性，使最终能量性能和可行性保持稳定；该结论限于当前单一30秒仿真场景。",
                f"- 5次重复的平台纯计算时间均值为{aggregate_indexed.loc['platform_runtime_total_ms', 'mean']:.6f} ms，范围为{aggregate_indexed.loc['platform_runtime_total_ms', 'minimum']:.6f}–{aggregate_indexed.loc['platform_runtime_total_ms', 'maximum']:.6f} ms。",
            ]
        )
    report.extend(
        [
            "",
            "## 统计口径",
            "",
            "- 报告均值、样本标准差、t分布95%置信区间、中位数、四分位数和极值。",
            "- CIM时间仅采用平台任务状态time_consume换算后的纯计算时间；SDK等待及端到端时间单独保留，不参与平台时间统计。",
            "- Hamming距离基于30个时间步、10个ESS的二进制模式序列计算。",
            (
                "- 已完成全部5次重复，当前统计为第五实验正式结果。"
                if completed == 5
                else "- 当前不足5次重复，统计结果仅为预统计。"
            ),
            "- 数据来自线路运行场景仿真，不是现场实测数据。",
            "",
        ]
    )
    (RESULT_ROOT / "Independent_Repeat_Results.md").write_text(
        "\n".join(report), encoding="utf-8"
    )
    print(summary.to_string(index=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("validate", "collect", "run-new"))
    parser.add_argument("--confirm-platform-submissions", type=int, default=0)
    parser.add_argument("--prompt-credentials", action="store_true")
    args = parser.parse_args()
    if args.command == "validate":
        validate()
        return
    if args.command == "collect":
        validate()
        collect()
        return
    if args.confirm_platform_submissions != 9:
        raise RuntimeError(
            "CIM execution is locked. Pass --confirm-platform-submissions 9 "
            "only after explicit user confirmation."
        )
    if not args.prompt_credentials:
        raise RuntimeError("Use --prompt-credentials so credentials are not stored in commands or files")
    user_id = input("Kaiwu user_id: ").strip()
    sdk_code = getpass("Kaiwu sdk_code: ").strip()
    if not user_id or not sdk_code:
        raise RuntimeError("Kaiwu credentials are required")
    run_new(user_id, sdk_code)


if __name__ == "__main__":
    main()
