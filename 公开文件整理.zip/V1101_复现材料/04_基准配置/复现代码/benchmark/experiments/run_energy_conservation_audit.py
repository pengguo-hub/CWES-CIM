"""Independent power, energy, and ESS SOC audit for saved experiment results.

This script is read-only with respect to existing experiments and never imports
or calls a solver, decoder, Kaiwu SDK, or simulation evaluation function.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd


EXPERIMENT_ROOT = Path(__file__).resolve().parent
RESULTS_ROOT = EXPERIMENT_ROOT / "results"
OUTPUT_ROOT = RESULTS_ROOT / "energy_conservation_audit"
CASE_FILE = EXPERIMENT_ROOT / "scale_cases" / "S03_3B3T10ESS_30s.csv"

DT_S = 1.0
ETA_CHARGE = 0.95
ETA_DISCHARGE = 0.95
SOC_MIN_PERCENT = 20.0
SOC_MAX_PERCENT = 90.0
POWER_BALANCE_TOLERANCE_KW = 1e-6
SOC_RECURRENCE_TOLERANCE_PERCENT = 1e-8
INPUT_MATCH_TOLERANCE_KW = 1e-9
POWER_LIMIT_TOLERANCE_KW = 1e-9
SIMULTANEOUS_POWER_TOLERANCE_KW = 1e-9
ESS_COUNT = 10

DATASETS = {
    "A_decoder_only": RESULTS_ROOT
    / "core_attribution/CORE_A_decoder_only/Quantum_QUBO/TimeSeries_Result_10ESS_10sBatch.csv",
    "B_static_maxcut_scip": RESULTS_ROOT
    / "core_attribution/CORE_B_static_maxcut_scip/Quantum_QUBO/TimeSeries_Result_10ESS_10sBatch.csv",
    "C_dynamic_maxcut_scip": RESULTS_ROOT
    / "core_attribution/CORE_C_dynamic_maxcut_scip/Quantum_QUBO/TimeSeries_Result_10ESS_10sBatch.csv",
    "D_dynamic_maxcut_cim": RESULTS_ROOT
    / "core_attribution/CORE_D_dynamic_maxcut_cim/Quantum_QUBO/TimeSeries_Result_10ESS_10sBatch.csv",
    "E_dynamic_no_maxcut_scip": RESULTS_ROOT
    / "core_attribution/CORE_E_dynamic_no_maxcut_scip/Quantum_QUBO/TimeSeries_Result_10ESS_10sBatch.csv",
    "decoder_hard_cim_modes": RESULTS_ROOT
    / "cim_decoder_contribution/hard_cim_modes_TimeSeries.csv",
    "decoder_soft_cim_guided": RESULTS_ROOT
    / "cim_decoder_contribution/soft_cim_guided_TimeSeries.csv",
    "decoder_pure_physical": RESULTS_ROOT
    / "cim_decoder_contribution/pure_physical_decoder_TimeSeries.csv",
}


def _snapshot_files(root, excluded):
    snapshot = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == excluded or excluded in path.parents:
            continue
        snapshot[str(path.relative_to(root))] = (
            path.stat().st_size,
            hashlib.sha256(path.read_bytes()).hexdigest(),
        )
    return snapshot


def _column(frame, *candidates):
    for candidate in candidates:
        if candidate in frame.columns:
            return candidate
    raise KeyError(f"None of the required columns exists: {candidates}")


def _numeric(frame, *candidates):
    return pd.to_numeric(frame[_column(frame, *candidates)], errors="raise")


def _case_parameters(case_data):
    first = case_data.iloc[0]
    parameters = []
    for ess_no in range(1, ESS_COUNT + 1):
        parameters.append(
            {
                "ess_no": ess_no,
                "capacity_kWh": float(first[f"ess_{ess_no}_capacity_kWh"]),
                "max_charge_kW": float(first[f"ess_{ess_no}_max_charge_kW"]),
                "max_discharge_kW": float(
                    first[f"ess_{ess_no}_max_discharge_kW"]
                ),
                "initial_soc_percent": float(
                    first[f"ess_{ess_no}_initial_soc_percent"]
                ),
            }
        )
    return parameters


def audit_dataset(dataset, path, case_data, ess_parameters):
    frame = pd.read_csv(path)
    if len(frame) != len(case_data):
        raise ValueError(
            f"{dataset}: result has {len(frame)} rows, case has {len(case_data)}"
        )
    frame = frame.sort_values("time_s").reset_index(drop=True)
    case = case_data.sort_values("time_s").reset_index(drop=True)

    brake = _numeric(frame, "brake_power_kW")
    traction = _numeric(frame, "traction_power_kW")
    charge = _numeric(frame, "ess_charge_kW", "ess_total_charge_kW")
    discharge = _numeric(frame, "ess_discharge_kW", "ess_total_discharge_kW")
    grid = _numeric(frame, "grid_power_kW")
    waste = _numeric(frame, "wasted_power_kW", "wasted_brake_power_kW")
    loss = _numeric(frame, "loss_kW", "line_loss_kW")

    case_brake = pd.to_numeric(case["brake_total_kW"], errors="raise")
    case_traction = pd.to_numeric(case["traction_total_kW"], errors="raise")
    brake_input_error = brake - case_brake
    traction_input_error = traction - case_traction
    residual = brake + grid + discharge - traction - charge - loss - waste
    flow_scale = (
        brake.abs()
        + grid.abs()
        + discharge.abs()
        + traction.abs()
        + charge.abs()
        + loss.abs()
        + waste.abs()
    ).clip(lower=1e-12)
    relative_residual = residual.abs() / flow_scale

    soc_records = []
    step_soc_max_residual = np.zeros(len(frame), dtype=float)
    step_soc_violation = np.zeros(len(frame), dtype=bool)
    step_power_limit_violation = np.zeros(len(frame), dtype=bool)
    step_simultaneous_violation = np.zeros(len(frame), dtype=bool)

    for parameter in ess_parameters:
        ess_no = parameter["ess_no"]
        charge_i = _numeric(
            frame,
            f"ess{ess_no}_charge_kW",
            f"ESS{ess_no}_charge_kW",
        ).to_numpy(dtype=float)
        discharge_i = _numeric(
            frame,
            f"ess{ess_no}_discharge_kW",
            f"ESS{ess_no}_discharge_kW",
        ).to_numpy(dtype=float)
        soc_i = _numeric(
            frame,
            f"soc_{ess_no}_percent",
            f"ESS{ess_no}_soc_percent",
            f"ess{ess_no}_soc_percent",
        ).to_numpy(dtype=float)
        previous_soc = float(parameter["initial_soc_percent"])
        for step_index in range(len(frame)):
            expected_soc = previous_soc + 100.0 * (
                ETA_CHARGE * charge_i[step_index] * DT_S / 3600.0
                - discharge_i[step_index]
                * DT_S
                / 3600.0
                / ETA_DISCHARGE
            ) / float(parameter["capacity_kWh"])
            soc_residual = soc_i[step_index] - expected_soc
            soc_bound_violation = bool(
                soc_i[step_index] < SOC_MIN_PERCENT - SOC_RECURRENCE_TOLERANCE_PERCENT
                or soc_i[step_index]
                > SOC_MAX_PERCENT + SOC_RECURRENCE_TOLERANCE_PERCENT
            )
            charge_limit_violation = bool(
                charge_i[step_index]
                > parameter["max_charge_kW"] + POWER_LIMIT_TOLERANCE_KW
            )
            discharge_limit_violation = bool(
                discharge_i[step_index]
                > parameter["max_discharge_kW"] + POWER_LIMIT_TOLERANCE_KW
            )
            simultaneous = bool(
                charge_i[step_index] > SIMULTANEOUS_POWER_TOLERANCE_KW
                and discharge_i[step_index] > SIMULTANEOUS_POWER_TOLERANCE_KW
            )
            step_soc_max_residual[step_index] = max(
                step_soc_max_residual[step_index], abs(soc_residual)
            )
            step_soc_violation[step_index] |= soc_bound_violation
            step_power_limit_violation[step_index] |= (
                charge_limit_violation or discharge_limit_violation
            )
            step_simultaneous_violation[step_index] |= simultaneous
            soc_records.append(
                {
                    "dataset": dataset,
                    "time_s": int(frame.loc[step_index, "time_s"]),
                    "ess_no": ess_no,
                    "previous_soc_percent": previous_soc,
                    "reported_soc_percent": soc_i[step_index],
                    "expected_soc_percent": expected_soc,
                    "soc_recurrence_residual_percent": soc_residual,
                    "charge_kW": charge_i[step_index],
                    "discharge_kW": discharge_i[step_index],
                    "soc_recurrence_pass": abs(soc_residual)
                    <= SOC_RECURRENCE_TOLERANCE_PERCENT,
                    "soc_bound_violation": soc_bound_violation,
                    "charge_limit_violation": charge_limit_violation,
                    "discharge_limit_violation": discharge_limit_violation,
                    "simultaneous_charge_discharge": simultaneous,
                }
            )
            previous_soc = soc_i[step_index]

    detail = pd.DataFrame(
        {
            "dataset": dataset,
            "time_s": pd.to_numeric(frame["time_s"], errors="raise").astype(int),
            "brake_power_kW": brake,
            "grid_power_kW": grid,
            "ess_discharge_kW": discharge,
            "traction_power_kW": traction,
            "ess_charge_kW": charge,
            "line_loss_kW": loss,
            "wasted_power_kW": waste,
            "power_balance_residual_kW": residual,
            "power_balance_abs_error_kW": residual.abs(),
            "power_balance_relative_error": relative_residual,
            "power_balance_pass": residual.abs()
            <= POWER_BALANCE_TOLERANCE_KW,
            "brake_input_error_kW": brake_input_error,
            "traction_input_error_kW": traction_input_error,
            "input_match_pass": (
                brake_input_error.abs() <= INPUT_MATCH_TOLERANCE_KW
            )
            & (traction_input_error.abs() <= INPUT_MATCH_TOLERANCE_KW),
            "max_soc_recurrence_residual_percent": step_soc_max_residual,
            "soc_recurrence_pass": step_soc_max_residual
            <= SOC_RECURRENCE_TOLERANCE_PERCENT,
            "soc_bound_violation": step_soc_violation,
            "power_limit_violation": step_power_limit_violation,
            "simultaneous_charge_discharge": step_simultaneous_violation,
        }
    )
    detail["audit_pass"] = (
        detail["power_balance_pass"]
        & detail["input_match_pass"]
        & detail["soc_recurrence_pass"]
        & ~detail["soc_bound_violation"]
        & ~detail["power_limit_violation"]
        & ~detail["simultaneous_charge_discharge"]
    )

    component_totals = {
        "dataset": dataset,
        "brake_energy_kWh": float(brake.sum()) * DT_S / 3600.0,
        "grid_energy_kWh": float(grid.sum()) * DT_S / 3600.0,
        "ess_discharge_energy_kWh": float(discharge.sum()) * DT_S / 3600.0,
        "traction_energy_kWh": float(traction.sum()) * DT_S / 3600.0,
        "ess_charge_energy_kWh": float(charge.sum()) * DT_S / 3600.0,
        "line_loss_energy_kWh": float(loss.sum()) * DT_S / 3600.0,
        "wasted_energy_kWh": float(waste.sum()) * DT_S / 3600.0,
        "cumulative_energy_closure_error_kWh": float(residual.sum())
        * DT_S
        / 3600.0,
        "absolute_residual_energy_kWh": float(residual.abs().sum())
        * DT_S
        / 3600.0,
    }
    summary = {
        "dataset": dataset,
        "time_steps": len(frame),
        "audit_pass_steps": int(detail["audit_pass"].sum()),
        "audit_pass_percent": float(detail["audit_pass"].mean() * 100.0),
        "power_balance_violation_steps": int(
            (~detail["power_balance_pass"]).sum()
        ),
        "input_mismatch_steps": int((~detail["input_match_pass"]).sum()),
        "soc_recurrence_violation_steps": int(
            (~detail["soc_recurrence_pass"]).sum()
        ),
        "soc_bound_violation_steps": int(detail["soc_bound_violation"].sum()),
        "power_limit_violation_steps": int(
            detail["power_limit_violation"].sum()
        ),
        "simultaneous_charge_discharge_steps": int(
            detail["simultaneous_charge_discharge"].sum()
        ),
        "max_power_balance_abs_error_kW": float(residual.abs().max()),
        "mean_power_balance_abs_error_kW": float(residual.abs().mean()),
        "p95_power_balance_abs_error_kW": float(
            residual.abs().quantile(0.95)
        ),
        "max_power_balance_relative_error": float(relative_residual.max()),
        "max_soc_recurrence_abs_error_percent": float(
            step_soc_max_residual.max()
        ),
        **{
            key: value
            for key, value in component_totals.items()
            if key != "dataset"
        },
    }
    return detail, pd.DataFrame(soc_records), summary, component_totals


def main():
    missing = [str(path) for path in DATASETS.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing audit inputs:\n" + "\n".join(missing))
    case_data = pd.read_csv(CASE_FILE)
    ess_parameters = _case_parameters(case_data)
    protected_before = _snapshot_files(RESULTS_ROOT, OUTPUT_ROOT)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    details = []
    soc_details = []
    summaries = []
    components = []
    for dataset, path in DATASETS.items():
        detail, soc_detail, summary, component = audit_dataset(
            dataset, path, case_data, ess_parameters
        )
        details.append(detail)
        soc_details.append(soc_detail)
        summaries.append(summary)
        components.append(component)

    detail_frame = pd.concat(details, ignore_index=True)
    soc_frame = pd.concat(soc_details, ignore_index=True)
    summary_frame = pd.DataFrame(summaries)
    component_frame = pd.DataFrame(components)
    anomaly_frame = detail_frame.loc[~detail_frame["audit_pass"]].copy()

    detail_frame.to_csv(
        OUTPUT_ROOT / "Energy_SOC_Audit_Detail.csv",
        index=False,
        encoding="utf-8-sig",
    )
    soc_frame.to_csv(
        OUTPUT_ROOT / "ESS_SOC_Recurrence_Audit.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary_frame.to_csv(
        OUTPUT_ROOT / "Energy_SOC_Audit_Summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    component_frame.to_csv(
        OUTPUT_ROOT / "Energy_Component_Totals.csv",
        index=False,
        encoding="utf-8-sig",
    )
    anomaly_frame.to_csv(
        OUTPUT_ROOT / "Energy_SOC_Audit_Anomalies.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(
        [
            ("dt_s", DT_S, "s"),
            ("eta_charge", ETA_CHARGE, "-"),
            ("eta_discharge", ETA_DISCHARGE, "-"),
            ("soc_min_percent", SOC_MIN_PERCENT, "%"),
            ("soc_max_percent", SOC_MAX_PERCENT, "%"),
            ("power_balance_tolerance", POWER_BALANCE_TOLERANCE_KW, "kW"),
            (
                "soc_recurrence_tolerance",
                SOC_RECURRENCE_TOLERANCE_PERCENT,
                "percentage point",
            ),
        ],
        columns=["parameter", "value", "unit"],
    ).to_csv(
        OUTPUT_ROOT / "Audit_Parameters.csv", index=False, encoding="utf-8-sig"
    )

    all_pass = bool((summary_frame["audit_pass_steps"] == 30).all())
    report_lines = [
        "# 逐时能量守恒与SOC独立审计结果",
        "",
        "## 审计范围与方法",
        "",
        "- 审计第一实验A-E组以及第二实验的硬模式、软模式和纯物理解码结果，共8套、240个时间步。",
        "- 本程序不导入求解器、物理解码器、仿真评价函数或Kaiwu SDK，未调用CIM平台。",
        "- 独立验证逐时功率闭合、累计能量闭合、原始输入一致性、10个ESS的SOC递推、SOC边界、功率上限及同时充放电。",
        f"- 功率闭合容差为{POWER_BALANCE_TOLERANCE_KW:g} kW；SOC递推容差为{SOC_RECURRENCE_TOLERANCE_PERCENT:g}个百分点。",
        "",
        "## 汇总结果",
        "",
        "| 数据集 | 通过步数 | 功率平衡异常 | SOC递推异常 | SOC越界 | 功率越界 | 同时充放电 | 最大功率残差(kW) | 累计闭合误差(kWh) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary_frame.iterrows():
        report_lines.append(
            f"| {row['dataset']} | {int(row['audit_pass_steps'])}/30 | "
            f"{int(row['power_balance_violation_steps'])} | "
            f"{int(row['soc_recurrence_violation_steps'])} | "
            f"{int(row['soc_bound_violation_steps'])} | "
            f"{int(row['power_limit_violation_steps'])} | "
            f"{int(row['simultaneous_charge_discharge_steps'])} | "
            f"{row['max_power_balance_abs_error_kW']:.3e} | "
            f"{row['cumulative_energy_closure_error_kWh']:.3e} |"
        )
    report_lines.extend(
        [
            "",
            "## 审计结论",
            "",
            (
                "- 8套结果的全部240个时间步均通过独立审计。"
                if all_pass
                else "- 存在未通过审计的数据集或时间步，详见异常明细。"
            ),
            f"- 全部数据集最大逐时功率闭合绝对误差为{summary_frame['max_power_balance_abs_error_kW'].max():.3e} kW。",
            f"- 全部数据集最大累计能量闭合误差绝对值为{summary_frame['cumulative_energy_closure_error_kWh'].abs().max():.3e} kWh。",
            f"- 全部ESS的最大SOC递推绝对误差为{summary_frame['max_soc_recurrence_abs_error_percent'].max():.3e}个百分点。",
            f"- 异常明细共{len(anomaly_frame)}行。",
            "- 本结果来自仿真算例，不是线路现场实测数据。",
            "",
        ]
    )
    (OUTPUT_ROOT / "Energy_SOC_Audit_Results.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )

    protected_after = _snapshot_files(RESULTS_ROOT, OUTPUT_ROOT)
    changed = sorted(
        path
        for path in set(protected_before) | set(protected_after)
        if protected_before.get(path) != protected_after.get(path)
    )
    audit_lines = [
        "# 逐时能量守恒审计覆盖检查",
        "",
        "- 新增量子平台提交：0。",
        f"- 实验前受保护文件数：{len(protected_before)}。",
        f"- 实验后受保护文件数：{len(protected_after)}。",
        f"- 受保护文件变化数：{len(changed)}。",
        "- 新文件仅写入 `results/energy_conservation_audit/`。",
        "",
    ]
    if changed:
        audit_lines.extend(f"- `{path}`" for path in changed)
    else:
        audit_lines.append("结论：未覆盖或修改任何既有实验结果文件。")
    (OUTPUT_ROOT / "Energy_SOC_No_Overwrite_Audit.md").write_text(
        "\n".join(audit_lines) + "\n", encoding="utf-8"
    )

    print(summary_frame.to_string(index=False))
    print(f"Anomalies: {len(anomaly_frame)}")
    print(f"Saved results to: {OUTPUT_ROOT}")
    if changed:
        raise RuntimeError("Protected files changed: " + ", ".join(changed))
    if not all_pass:
        raise RuntimeError("One or more datasets failed the independent audit")


if __name__ == "__main__":
    main()
