"""Run all algorithms on variable train/ESS scales and collect metrics."""

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ROOT = Path(__file__).resolve().parent
CASE_DIR = EXPERIMENT_ROOT / "scale_cases"
MANIFEST_FILE = CASE_DIR / "scale_manifest.csv"
RESULT_ROOT = Path(
    os.environ.get(
        "REPRO_SCALE_RESULT_ROOT",
        EXPERIMENT_ROOT / "results" / "scale_ablation",
    )
).resolve()
SENSITIVITY_RECOMMENDATION = Path(
    os.environ.get(
        "REPRO_PENALTY_RECOMMENDATION",
        EXPERIMENT_ROOT
        / "results"
        / "penalty_sensitivity"
        / "Recommended_Hyperparameters.csv",
    )
).resolve()

METHODS = {
    "Ground_SC": ROOT / "Ground_SC_Control" / "ground.sc.py",
    "k_flip": ROOT / "k_flip" / "k-flip.py",
    "MILP": ROOT / "MILP" / "MILP.py",
    "Gao2015": ROOT / "Gao2015_Voltage_SOC" / "gao2015.py",
    "Genetic_Algorithm": ROOT / "Genetic_Algorithm" / "genetic_algorithm.py",
    "Quantum_QUBO": ROOT / "Quantum_QUBO" / "quantum_10ess.py",
}


def load_manifest():
    if not MANIFEST_FILE.is_file():
        raise FileNotFoundError(
            f"Generate scale cases first: {MANIFEST_FILE}"
        )
    return pd.read_csv(MANIFEST_FILE)


def recommended_weights():
    if not SENSITIVITY_RECOMMENDATION.is_file():
        return 0.001, 20.0
    row = pd.read_csv(SENSITIVITY_RECOMMENDATION).iloc[0]
    return float(row["balance_weight"]), float(row["soc_dynamic_weight"])


def quantum_batch_size(scale_row):
    """Use one-step batches after observed dense-QUBO platform timeouts."""
    ess_count = int(scale_row["ess_stations"])
    if ess_count >= 20:
        return 1
    return min(10, max(1, 100 // ess_count))


def environment_for(scale_row):
    balance_weight, soc_dynamic_weight = recommended_weights()
    quantum_backend = os.environ.get("SCALE_QUANTUM_BACKEND", "cim")
    environment = os.environ.copy()
    environment.update(
        BENCHMARK_CASE_KEY=str(scale_row["scale"]),
        BENCHMARK_RESULT_ROOT=str(RESULT_ROOT.relative_to(ROOT)),
        BENCHMARK_NUM_BRAKE=str(int(scale_row["brake_trains"])),
        BENCHMARK_NUM_TRACTION=str(int(scale_row["traction_trains"])),
        BENCHMARK_NUM_ESS=str(int(scale_row["ess_stations"])),
        BENCHMARK_SIM_TIME=str(int(scale_row["time_steps"])),
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND=quantum_backend,
        ESS_QUBO_BATCH_SIZE=str(quantum_batch_size(scale_row)),
        ESS_QUBO_BALANCE_WEIGHT=str(balance_weight),
        ESS_QUBO_SOC_DYNAMIC_WEIGHT=str(soc_dynamic_weight),
    )
    if quantum_backend == "scip":
        environment["ESS_ALLOW_LOCAL_QUBO_EXPERIMENT"] = "1"
    return environment


def time_series_path(scale_row, method):
    case_root = RESULT_ROOT / str(scale_row["scale"]) / method
    if method == "Quantum_QUBO":
        ess_count = int(scale_row["ess_stations"])
        batch_size = quantum_batch_size(scale_row)
        return case_root / (
            f"TimeSeries_Result_{ess_count}ESS_{batch_size}sBatch.csv"
        )
    return case_root / "excel_result" / "TimeSeries_Result.xlsx"


def run_one(scale_row, method, force=False):
    output_file = time_series_path(scale_row, method)
    if output_file.is_file() and not force:
        print(f"SKIP {scale_row['scale']} / {method}: result exists")
        return
    script = METHODS[method]
    case_file = CASE_DIR / str(scale_row["file"])
    command = [sys.executable, "-u", "-B", str(script), str(case_file)]
    print(f"RUN {scale_row['scale']} / {method}", flush=True)
    maximum_attempts = (
        5
        if method == "Quantum_QUBO"
        and os.environ.get("SCALE_QUANTUM_BACKEND", "cim") == "cim"
        else 1
    )
    for attempt in range(1, maximum_attempts + 1):
        try:
            subprocess.run(
                command,
                cwd=script.parent,
                env=environment_for(scale_row),
                check=True,
            )
            break
        except subprocess.CalledProcessError:
            if attempt >= maximum_attempts:
                raise
            delay_s = min(5 * attempt, 30)
            print(
                f"RETRY {scale_row['scale']} / {method}: "
                f"attempt {attempt + 1}/{maximum_attempts} after {delay_s}s",
                flush=True,
            )
            time.sleep(delay_s)


def load_time_series(scale_row, method):
    path = time_series_path(scale_row, method)
    if not path.is_file():
        return None
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    return pd.read_excel(path)


def summarize(scale_row, method):
    data = load_time_series(scale_row, method)
    if data is None:
        return None
    energy = lambda column: float(data[column].sum() / 3600.0)
    total_regen = energy("brake_power_kW")
    effective = (
        energy("p_direct_kW")
        + energy("ess_charge_kW")
        - energy("loss_kW")
    )
    result = {
        "scale": str(scale_row["scale"]),
        "method": method,
        "brake_trains": int(scale_row["brake_trains"]),
        "traction_trains": int(scale_row["traction_trains"]),
        "ess_stations": int(scale_row["ess_stations"]),
        "time_steps": len(data),
        "quantum_batch_size_s": (
            quantum_batch_size(scale_row)
            if method == "Quantum_QUBO"
            else np.nan
        ),
        "qubo_variables_per_batch": (
            int(scale_row["ess_stations"])
            * quantum_batch_size(scale_row)
            if method == "Quantum_QUBO"
            else np.nan
        ),
        "total_regen_kWh": total_regen,
        "effective_absorbed_kWh": effective,
        "absorption_rate_percent": (
            effective / total_regen * 100.0 if total_regen else 0.0
        ),
        "wasted_energy_kWh": energy("wasted_power_kW"),
        "grid_energy_kWh": energy("grid_power_kW"),
        "line_loss_kWh": energy("loss_kW"),
        "total_solve_time_s": float(data["solve_time_ms"].sum() / 1000.0),
        "mean_step_time_ms": float(data["solve_time_ms"].mean()),
        "maximum_step_time_ms": float(data["solve_time_ms"].max()),
        "infeasible_steps": int((~data["feasible"].astype(bool)).sum()),
        "voltage_violations": int(data["voltage_violation"].sum()),
        "power_violations": int(data["power_violation"].sum()),
        "max_power_balance_error_kW": float(
            data["power_balance_error_kW"].abs().max()
        ),
    }
    if method == "Quantum_QUBO":
        backend = data["batch_solver_backend"].astype(str).str.upper()
        result["platform_submissions"] = int(
            data.loc[backend == "CIM", "batch_id"].nunique()
        )
        result["local_fallback_batches"] = int(
            data.loc[backend != "CIM", "batch_id"].nunique()
        )
        result["solver_backend_mix"] = "+".join(
            sorted(data["batch_solver_backend"].astype(str).unique())
        )
        result["raw_qubo_balance_violation_steps"] = int(
            data["qubo_balance_violation"].astype(bool).sum()
        )
    else:
        result["platform_submissions"] = 0
        result["local_fallback_batches"] = 0
        result["solver_backend_mix"] = ""
        result["raw_qubo_balance_violation_steps"] = np.nan
    return result


def collect():
    manifest = load_manifest()
    rows = [
        result
        for _, scale_row in manifest.iterrows()
        for method in METHODS
        if (result := summarize(scale_row, method)) is not None
    ]
    if not rows:
        raise RuntimeError("No scale-ablation results are available")
    summary = pd.DataFrame(rows).sort_values(
        ["ess_stations", "method"]
    )
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    summary.to_csv(
        RESULT_ROOT / "Scale_Ablation_All_Results.csv",
        index=False,
        encoding="utf-8-sig",
    )

    complete_methods = [
        method
        for method, group in summary.groupby("method")
        if len(group) >= 3
    ]
    trend_rows = []
    for method in complete_methods:
        group = summary[summary["method"] == method].sort_values(
            "ess_stations"
        )
        positive = group[group["total_solve_time_s"] > 0]
        exponent = (
            float(
                np.polyfit(
                    np.log(positive["ess_stations"]),
                    np.log(positive["total_solve_time_s"]),
                    1,
                )[0]
            )
            if len(positive) >= 3
            else np.nan
        )
        trend_rows.append(
            {
                "method": method,
                "observed_time_scaling_exponent": exponent,
                "smallest_scale_time_s": float(
                    group.iloc[0]["total_solve_time_s"]
                ),
                "largest_scale_time_s": float(
                    group.iloc[-1]["total_solve_time_s"]
                ),
                "largest_to_smallest_time_ratio": float(
                    group.iloc[-1]["total_solve_time_s"]
                    / max(group.iloc[0]["total_solve_time_s"], 1e-12)
                ),
            }
        )
    trends = pd.DataFrame(trend_rows).sort_values(
        "observed_time_scaling_exponent"
    )
    trends.to_csv(
        RESULT_ROOT / "Scale_Time_Trends.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(summary.to_string(index=False))
    if not trends.empty:
        print("\nTime trends:\n", trends.to_string(index=False))
    return summary, trends


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("list", "classic", "quantum", "all", "collect")
    )
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    manifest = load_manifest()
    if args.command == "list":
        print(manifest.to_string(index=False))
        print("Methods:", ", ".join(METHODS))
        return
    if args.command in {"classic", "all"}:
        for _, scale_row in manifest.iterrows():
            for method in METHODS:
                if method != "Quantum_QUBO":
                    run_one(scale_row, method, force=args.force)
    if args.command in {"quantum", "all"}:
        for _, scale_row in manifest.iterrows():
            run_one(scale_row, "Quantum_QUBO", force=args.force)
    collect()


if __name__ == "__main__":
    main()
