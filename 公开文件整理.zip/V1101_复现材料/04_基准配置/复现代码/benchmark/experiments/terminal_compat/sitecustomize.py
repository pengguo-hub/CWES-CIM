"""Allow the existing Python 3.10 package stack to run in restricted Windows sessions.

The installed openpyxl asks the Windows registry for MIME types at import time.
Registry access may be denied even though workbook reading and writing work.
This changes only that optional MIME lookup for the opt-in reproduction run.
"""

import mimetypes

mimetypes.MimeTypes.read_windows_registry = lambda self: None
