"""Generate reproducible variable-scale cases from the dynamic mixed case."""

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE_FILE = ROOT / "data" / "Case4_150s_dynamic_mixed_10ESS.xlsx"
OUTPUT_DIR = Path(__file__).resolve().parent / "scale_cases"
HORIZON_STEPS = 30

SCALES = {
    "S01_1B1T2ESS": (1, 1, 2),
    "S02_2B2T5ESS": (2, 2, 5),
    "S03_3B3T10ESS": (3, 3, 10),
    "S04_5B5T20ESS": (5, 5, 20),
    "S05_8B8T40ESS": (8, 8, 40),
}


def resample_train_fleet(row, kind, source_count, target_count):
    """Resample one fleet while preserving its aggregate power exactly."""
    source_axis = np.linspace(0.0, 1.0, source_count)
    target_axis = np.linspace(0.0, 1.0, target_count)
    source_power = np.asarray(
        [row[f"{kind}_train_{index}_kW"] for index in range(1, source_count + 1)],
        dtype=float,
    )
    source_position = np.asarray(
        [
            row[f"{kind}_train_{index}_pos_km"]
            for index in range(1, source_count + 1)
        ],
        dtype=float,
    )
    if target_count == 1:
        target_power = np.asarray([source_power.sum()], dtype=float)
        if source_power.sum() > 0:
            target_position = np.asarray(
                [np.average(source_position, weights=source_power)], dtype=float
            )
        else:
            target_position = np.asarray([source_position.mean()], dtype=float)
        return target_power, target_position

    target_power = np.interp(target_axis, source_axis, source_power)
    if target_power.sum() > 0:
        target_power *= source_power.sum() / target_power.sum()
    target_position = np.interp(target_axis, source_axis, source_position)
    return target_power, target_position


def build_case(source, brake_count, traction_count, ess_count):
    """Build one 30-step scale case with the original aggregate power curves."""
    records = []
    ess_positions = np.linspace(1.0, 30.0, ess_count)
    for _, source_row in source.iloc[:HORIZON_STEPS].iterrows():
        record = {
            "time_s": int(source_row["time_s"]),
            "phase": str(source_row.get("phase", "dynamic_mixed")),
        }
        for kind, target_count in (
            ("brake", brake_count),
            ("traction", traction_count),
        ):
            powers, positions = resample_train_fleet(
                source_row,
                kind,
                source_count=3,
                target_count=target_count,
            )
            for index, (power, position) in enumerate(
                zip(powers, positions), start=1
            ):
                record[f"{kind}_train_{index}_pos_km"] = float(position)
                record[f"{kind}_train_{index}_kW"] = float(power)
        for index, position in enumerate(ess_positions, start=1):
            record[f"ess_{index}_pos_km"] = float(position)
            record[f"ess_{index}_capacity_kWh"] = 1000.0
            record[f"ess_{index}_max_charge_kW"] = 500.0
            record[f"ess_{index}_max_discharge_kW"] = 500.0
            record[f"ess_{index}_initial_soc_percent"] = 50.0
        record["brake_total_kW"] = sum(
            record[f"brake_train_{index}_kW"]
            for index in range(1, brake_count + 1)
        )
        record["traction_total_kW"] = sum(
            record[f"traction_train_{index}_kW"]
            for index in range(1, traction_count + 1)
        )
        record["power_surplus_kW"] = (
            record["brake_total_kW"] - record["traction_total_kW"]
        )
        records.append(record)
    return pd.DataFrame.from_records(records)


def validate_totals(source, generated, scale_name):
    for column in ("brake_total_kW", "traction_total_kW"):
        expected = source.iloc[:HORIZON_STEPS][column].to_numpy(dtype=float)
        actual = generated[column].to_numpy(dtype=float)
        if not np.allclose(actual, expected, rtol=0.0, atol=1e-8):
            raise ValueError(f"{scale_name} does not preserve {column}")


def main():
    source = pd.read_excel(SOURCE_FILE).dropna(how="all").reset_index(drop=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    manifest_rows = []
    for scale_name, (brake_count, traction_count, ess_count) in SCALES.items():
        generated = build_case(source, brake_count, traction_count, ess_count)
        validate_totals(source, generated, scale_name)
        output_file = OUTPUT_DIR / f"{scale_name}_30s.csv"
        generated.to_csv(output_file, index=False, encoding="utf-8-sig")
        manifest_rows.append(
            {
                "scale": scale_name,
                "brake_trains": brake_count,
                "traction_trains": traction_count,
                "ess_stations": ess_count,
                "time_steps": len(generated),
                "qubo_variables_per_batch": ess_count * 10,
                "file": output_file.name,
            }
        )
    pd.DataFrame(manifest_rows).to_csv(
        OUTPUT_DIR / "scale_manifest.csv", index=False, encoding="utf-8-sig"
    )
    print(f"Generated {len(manifest_rows)} scale cases in {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
