"""Real-coded genetic algorithm for the shared 30-second 10ESS benchmark.

Each chromosome contains one participation ratio per ESS. The shared runtime
turns the chromosome into a physically feasible power dispatch and applies the
same SOC, power, voltage, loss, and balance rules used by the classic methods.
"""

import os
import random
import sys
import time
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
ROOT = BASE_DIR.parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import (
    CASE_FILES,
    ESS_POSITIONS,
    GA_CROSSOVER_RATE,
    GA_ELITE_SIZE,
    GA_GENERATIONS,
    GA_LOSS_WEIGHT,
    GA_MUTATION_RATE,
    GA_MUTATION_SIGMA,
    GA_POPULATION_SIZE,
    GA_RANDOM_SEED,
    GA_SOC_BALANCE_WEIGHT,
    GA_STAGNATION_GENERATIONS,
    GA_TOURNAMENT_SIZE,
    MILP_OBJECTIVE_WEIGHTS,
    NUM_ESS,
    RESULT_ROOT,
    SOC_INIT,
)
from data_loader import build_input_t, load_case_data
from evaluation import calculate_summary
from reporting import plot_standard_results, save_tabular_outputs
from runtime import (
    allocate_power,
    charge_limits,
    discharge_limits,
    finalize_step,
    location_scores,
)

# =========================
# Case selection — change CASE_NAME to run different scenarios:
#   "Case1"  "Case2"  "Case3"  "Case4"
# =========================
DEFAULT_CASE_NAME = "Case1"

INPUT_FILE = (
    Path(sys.argv[1]) if len(sys.argv) > 1
    else ROOT / "data" / CASE_FILES[DEFAULT_CASE_NAME]
)
CASE_NAME = os.environ.get("BENCHMARK_CASE_KEY") or next(
    (
        case_key
        for case_key, filename in CASE_FILES.items()
        if Path(filename).name == INPUT_FILE.name
    ),
    INPUT_FILE.stem,
)
OUTPUT_DIR = ROOT / RESULT_ROOT / CASE_NAME / "Genetic_Algorithm"
EXCEL_DIR = OUTPUT_DIR / "excel_result"
FIG_DIR = OUTPUT_DIR / "figure"
TXT_DIR = OUTPUT_DIR / "txt"
for directory in (EXCEL_DIR, FIG_DIR, TXT_DIR):
    directory.mkdir(parents=True, exist_ok=True)


def _clip_gene(value):
    return min(1.0, max(0.0, float(value)))


def dispatch_from_genome(input_t, genome):
    """Map a real-valued chromosome to charge/discharge requests."""
    brake = sum(input_t["brake_power"])
    traction = sum(input_t["traction_power"])
    surplus = max(0.0, brake - traction)
    deficit = max(0.0, traction - brake)
    charge = [0.0] * NUM_ESS
    discharge = [0.0] * NUM_ESS

    if surplus > 0.0:
        caps = [
            limit * _clip_gene(gene)
            for limit, gene in zip(charge_limits(input_t["soc"]), genome)
        ]
        scores = location_scores(
            ESS_POSITIONS, input_t["brake_position"], input_t["brake_power"]
        )
        charge = allocate_power(surplus, caps, scores)
    elif deficit > 0.0:
        caps = [
            limit * _clip_gene(gene)
            for limit, gene in zip(discharge_limits(input_t["soc"]), genome)
        ]
        scores = location_scores(
            ESS_POSITIONS, input_t["traction_position"], input_t["traction_power"]
        )
        discharge = allocate_power(deficit, caps, scores)
    return charge, discharge


def chromosome_fitness(input_t, genome):
    charge, discharge = dispatch_from_genome(input_t, genome)
    result, next_soc, _ = finalize_step(input_t, charge, discharge, 0.0)
    weights = MILP_OBJECTIVE_WEIGHTS
    soc_spread_percent = (max(next_soc) - min(next_soc)) * 100.0
    fitness = (
        weights["charge"] * result["ess_charge_kW"]
        + weights["discharge"] * result["ess_discharge_kW"]
        - weights["waste"] * result["wasted_power_kW"]
        - weights["grid"] * result["grid_power_kW"]
        - GA_LOSS_WEIGHT * result["loss_kW"]
        - GA_SOC_BALANCE_WEIGHT * soc_spread_percent
    )
    return float(fitness)


def _spatial_seed(input_t):
    if sum(input_t["brake_power"]) >= sum(input_t["traction_power"]):
        scores = location_scores(
            ESS_POSITIONS, input_t["brake_position"], input_t["brake_power"]
        )
    else:
        scores = location_scores(
            ESS_POSITIONS, input_t["traction_position"], input_t["traction_power"]
        )
    maximum = max(scores, default=0.0)
    if maximum <= 1e-12:
        return [1.0] * NUM_ESS
    return [score / maximum for score in scores]


def _initial_population(input_t, rng, warm_start=None):
    population = [
        [1.0] * NUM_ESS,
        [0.0] * NUM_ESS,
        _spatial_seed(input_t),
    ]
    if warm_start is not None:
        population.append([_clip_gene(gene) for gene in warm_start])
    while len(population) < GA_POPULATION_SIZE:
        population.append([rng.random() for _ in range(NUM_ESS)])
    return population[:GA_POPULATION_SIZE]


def _tournament(scored, rng):
    contestants = rng.sample(scored, k=min(GA_TOURNAMENT_SIZE, len(scored)))
    return max(contestants, key=lambda item: item[0])[1]


def _crossover(parent_a, parent_b, rng):
    if rng.random() >= GA_CROSSOVER_RATE:
        return list(parent_a), list(parent_b)
    child_a = []
    child_b = []
    for gene_a, gene_b in zip(parent_a, parent_b):
        alpha = rng.random()
        child_a.append(_clip_gene(alpha * gene_a + (1.0 - alpha) * gene_b))
        child_b.append(_clip_gene(alpha * gene_b + (1.0 - alpha) * gene_a))
    return child_a, child_b


def _mutate(genome, rng):
    mutated = list(genome)
    for index in range(NUM_ESS):
        if rng.random() < GA_MUTATION_RATE:
            mutated[index] = _clip_gene(
                mutated[index] + rng.gauss(0.0, GA_MUTATION_SIGMA)
            )
    return mutated


def solve_one_step_ga(input_t, step_index, warm_start=None):
    """Return the best dispatch and deterministic GA diagnostics for one step."""
    rng = random.Random(GA_RANDOM_SEED + int(step_index))
    population = _initial_population(input_t, rng, warm_start)
    cache = {}
    best_genome = list(population[0])
    best_fitness = float("-inf")
    stagnant = 0
    generations_run = 0
    start = time.perf_counter()

    for generation in range(GA_GENERATIONS):
        scored = []
        for genome in population:
            key = tuple(round(gene, 8) for gene in genome)
            if key not in cache:
                cache[key] = chromosome_fitness(input_t, genome)
            scored.append((cache[key], genome))
        scored.sort(key=lambda item: item[0], reverse=True)
        generations_run = generation + 1

        if scored[0][0] > best_fitness + 1e-9:
            best_fitness = scored[0][0]
            best_genome = list(scored[0][1])
            stagnant = 0
        else:
            stagnant += 1
        if stagnant >= GA_STAGNATION_GENERATIONS:
            break

        next_population = [list(item[1]) for item in scored[:GA_ELITE_SIZE]]
        while len(next_population) < GA_POPULATION_SIZE:
            parent_a = _tournament(scored, rng)
            parent_b = _tournament(scored, rng)
            child_a, child_b = _crossover(parent_a, parent_b, rng)
            next_population.append(_mutate(child_a, rng))
            if len(next_population) < GA_POPULATION_SIZE:
                next_population.append(_mutate(child_b, rng))
        population = next_population

    charge, discharge = dispatch_from_genome(input_t, best_genome)
    solve_ms = (time.perf_counter() - start) * 1000.0
    diagnostics = {
        "ga_best_fitness": best_fitness,
        "ga_generations_run": generations_run,
        "ga_population_size": GA_POPULATION_SIZE,
        "ga_active_ess_count": sum(gene > 1e-6 for gene in best_genome),
        "ga_best_genome": ";".join(f"{gene:.6f}" for gene in best_genome),
    }
    return charge, discharge, best_genome, solve_ms, diagnostics


def run_genetic_algorithm_case(case_file=None):
    condition = load_case_data(case_file or INPUT_FILE)
    soc = [SOC_INIT] * NUM_ESS
    previous_genome = None
    records = []
    total_start = time.perf_counter()
    for step_index, (_, row) in enumerate(condition.iterrows()):
        input_t = build_input_t(row, soc)
        charge, discharge, previous_genome, solve_ms, extras = solve_one_step_ga(
            input_t, step_index, warm_start=previous_genome
        )
        result, soc, _ = finalize_step(input_t, charge, discharge, solve_ms, extras)
        records.append(result)
    return pd.DataFrame(records), time.perf_counter() - total_start


def main():
    print(f"Case file: {INPUT_FILE}")
    print(f"Output directory: {OUTPUT_DIR}")
    result_df, total_runtime = run_genetic_algorithm_case()
    summary_df = calculate_summary(
        result_df, total_runtime, "Real-coded Genetic Algorithm (GA)"
    )
    save_tabular_outputs(
        result_df,
        summary_df,
        EXCEL_DIR,
        TXT_DIR,
        "GA 10ESS unified evaluation result",
    )
    plot_standard_results(result_df, FIG_DIR, prefix="GA")
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
