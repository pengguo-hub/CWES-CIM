"""Single-step MILP adapted to the shared 10ESS benchmark."""

import os
import sys
import time
from pathlib import Path

import pandas as pd
import pulp

BASE_DIR = Path(__file__).resolve().parent
ROOT = BASE_DIR.parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import ESS_POSITIONS, MILP_OBJECTIVE_WEIGHTS, NUM_ESS, SOC_INIT, CASE_FILES, RESULT_ROOT
from data_loader import build_input_t, load_case_data
from evaluation import calculate_summary
from reporting import plot_standard_results, save_tabular_outputs
from runtime import charge_limits, discharge_limits, finalize_step

# =========================
# Case selection — change CASE_NAME to run different scenarios:
#   "Case1"  "Case2"  "Case3"  "Case4"
# =========================
DEFAULT_CASE_NAME = "Case1"

INPUT_FILE = (
    Path(sys.argv[1]) if len(sys.argv) > 1
    else ROOT / "data" / CASE_FILES[DEFAULT_CASE_NAME]
)
CASE_NAME = os.environ.get("BENCHMARK_CASE_KEY") or next(
    (
        case_key
        for case_key, filename in CASE_FILES.items()
        if Path(filename).name == INPUT_FILE.name
    ),
    INPUT_FILE.stem,
)
OUTPUT_DIR = ROOT / RESULT_ROOT / CASE_NAME / "MILP"
EXCEL_DIR = OUTPUT_DIR / "excel_result"
FIG_DIR = OUTPUT_DIR / "figure"
TXT_DIR = OUTPUT_DIR / "txt"
for directory in (EXCEL_DIR, FIG_DIR, TXT_DIR):
    directory.mkdir(parents=True, exist_ok=True)


def _nearest_distance(position, train_positions, train_powers):
    active = [p for p, power in zip(train_positions, train_powers) if power > 0]
    return min((abs(position - p) for p in active), default=0.0)


def solve_one_step_milp(input_t):
    model = pulp.LpProblem("MILP_10ESS_Regenerative_Energy", pulp.LpMaximize)
    charge = [pulp.LpVariable(f"p_ch_{i + 1}", lowBound=0) for i in range(NUM_ESS)]
    discharge = [pulp.LpVariable(f"p_dis_{i + 1}", lowBound=0) for i in range(NUM_ESS)]
    charge_on = [pulp.LpVariable(f"y_ch_{i + 1}", cat="Binary") for i in range(NUM_ESS)]
    discharge_on = [pulp.LpVariable(f"y_dis_{i + 1}", cat="Binary") for i in range(NUM_ESS)]
    waste = pulp.LpVariable("p_waste", lowBound=0)
    grid = pulp.LpVariable("p_grid", lowBound=0)

    brake = sum(input_t["brake_power"])
    traction = sum(input_t["traction_power"])
    surplus = max(0.0, brake - traction)
    deficit = max(0.0, traction - brake)
    ch_limits = charge_limits(input_t["soc"])
    dis_limits = discharge_limits(input_t["soc"])

    model += pulp.lpSum(charge) + waste == surplus
    model += pulp.lpSum(discharge) + grid == deficit
    for i in range(NUM_ESS):
        model += charge[i] <= ch_limits[i] * charge_on[i]
        model += discharge[i] <= dis_limits[i] * discharge_on[i]
        model += charge_on[i] + discharge_on[i] <= 1

    weights = MILP_OBJECTIVE_WEIGHTS
    charge_distance = [
        _nearest_distance(position, input_t["brake_position"], input_t["brake_power"])
        for position in ESS_POSITIONS
    ]
    discharge_distance = [
        _nearest_distance(position, input_t["traction_position"], input_t["traction_power"])
        for position in ESS_POSITIONS
    ]
    model += (
        weights["charge"] * pulp.lpSum(charge)
        + weights["discharge"] * pulp.lpSum(discharge)
        - weights["waste"] * waste
        - weights["grid"] * grid
        - weights["distance"] * pulp.lpSum(
            charge_distance[i] * charge[i] + discharge_distance[i] * discharge[i]
            for i in range(NUM_ESS)
        )
    )

    start = time.perf_counter()
    status = model.solve(pulp.PULP_CBC_CMD(msg=False))
    solve_ms = (time.perf_counter() - start) * 1000.0
    feasible = pulp.LpStatus[status] in {"Optimal", "Feasible"}
    if not feasible:
        return [0.0] * NUM_ESS, [0.0] * NUM_ESS, solve_ms, {
            "milp_status": pulp.LpStatus[status], "objective_value": float("nan")
        }
    return (
        [float(pulp.value(variable) or 0.0) for variable in charge],
        [float(pulp.value(variable) or 0.0) for variable in discharge],
        solve_ms,
        {"milp_status": pulp.LpStatus[status], "objective_value": float(pulp.value(model.objective))},
    )


def run_milp_case(case_file=None):
    condition = load_case_data(case_file or INPUT_FILE)
    soc = [SOC_INIT] * NUM_ESS
    records = []
    total_start = time.perf_counter()
    for _, row in condition.iterrows():
        input_t = build_input_t(row, soc)
        charge, discharge, solve_ms, extras = solve_one_step_milp(input_t)
        result, soc, _ = finalize_step(input_t, charge, discharge, solve_ms, extras)
        records.append(result)
    return pd.DataFrame(records), time.perf_counter() - total_start


def main():
    print(f"工况文件: {INPUT_FILE}")
    print(f"输出目录: {OUTPUT_DIR}")
    result_df, total_runtime = run_milp_case()
    summary_df = calculate_summary(result_df, total_runtime, "MILP")
    save_tabular_outputs(result_df, summary_df, EXCEL_DIR, TXT_DIR, "MILP 10ESS统一评价结果")
    plot_standard_results(result_df, FIG_DIR, prefix="MILP")
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
