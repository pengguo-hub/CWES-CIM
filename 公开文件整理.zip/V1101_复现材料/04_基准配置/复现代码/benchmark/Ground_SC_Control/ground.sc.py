"""Ground supercapacitor feedback controller adapted to the 10ESS benchmark."""

import os
import sys
import time
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
ROOT = BASE_DIR.parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import ESS_POSITIONS, NUM_ESS, SOC_INIT, SOC_MAX, SOC_MIN, CASE_FILES, RESULT_ROOT
from data_loader import build_input_t, load_case_data
from evaluation import calculate_summary
from reporting import plot_standard_results, save_tabular_outputs
from runtime import allocate_power, charge_limits, discharge_limits, finalize_step, location_scores

# =========================
# Case selection — change CASE_NAME to run different scenarios:
#   "Case1"  "Case2"  "Case3"  "Case4"
# =========================
DEFAULT_CASE_NAME = "Case1"

INPUT_FILE = (
    Path(sys.argv[1]) if len(sys.argv) > 1
    else ROOT / "data" / CASE_FILES[DEFAULT_CASE_NAME]
)
CASE_NAME = os.environ.get("BENCHMARK_CASE_KEY") or next(
    (
        case_key
        for case_key, filename in CASE_FILES.items()
        if Path(filename).name == INPUT_FILE.name
    ),
    INPUT_FILE.stem,
)
OUTPUT_DIR = ROOT / RESULT_ROOT / CASE_NAME / "Ground_SC"
EXCEL_DIR = OUTPUT_DIR / "excel_result"
FIG_DIR = OUTPUT_DIR / "figure"
TXT_DIR = OUTPUT_DIR / "txt"
for directory in (EXCEL_DIR, FIG_DIR, TXT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

U_REF = 1500.0
U_CH_START = 1650.0
U_CH_FULL = 1800.0
U_DIS_START = 1350.0
U_DIS_FULL = 1200.0


def estimate_dc_voltage(brake_power, traction_power):
    base = max(brake_power, traction_power, 1.0)
    return max(1100.0, min(1900.0, U_REF + 300.0 * (brake_power - traction_power) / base))


def voltage_charge_factor(voltage):
    return max(0.0, min(1.0, (voltage - U_CH_START) / (U_CH_FULL - U_CH_START)))


def voltage_discharge_factor(voltage):
    return max(0.0, min(1.0, (U_DIS_START - voltage) / (U_DIS_START - U_DIS_FULL)))


def ground_sc_controller(input_t):
    start = time.perf_counter()
    brake = sum(input_t["brake_power"])
    traction = sum(input_t["traction_power"])
    surplus = max(0.0, brake - traction)
    deficit = max(0.0, traction - brake)
    voltage = estimate_dc_voltage(brake, traction)
    charge = [0.0] * NUM_ESS
    discharge = [0.0] * NUM_ESS
    mode = "standby"

    if surplus > 0 and voltage > U_CH_START:
        mode = "charge"
        factor = voltage_charge_factor(voltage)
        limits = [
            limit * factor * max(0.0, (SOC_MAX - soc) / (SOC_MAX - SOC_MIN))
            for limit, soc in zip(charge_limits(input_t["soc"]), input_t["soc"])
        ]
        scores = location_scores(ESS_POSITIONS, input_t["brake_position"], input_t["brake_power"])
        charge = allocate_power(surplus, limits, scores)
    elif deficit > 0 and voltage < U_DIS_START:
        mode = "discharge"
        factor = voltage_discharge_factor(voltage)
        limits = [
            limit * factor * max(0.0, (soc - SOC_MIN) / (SOC_MAX - SOC_MIN))
            for limit, soc in zip(discharge_limits(input_t["soc"]), input_t["soc"])
        ]
        scores = location_scores(ESS_POSITIONS, input_t["traction_position"], input_t["traction_power"])
        discharge = allocate_power(deficit, limits, scores)

    solve_ms = (time.perf_counter() - start) * 1000.0
    return charge, discharge, solve_ms, {"control_mode": mode, "dc_voltage_V": voltage}


def run_ground_sc_case(case_file=None):
    condition = load_case_data(case_file or INPUT_FILE)
    soc = [SOC_INIT] * NUM_ESS
    records = []
    total_start = time.perf_counter()
    for _, row in condition.iterrows():
        input_t = build_input_t(row, soc)
        charge, discharge, solve_ms, extras = ground_sc_controller(input_t)
        result, soc, _ = finalize_step(input_t, charge, discharge, solve_ms, extras)
        records.append(result)
    return pd.DataFrame(records), time.perf_counter() - total_start


def main():
    print(f"工况文件: {INPUT_FILE}")
    print(f"输出目录: {OUTPUT_DIR}")
    result_df, total_runtime = run_ground_sc_case()
    summary_df = calculate_summary(result_df, total_runtime, "Ground_SC_Control")
    save_tabular_outputs(result_df, summary_df, EXCEL_DIR, TXT_DIR, "Ground SC 10ESS统一评价结果")
    plot_standard_results(result_df, FIG_DIR, prefix="Ground_SC", voltage_column="dc_voltage_V")
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
