"""Static and data validation that never starts the quantum solver."""

import ast
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
BENCHMARK_ROOT = ROOT.parent
CONFIG_DIR = BENCHMARK_ROOT / "config"
DATA_DIR = BENCHMARK_ROOT / "data"
RESULT_ROOT = BENCHMARK_ROOT / "results"
for import_dir in (ROOT, CONFIG_DIR):
    if str(import_dir) not in sys.path:
        sys.path.insert(0, str(import_dir))

from benchmark_config import CASE_FILES, NUM_BRAKE, NUM_ESS, NUM_TRACTION, TIME_STEPS
from data_loader import load_case_data
from quantum_config import BATCH_SIZE, QUANTUM_SOLVER_BACKEND, USE_QUANTUM_INTERFACE


EXPECTED_CASE_KEYS = ("Case1", "Case2", "Case3", "Case4")
PYTHON_FILES = (
    "quantum_10ess.py",
    "numeric_qubo_builder.py",
    "physical_dispatch.py",
    "quantum_config.py",
    "run_quantum_cases.py",
    "validate_setup.py",
)


def validate_configuration():
    assert tuple(CASE_FILES) == EXPECTED_CASE_KEYS, tuple(CASE_FILES)
    assert (NUM_BRAKE, NUM_TRACTION, NUM_ESS) == (3, 3, 10)
    assert TIME_STEPS == 150
    assert USE_QUANTUM_INTERFACE is True
    assert QUANTUM_SOLVER_BACKEND == "cim"
    assert BATCH_SIZE == 10
    assert (TIME_STEPS + BATCH_SIZE - 1) // BATCH_SIZE == 15


def validate_case_files():
    for case_key, filename in CASE_FILES.items():
        path = DATA_DIR / filename
        data = load_case_data(path)
        assert len(data) == TIME_STEPS, (case_key, len(data))
        assert int(data.iloc[0]["time_s"]) == 0
        assert int(data.iloc[-1]["time_s"]) == TIME_STEPS - 1
        for ess_index in range(1, NUM_ESS + 1):
            assert f"ess_{ess_index}_pos_km" in data.columns


def validate_python_syntax():
    for filename in PYTHON_FILES:
        path = ROOT / filename
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))


def validate_quantum_results_if_present():
    for case_key in CASE_FILES:
        result_dir = RESULT_ROOT / case_key / "Quantum_QUBO"
        if not result_dir.exists():
            continue
        time_series = result_dir / "TimeSeries_Result_10ESS_10sBatch.csv"
        batch_summary = result_dir / "Batch_Summary_10ESS_10sBatch.csv"
        summary = result_dir / "Summary_Result_10ESS_10sBatch.csv"
        for required_file in (time_series, batch_summary, summary):
            assert required_file.is_file(), required_file
        import pandas as pd

        assert len(pd.read_csv(time_series)) == TIME_STEPS
        assert len(pd.read_csv(batch_summary)) == 15


def main():
    validate_configuration()
    validate_case_files()
    validate_python_syntax()
    validate_quantum_results_if_present()
    print("PASS: four cases and Quantum_QUBO setup are valid.")
    print("PASS: validation did not import or execute the quantum solver.")


if __name__ == "__main__":
    main()
