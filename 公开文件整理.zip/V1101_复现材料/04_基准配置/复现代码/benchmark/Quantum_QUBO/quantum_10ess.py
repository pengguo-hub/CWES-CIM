import numpy as np
import networkx as nx
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
BENCHMARK_ROOT = BASE_DIR.parent
CONFIG_DIR = BENCHMARK_ROOT / "config"
DATA_DIR = BENCHMARK_ROOT / "data"
RESULT_ROOT = BENCHMARK_ROOT / os.environ.get(
    "BENCHMARK_RESULT_ROOT", "results"
)
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from quantum_config import (
    BALANCE_TOLERANCE_KW,
    DISPATCH_LOSS_WEIGHT,
    DISPATCH_QUBO_PRIORITY_BOOST,
    DISPATCH_RANDOM_SEED,
    DISPATCH_RANDOM_STARTS,
    BATCH_SIZE,
    DEFAULT_CASE_KEY,
    QUBO_BALANCE_WEIGHT,
    QUBO_SOC_BOUNDARY_WEIGHT,
    QUBO_SOC_DYNAMIC_WEIGHT,
    QUBO_SUBSTATION_WEIGHT,
    QUBO_SWITCH_WEIGHT,
    QUBO_WASTE_WEIGHT,
    QUANTUM_SOLVER_BACKEND,
    QUBO_DISCHARGE_REWARD_WEIGHT,
    QUBO_GRID_WEIGHT,
    QUBO_LOSS_WEIGHT,
    I_MAX_KA,
    USE_QUANTUM_INTERFACE,
    VOLTAGE_MAX_V,
)

# Physical parameters, case loading, graph construction, and evaluation come
# from the shared benchmark configuration.
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

if USE_QUANTUM_INTERFACE:
    import kaiwu as kw
    import kaiwu
else:
    kw = None
    kaiwu = None
import pandas as pd
from typing import Tuple
from time import perf_counter
try:
    from scipy.optimize import minimize
except ImportError:  # The deterministic seed decoder remains available.
    minimize = None

from benchmark_config import (
    CASE_FILES,
    NUM_BRAKE,
    NUM_TRACTION,
    NUM_ESS,
    DT,
    ESS_POSITIONS,
    ESS_CAPACITY_KWH,
    P_CH_MAX_KW,
    P_DIS_MAX_KW,
    SOC_INIT,
    SOC_MIN,
    SOC_MAX,
    ETA_CH,
    ETA_DIS,
    DC_VOLTAGE,
    DC_VOLTAGE_MIN,
    LINE_RESISTANCE,
    P_SUB_MAX_KW,
    MILP_OBJECTIVE_WEIGHTS,
)
from data_loader import (
    build_input_t,
    load_case_data,
)
from edge_builder import GAMMA, build_edges
from evaluation import calculate_summary
from runtime import (
    allocate_power as shared_allocate_power,
    charge_limits as shared_charge_limits,
    discharge_limits as shared_discharge_limits,
    finalize_step as finalize_shared_step,
    location_scores as shared_location_scores,
)
if USE_QUANTUM_INTERFACE:
    from numeric_qubo_builder import solve_numeric_batch_qubo
else:
    solve_numeric_batch_qubo = None
from physical_dispatch import calculate_transfer_result_physical

# =========================================================
# Dynamic Max-Cut + QUBO + CIM
# Case1 统一评价体系版本
# =========================================================
if USE_QUANTUM_INTERFACE and QUANTUM_SOLVER_BACKEND == "cim":
    kaiwu_user_id = os.environ.get("KAIWU_USER_ID", "").strip()
    kaiwu_sdk_code = os.environ.get("KAIWU_SDK_CODE", "").strip()
    if not kaiwu_user_id or not kaiwu_sdk_code:
        raise RuntimeError(
            "CIM execution requires KAIWU_USER_ID and KAIWU_SDK_CODE "
            "in the current process environment"
        )
    kaiwu.license.init(
        user_id=kaiwu_user_id,
        sdk_code=kaiwu_sdk_code,
    )
elif USE_QUANTUM_INTERFACE:
    print("[MODE] Numeric QUBO will be solved locally by SCIP.")
else:
    print("[MODE] Quantum/CIM interface is disabled; delegating to classic k_flip.")

# =====================
# 0. 输入输出路径
# =====================

if DEFAULT_CASE_KEY not in CASE_FILES:
    raise ValueError(f"Unknown default case key: {DEFAULT_CASE_KEY}")

INPUT_FILE = (
    Path(sys.argv[1]).resolve()
    if len(sys.argv) > 1
    else DATA_DIR / CASE_FILES[DEFAULT_CASE_KEY]
)
CASE_KEY_BY_FILE = {Path(name).name: key for key, name in CASE_FILES.items()}
CASE_KEY = os.environ.get("BENCHMARK_CASE_KEY")
if not CASE_KEY:
    try:
        CASE_KEY = CASE_KEY_BY_FILE[INPUT_FILE.name]
    except KeyError as error:
        supported = ", ".join(sorted(CASE_KEY_BY_FILE))
        raise ValueError(
            "Nonstandard experiment inputs require BENCHMARK_CASE_KEY. "
            f"Standard inputs are: {supported}"
        ) from error
CASE_NAME = INPUT_FILE.stem
OUTPUT_DIR = EXCEL_DIR = TXT_DIR = RESULT_ROOT / CASE_KEY / "Quantum_QUBO"

if USE_QUANTUM_INTERFACE:
    for d in [EXCEL_DIR, TXT_DIR]:
        d.mkdir(parents=True, exist_ok=True)




# =====================
# 1. 参数配置
# =====================

class LocalMaxCutConfig:
    def __init__(self):
        self.arm_id = 0

        # 电气参数
        self.V0 = DC_VOLTAGE / 1000.0
        self.I_max = I_MAX_KA
        self.P_loss_max = self.V0 * self.I_max * 1000
        self.Z_unit = LINE_RESISTANCE

        # 节点状态
        self.node_names = []
        self.node_types = np.array([], dtype=int)
        self.P = np.array([], dtype=float)
        self.positions = np.array([], dtype=float)
        self.speed = np.array([], dtype=float)
        self.voltage = np.array([], dtype=float)
        self.distance_matrix = np.zeros((0, 0), dtype=float)

        # 权重与效率参数
        self.gamma = GAMMA
        self.eta_c = ETA_CH
        self.eta_d = ETA_DIS

        # 多储能参数
        self.SOC_max = SOC_MAX
        self.SOC_min = SOC_MIN
        self.ess_count = NUM_ESS

        self.SOC_ess = np.full(self.ess_count, SOC_INIT, dtype=float)
        self.ess_positions_km = np.asarray(ESS_POSITIONS, dtype=float)
        self.ess_capacity_kWh = np.full(self.ess_count, ESS_CAPACITY_KWH, dtype=float)
        self.P_s_max_ch = np.full(self.ess_count, P_CH_MAX_KW, dtype=float)
        self.P_s_max_dis = np.full(self.ess_count, P_DIS_MAX_KW, dtype=float)

        self.qubo_var_count = 0
        self.substation_max_power_kW = P_SUB_MAX_KW
        self.V_min = DC_VOLTAGE_MIN / 1000.0
        self.V_max = (
            float("inf")
            if VOLTAGE_MAX_V is None
            else VOLTAGE_MAX_V / 1000.0
        )
        self.balance_tolerance_kW = BALANCE_TOLERANCE_KW

        # 时间参数
        self.dt = DT
        self.sim_steps = 0

        # QUBO惩罚参数
        self.lambda1 = 0.001
        self.lambda2 = 0.001
        self.lambda_balance_base = QUBO_BALANCE_WEIGHT
        self.lambda_switch = QUBO_SWITCH_WEIGHT
        self.cross_batch_switch_enabled = (
            os.environ.get("ESS_QUBO_CROSS_BATCH_SWITCH", "0") == "1"
        )
        self.previous_ess_modes = None
        self.lambda_substation = QUBO_SUBSTATION_WEIGHT

        # ===== 全约束QUBO附加权重 =====
        # C4-C5、C11：批次内SOC动态与SOC安全区间软约束
        self.lambda_soc_dynamic = QUBO_SOC_DYNAMIC_WEIGHT
        self.lambda_soc_boundary = QUBO_SOC_BOUNDARY_WEIGHT
        self.soc_target = 0.55

        # C8：线路损耗的距离-功率二次代理惩罚
        # Physical-kW loss weight; survives 8-bit Ising quantisation.
        self.lambda_loss_qubo = QUBO_LOSS_WEIGHT
        self.dispatch_loss_weight = DISPATCH_LOSS_WEIGHT
        self.dispatch_qubo_priority_boost = DISPATCH_QUBO_PRIORITY_BOOST
        self.dispatch_decoder_mode = os.environ.get(
            "ESS_DECODER_MODE", "soft"
        ).strip().lower()
        if self.dispatch_decoder_mode not in {"soft", "hard"}:
            raise ValueError(
                "ESS_DECODER_MODE must be 'soft' or 'hard'"
            )

        # C9：弃能与电网补能代理惩罚
        self.lambda_waste_qubo = QUBO_WASTE_WEIGHT
        self.lambda_grid_qubo = QUBO_GRID_WEIGHT
        self.lambda_discharge_reward_qubo = QUBO_DISCHARGE_REWARD_WEIGHT

        # QUBO系数精度，降低CIM矩阵bit数
        self.qubo_round_digits = 4
        self.cim_bit_width = 8

        # Controlled attribution switches.  Defaults preserve the production
        # dynamic-Max-Cut behavior; experiment runners opt in through the
        # environment without changing module paths or solver APIs.
        self.graph_mode = os.environ.get(
            "ESS_ABLATION_GRAPH_MODE", "dynamic"
        ).strip().lower()
        if self.graph_mode not in {"dynamic", "static"}:
            raise ValueError(
                "ESS_ABLATION_GRAPH_MODE must be 'dynamic' or 'static'"
            )
        maxcut_flag = os.environ.get(
            "ESS_ABLATION_ENABLE_MAXCUT", "1"
        ).strip().lower()
        if maxcut_flag not in {"0", "1"}:
            raise ValueError(
                "ESS_ABLATION_ENABLE_MAXCUT must be '0' or '1'"
            )
        self.maxcut_enabled = maxcut_flag == "1"

# =====================
# 2. 读取 Case1
# =====================

def load_benchmark_case(input_file):
    """Load one of the four benchmark cases through the shared data loader."""
    return load_case_data(input_file)


def update_config_from_case1_row(config, row):
    """
    使用统一data_loader.build_input_t构造当前时间步节点。
    缺失的第4/5列车自动补0，因此兼容3B3T和5B5T工况。
    """
    input_t = build_input_t(row, config.SOC_ess)

    node_names = []
    node_types = []
    powers = []
    positions = []
    nodes = []

    for i, (power, pos) in enumerate(
        zip(input_t["brake_power"], input_t["brake_position"]),
        start=1,
    ):
        if power > 1e-9:
            node_names.append(f"B{i}")
            node_types.append(0)
            powers.append(float(power))
            positions.append(float(pos))
            nodes.append({
                "name": f"B{i}",
                "type": "brake",
                "power": float(power),
                "pos": float(pos),
            })

    for i, (power, pos) in enumerate(
        zip(input_t["traction_power"], input_t["traction_position"]),
        start=1,
    ):
        if power > 1e-9:
            node_names.append(f"T{i}")
            node_types.append(1)
            powers.append(-float(power))
            positions.append(float(pos))
            nodes.append({
                "name": f"T{i}",
                "type": "traction",
                # edge_builder uses positive demand magnitudes; config.P keeps
                # the negative sign above for the physical balance equation.
                "power": float(power),
                "pos": float(pos),
            })

    for ess_idx in range(config.ess_count):
        name = f"E{ess_idx + 1}"
        pos = float(config.ess_positions_km[ess_idx])
        node_names.append(name)
        node_types.append(2)
        powers.append(0.0)
        positions.append(pos)
        nodes.append({
            "name": name,
            "type": "storage",
            "power": 0.0,
            "pos": pos,
            "soc": float(config.SOC_ess[ess_idx]),
            "power_rated": float(config.P_s_max_ch[ess_idx]),
        })

    positions_array = np.asarray(positions, dtype=float)
    distance_matrix = np.abs(
        positions_array[:, None] - positions_array[None, :]
    )

    config.node_names = node_names
    config.node_types = np.asarray(node_types, dtype=int)
    config.P = np.asarray(powers, dtype=float)
    config.positions = positions_array
    config.speed = np.zeros(len(node_names), dtype=float)
    config.voltage = np.full(len(node_names), config.V0, dtype=float)
    config.distance_matrix = distance_matrix
    config.unified_nodes = nodes


def get_ess_index(config, node_i):
    ess_nodes = [i for i, t in enumerate(config.node_types) if t == 2]
    return ess_nodes.index(node_i)

# =====================
# 3. 边权重计算
# =====================
def calculate_weight_ij(config: LocalMaxCutConfig, i: int, j: int) -> float:
    Pi = config.P[i]
    Pj = config.P[j]

    type_i = config.node_types[i]
    type_j = config.node_types[j]

    distance_ij = config.distance_matrix[i][j]
    Z_ij = config.Z_unit * distance_ij

    # 制动-牵引
    if (type_i == 0 and type_j == 1) or (type_i == 1 and type_j == 0):
        p_brake = Pi if type_i == 0 else Pj
        p_tract = abs(Pj) if type_i == 0 else abs(Pi)

        return min(p_brake, p_tract) / (1 + config.gamma * Z_ij)

    # 制动-储能
    elif (type_i == 0 and type_j == 2) or (type_i == 2 and type_j == 0):
        p_brake = Pi if type_i == 0 else Pj
        ess_node = j if type_j == 2 else i
        e_idx = get_ess_index(config, ess_node)

        if config.SOC_ess[e_idx] >= config.SOC_max:
            return 0.0

        soc_factor = (
            config.SOC_max - config.SOC_ess[e_idx]
        ) / (config.SOC_max - config.SOC_min)

        soc_factor = min(max(soc_factor, 0.0), 1.0)

        return (
            min(p_brake, config.P_s_max_ch[e_idx])
            / (1 + config.gamma * Z_ij)
            * config.eta_c
            * soc_factor
        )

    # 牵引-储能
    elif (type_i == 1 and type_j == 2) or (type_i == 2 and type_j == 1):
        p_tract = abs(Pj) if type_i == 1 else abs(Pi)
        ess_node = j if type_j == 2 else i
        e_idx = get_ess_index(config, ess_node)

        if config.SOC_ess[e_idx] <= config.SOC_min:
            return 0.0

        soc_factor = (
            config.SOC_ess[e_idx] - config.SOC_min
        ) / (config.SOC_max - config.SOC_min)

        soc_factor = min(max(soc_factor, 0.0), 1.0)

        return (
            min(p_tract, config.P_s_max_dis[e_idx])
            / (1 + config.gamma * Z_ij)
            * config.eta_d
            * soc_factor
        )

    return 0.0


_STATIC_GRAPH_TEMPLATE = None


def build_local_graph(config: LocalMaxCutConfig) -> nx.Graph:
    """Build the configured graph without changing shared module imports.

    ``dynamic`` is the original behavior.  ``static`` freezes the edge set,
    weights, and distances observed at the first simulated time step, then
    reuses that template throughout the process.  The controlled runner
    disables resume so that the static reference is always t=0.
    """
    if not hasattr(config, "unified_nodes"):
        raise RuntimeError("请先调用update_config_from_case1_row。")

    dynamic_graph = nx.Graph()
    dynamic_graph.add_nodes_from(range(len(config.unified_nodes)))

    for i, j, weight in build_edges(config.unified_nodes):
        dynamic_graph.add_edge(
            i,
            j,
            weight=float(weight),
            distance=float(config.distance_matrix[i][j]),
        )

    if config.graph_mode == "dynamic":
        return dynamic_graph

    global _STATIC_GRAPH_TEMPLATE
    node_names = tuple(config.node_names)
    if _STATIC_GRAPH_TEMPLATE is None:
        _STATIC_GRAPH_TEMPLATE = {
            "node_names": node_names,
            "edges": [
                (
                    config.node_names[node_u],
                    config.node_names[node_v],
                    float(data["weight"]),
                    float(data["distance"]),
                )
                for node_u, node_v, data in dynamic_graph.edges(data=True)
            ],
        }
        print(
            "  [消融] 静态图已冻结为t=0边权模板："
            f"{len(_STATIC_GRAPH_TEMPLATE['edges'])}条边",
            flush=True,
        )

    static_graph = nx.Graph()
    static_graph.add_nodes_from(range(len(config.unified_nodes)))
    index_by_name = {
        name: index for index, name in enumerate(config.node_names)
    }
    for name_u, name_v, weight, distance in _STATIC_GRAPH_TEMPLATE["edges"]:
        if name_u not in index_by_name or name_v not in index_by_name:
            continue
        static_graph.add_edge(
            index_by_name[name_u],
            index_by_name[name_v],
            weight=weight,
            distance=distance,
        )
    return static_graph


# =====================
# 4. 目标函数
# =====================

def objective_function(
    G: nx.Graph,
    config: LocalMaxCutConfig,
    partition: np.ndarray
) -> Tuple[float, float, float]:

    cut = 0.0

    for u, v, d in G.edges(data=True):
        if partition[u] != partition[v]:
            cut += d["weight"]

    n = len(G.nodes)
    S_power = sum(config.P[i] for i in range(n) if partition[i] == 1)
    L_power = abs(sum(config.P[i] for i in range(n) if partition[i] == 0))

    penalty1 = abs(S_power - L_power)
    transfer_power = min(S_power, L_power)
    penalty2 = max(0, transfer_power - config.P_loss_max)

    F = cut - config.lambda1 * penalty1 - config.lambda2 * penalty2

    return F, cut, transfer_power


def adaptive_penalty(config: LocalMaxCutConfig) -> float:
    brake_power = sum(max(p, 0) for p in config.P)
    traction_power = sum(abs(min(p, 0)) for p in config.P)

    imbalance = abs(brake_power - traction_power) / max(brake_power + traction_power, 1e-9)
    lambda_balance = config.lambda_balance_base * (1 + 5 * imbalance)

    return lambda_balance


# =====================
# 5. QUBO + CIM 求解
# =====================

def cim_qubo_maxcut(
    G: nx.Graph,
    config: LocalMaxCutConfig,
    previous_partition=None
):
    from time import perf_counter

    n = len(G.nodes)

    ess_nodes = [i for i, t in enumerate(config.node_types) if t == 2]

    ess_pos = {}
    free_ess_nodes = []
    fixed_ess_state = {}

    for i in ess_nodes:
        e_idx = get_ess_index(config, i)

        if config.SOC_ess[e_idx] <= config.SOC_min:
            fixed_ess_state[i] = 0

        elif config.SOC_ess[e_idx] >= config.SOC_max:
            fixed_ess_state[i] = 1

        else:
            ess_pos[i] = len(free_ess_nodes)
            free_ess_nodes.append(i)

    # QUBO变量个数
    config.qubo_var_count = len(free_ess_nodes)
    config.total_ess_count = len(ess_nodes)

    z = kw.core.ndarray((len(free_ess_nodes),), "z", kw.core.Binary)

    node_expr = []

    for i in range(n):
        if config.node_types[i] == 0:
            node_expr.append(1)
        elif config.node_types[i] == 1:
            node_expr.append(0)
        elif i in fixed_ess_state:
            node_expr.append(fixed_ess_state[i])
        else:
            node_expr.append(z[ess_pos[i]])

    qubo_model = kw.qubo.QuboModel()

    # ===== 最大割目标函数 =====
    cut_expr = kw.core.quicksum([
        d["weight"] * (
            node_expr[u] + node_expr[v]
            - 2 * node_expr[u] * node_expr[v]
        )
        for u, v, d in G.edges(data=True)
    ])

    # ===== C3：功率平衡惩罚 =====
    balance_terms = []

    for i in range(n):
        if config.node_types[i] == 0:
            balance_terms.append(node_expr[i] * abs(config.P[i]))

        elif config.node_types[i] == 1:
            balance_terms.append(-(1 - node_expr[i]) * abs(config.P[i]))

        elif config.node_types[i] == 2:
            e_idx = get_ess_index(config, i)

            balance_terms.append(
                node_expr[i] * float(config.P_s_max_dis[e_idx])
                - (1 - node_expr[i]) * float(config.P_s_max_ch[e_idx])
            )

    balance_expr = kw.core.quicksum(balance_terms)
    lambda_balance = adaptive_penalty(config)

    # ===== C7：变电所容量惩罚 =====
    traction_demand = kw.core.quicksum([
        (1 - node_expr[i]) * abs(config.P[i])
        for i in range(n)
        if config.node_types[i] == 1
    ])

    ess_charge_demand = kw.core.quicksum([
        (1 - node_expr[i]) * float(config.P_s_max_ch[get_ess_index(config, i)])
        for i in range(n)
        if config.node_types[i] == 2
    ])

    internal_supply = kw.core.quicksum([
        node_expr[i] * abs(config.P[i])
        for i in range(n)
        if config.node_types[i] == 0
    ]) + kw.core.quicksum([
        node_expr[i] * float(config.P_s_max_dis[get_ess_index(config, i)])
        for i in range(n)
        if config.node_types[i] == 2
    ])

    substation_gap = traction_demand + ess_charge_demand - internal_supply - config.substation_max_power_kW
    substation_penalty = substation_gap * substation_gap

    # ===== Warm Start切换惩罚 =====
    switch_penalty = 0

    if previous_partition is not None:
        for i in free_ess_nodes:
            z_i = z[ess_pos[i]]
            prev_i = previous_partition[i]

            if prev_i == 0:
                switch_penalty += z_i
            else:
                switch_penalty += (1 - z_i)

    qubo_model.set_objective(
        -cut_expr
        + lambda_balance * balance_expr * balance_expr
        + config.lambda_substation * substation_penalty
        + config.lambda_switch * switch_penalty
    )

    kw.common.CheckpointManager.save_dir = "/tmp"

    optimizer = kw.cim.CIMOptimizer(
        task_name="case1_dynamic_maxcut_qubo_cim",
        wait=True
    )

    optimizer = kw.cim.PrecisionReducer(optimizer, 8)
    solver = kw.solver.SimpleSolver(optimizer)

    solver_start = perf_counter()
    sol_dict, qubo_val = solver.solve_qubo(qubo_model)
    solver_time = perf_counter() - solver_start

    partition = np.zeros(n, dtype=int)

    if len(free_ess_nodes) > 0:
        z_value = kw.core.get_array_val(z, sol_dict).astype(int)
    else:
        z_value = []

    for i in range(n):
        if config.node_types[i] == 0:
            partition[i] = 1
        elif config.node_types[i] == 1:
            partition[i] = 0
        elif i in fixed_ess_state:
            partition[i] = fixed_ess_state[i]
        else:
            partition[i] = z_value[ess_pos[i]]

    best_F, best_cut, best_transfer = objective_function(G, config, partition)

    kw.common.CheckpointManager.save_dir = None

    return partition.tolist(), best_F, best_cut, best_transfer, qubo_val, solver_time

# =====================

def _solve_all_steps_once_symbolic(case_df, config):
    """
    10ESS批量全约束QUBO版本。

    决策变量：
        z[t,s] = 0：第t步ESS_s位于荷组，按额定上限参与充电；
        z[t,s] = 1：第t步ESS_s位于源组，按额定上限参与放电。

    进入QUBO的约束/目标：
        C1：制动列车固定源组；
        C2：牵引列车固定荷组；
        C3：源荷功率平衡平方惩罚；
        C4-C5：SOC上下限的边界方向惩罚；
        C6：ESS功率上限由模式额定功率隐含限定；
        C7：变电所容量平方惩罚；
        C8：线路损耗的距离-功率代理惩罚；
        C9：弃能与电网补能代理惩罚；
        C10：充放电互斥由单一二元变量天然满足；
        C11：批次内SOC累计动态及目标SOC惩罚；
        切换约束：相邻时间步ESS模式切换惩罚。

    说明：
        受QUBO二次形式限制，SOC不等式、真实P²R/U²网损和连续功率分配
        采用二次代理/软约束表达；求解后仍进行真实物理后处理与硬约束校验。
    """
    total_steps = len(case_df)
    ess_count = config.ess_count
    build_start = perf_counter()
    print(
        f"  [构建] 开始生成 {total_steps} 步 × {ess_count} ESS 的QUBO目标项",
        flush=True,
    )

    z = kw.core.ndarray(
        (total_steps, ess_count),
        "z",
        kw.core.Binary
    )

    qubo_model = kw.qubo.QuboModel()
    all_objective_terms = []
    step_configs = []
    step_graphs = []

    # 批次开始SOC，用于构造跨步累计SOC表达式
    batch_initial_soc = np.asarray(
        config.SOC_ess,
        dtype=float
    ).copy()

    # 每个ESS的累计SOC线性表达式
    cumulative_soc_expr = [
        float(batch_initial_soc[s])
        for s in range(ess_count)
    ]

    for step_idx, (_, row) in enumerate(case_df.iterrows()):
        step_config = LocalMaxCutConfig()
        step_config.SOC_ess = batch_initial_soc.copy()
        step_config.soc_initialized = True

        update_config_from_case1_row(step_config, row)
        G = build_local_graph(step_config)

        step_configs.append(step_config)
        step_graphs.append(G)

        n = len(step_config.node_types)
        ess_nodes = [
            i for i, node_type in enumerate(step_config.node_types)
            if node_type == 2
        ]
        ess_index = {
            node: index
            for index, node in enumerate(ess_nodes)
        }

        node_expr = []
        for i in range(n):
            if step_config.node_types[i] == 0:
                node_expr.append(1)
            elif step_config.node_types[i] == 1:
                node_expr.append(0)
            else:
                node_expr.append(z[step_idx, ess_index[i]])

        # -------------------------------------------------
        # 最大割目标：功率匹配 + 距离 + SOC引导
        # -------------------------------------------------
        cut_expr = kw.core.quicksum([
            round(
                float(data["weight"]),
                config.qubo_round_digits
            ) * (
                node_expr[u]
                + node_expr[v]
                - 2 * node_expr[u] * node_expr[v]
            )
            for u, v, data in G.edges(data=True)
        ])

        brake_power = sum(
            max(float(p), 0.0)
            for p in step_config.P
        )
        traction_power = sum(
            abs(min(float(p), 0.0))
            for p in step_config.P
        )

        # -------------------------------------------------
        # C3：功率平衡
        # -------------------------------------------------
        balance_terms = []

        for i in range(n):
            if step_config.node_types[i] == 0:
                balance_terms.append(
                    node_expr[i] * round(
                        abs(float(step_config.P[i])),
                        config.qubo_round_digits
                    )
                )
            elif step_config.node_types[i] == 1:
                balance_terms.append(
                    -(1 - node_expr[i]) * round(
                        abs(float(step_config.P[i])),
                        config.qubo_round_digits
                    )
                )
            else:
                e_idx = ess_index[i]
                p_dis = round(
                    float(step_config.P_s_max_dis[e_idx]),
                    config.qubo_round_digits
                )
                p_ch = round(
                    float(step_config.P_s_max_ch[e_idx]),
                    config.qubo_round_digits
                )
                balance_terms.append(
                    node_expr[i] * p_dis
                    - (1 - node_expr[i]) * p_ch
                )

        balance_expr = kw.core.quicksum(balance_terms)
        lambda_balance = round(
            adaptive_penalty(step_config),
            config.qubo_round_digits
        )
        balance_penalty = (
            lambda_balance
            * balance_expr
            * balance_expr
        )

        # -------------------------------------------------
        # C7：变电所容量
        # -------------------------------------------------
        traction_demand = float(traction_power)

        ess_charge_demand = kw.core.quicksum([
            (1 - z[step_idx, s])
            * round(
                float(step_config.P_s_max_ch[s]),
                config.qubo_round_digits
            )
            for s in range(ess_count)
        ])

        internal_supply = (
            float(brake_power)
            + kw.core.quicksum([
                z[step_idx, s]
                * round(
                    float(step_config.P_s_max_dis[s]),
                    config.qubo_round_digits
                )
                for s in range(ess_count)
            ])
        )

        substation_gap = (
            traction_demand
            + ess_charge_demand
            - internal_supply
            - float(config.substation_max_power_kW)
        )
        substation_penalty = (
            config.lambda_substation
            * substation_gap
            * substation_gap
        )

        # -------------------------------------------------
        # C4-C5、C11：批次内SOC累计动态
        # -------------------------------------------------
        soc_dynamic_penalty = 0
        soc_boundary_penalty = 0

        for s in range(ess_count):
            p_ch = float(step_config.P_s_max_ch[s])
            p_dis = float(step_config.P_s_max_dis[s])
            capacity = float(step_config.ess_capacity_kWh[s])

            delta_soc_charge = (
                p_ch
                * config.dt
                / 3600.0
                * config.eta_c
                / capacity
            )
            delta_soc_discharge = (
                p_dis
                * config.dt
                / 3600.0
                / config.eta_d
                / capacity
            )

            cumulative_soc_expr[s] = (
                cumulative_soc_expr[s]
                + (1 - z[step_idx, s]) * delta_soc_charge
                - z[step_idx, s] * delta_soc_discharge
            )

            # 以安全目标SOC为中心的二次软约束
            soc_deviation = (
                cumulative_soc_expr[s]
                - config.soc_target
            )
            soc_dynamic_penalty += (
                config.lambda_soc_dynamic
                * soc_deviation
                * soc_deviation
            )

            # 靠近上限时惩罚充电；靠近下限时惩罚放电
            current_soc = float(batch_initial_soc[s])
            high_risk = max(
                0.0,
                (current_soc - 0.80)
                / max(config.SOC_max - 0.80, 1e-9)
            )
            low_risk = max(
                0.0,
                (0.30 - current_soc)
                / max(0.30 - config.SOC_min, 1e-9)
            )

            soc_boundary_penalty += (
                config.lambda_soc_boundary
                * high_risk
                * (1 - z[step_idx, s])
            )
            soc_boundary_penalty += (
                config.lambda_soc_boundary
                * low_risk
                * z[step_idx, s]
            )

        # -------------------------------------------------
        # C8：线路损耗代理项
        # 使用ESS与制动/牵引节点平均距离及额定功率平方作为代理
        # -------------------------------------------------
        loss_surrogate = 0

        brake_nodes = [
            i for i, tp in enumerate(step_config.node_types)
            if tp == 0
        ]
        traction_nodes = [
            i for i, tp in enumerate(step_config.node_types)
            if tp == 1
        ]

        for s_node in ess_nodes:
            s = ess_index[s_node]

            avg_brake_distance = (
                np.mean([
                    step_config.distance_matrix[b][s_node]
                    for b in brake_nodes
                ])
                if brake_nodes else 0.0
            )
            avg_traction_distance = (
                np.mean([
                    step_config.distance_matrix[t][s_node]
                    for t in traction_nodes
                ])
                if traction_nodes else 0.0
            )

            loss_scale = 1000.0 / (config.V0 * 1000.0) ** 2
            charge_loss_coeff = (
                loss_scale * config.Z_unit
                * avg_brake_distance
                * float(step_config.P_s_max_ch[s]) ** 2
            )
            discharge_loss_coeff = (
                loss_scale * config.Z_unit
                * avg_traction_distance
                * float(step_config.P_s_max_dis[s]) ** 2
            )

            loss_surrogate += (
                config.lambda_loss_qubo
                * (
                    (1 - z[step_idx, s]) * charge_loss_coeff
                    + z[step_idx, s] * discharge_loss_coeff
                )
            )

        # -------------------------------------------------
        # C9：弃能与电网补能代理
        # -------------------------------------------------
        total_charge_expr = kw.core.quicksum([
            (1 - z[step_idx, s])
            * float(step_config.P_s_max_ch[s])
            for s in range(ess_count)
        ])
        total_discharge_expr = kw.core.quicksum([
            z[step_idx, s]
            * float(step_config.P_s_max_dis[s])
            for s in range(ess_count)
        ])

        # 制动过剩由ESS充电能力吸收；牵引缺口由ESS放电能力补偿
        braking_surplus = max(
            brake_power - traction_power,
            0.0
        )
        traction_deficit = max(
            traction_power - brake_power,
            0.0
        )

        waste_gap = (
            float(braking_surplus)
            - total_charge_expr
        )
        grid_gap = (
            float(traction_deficit)
            - total_discharge_expr
        )

        waste_penalty = (
            config.lambda_waste_qubo
            * waste_gap
            * waste_gap
        )
        grid_penalty = (
            config.lambda_grid_qubo
            * grid_gap
            * grid_gap
        )

        discharge_reward = 0
        if (
            traction_deficit > 1e-12
            and config.lambda_discharge_reward_qubo > 0.0
        ):
            total_discharge_capacity = sum(
                float(step_config.P_s_max_dis[s])
                for s in range(ess_count)
            )
            demand_fraction = min(
                1.0,
                traction_deficit / max(total_discharge_capacity, 1e-12),
            )
            reward_terms = []
            for s_node in ess_nodes:
                s = ess_index[s_node]
                nearest_distance = min(
                    (
                        float(step_config.distance_matrix[t][s_node])
                        for t in traction_nodes
                    ),
                    default=0.0,
                )
                distance_efficiency = 1.0 / (
                    1.0 + step_config.gamma * step_config.Z_unit * nearest_distance
                )
                reward_terms.append(
                    z[step_idx, s]
                    * float(step_config.P_s_max_dis[s])
                    * distance_efficiency
                )
            discharge_reward = -config.lambda_discharge_reward_qubo * (
                demand_fraction * kw.core.quicksum(reward_terms)
            )

        # -------------------------------------------------
        # 模式切换惩罚
        # -------------------------------------------------
        switch_penalty = 0
        if step_idx > 0 and config.lambda_switch > 0:
            for s in range(ess_count):
                switch_expr = (
                    z[step_idx, s]
                    + z[step_idx - 1, s]
                    - 2
                    * z[step_idx, s]
                    * z[step_idx - 1, s]
                )
                switch_penalty += (
                    config.lambda_switch
                    * switch_expr
                )

        step_objective = (
            -cut_expr
            + balance_penalty
            + substation_penalty
            + soc_dynamic_penalty
            + soc_boundary_penalty
            + loss_surrogate
            + waste_penalty
            + grid_penalty
            + discharge_reward
            + switch_penalty
        )

        all_objective_terms.append(step_objective)
        print(
            f"  [构建] 已完成时间步 {step_idx + 1}/{total_steps}",
            flush=True,
        )

    print("  [矩阵] 正在展开并生成QUBO矩阵...", flush=True)
    qubo_model.set_objective(
        kw.core.quicksum(all_objective_terms)
    )

    config.qubo_var_count = total_steps * ess_count
    print(
        f"  [矩阵] QUBO已生成，共 {config.qubo_var_count} 个变量，"
        f"本地构建耗时 {perf_counter() - build_start:.2f} s",
        flush=True,
    )

    kw.common.CheckpointManager.save_dir = "/tmp"

    optimizer = kw.cim.CIMOptimizer(
        task_name=f"{CASE_NAME}_{BATCH_SIZE}s_unified_modules_qubo",
        wait=True
    )

    optimizer = kw.cim.PrecisionReducer(
        optimizer,
        precision=8
    )

    solver = kw.solver.SimpleSolver(optimizer)

    print(
        "  [CIM] 正在提交并等待结果；SDK默认每1分钟轮询一次...",
        flush=True,
    )
    solver_start = perf_counter()
    sol_dict, qubo_value = solver.solve_qubo(
        qubo_model
    )
    cim_call_time = perf_counter() - solver_start
    print(
        f"  [CIM] 已返回结果，等待耗时 {cim_call_time:.2f} s",
        flush=True,
    )

    z_values = kw.core.get_array_val(
        z,
        sol_dict
    ).astype(int)

    kw.common.CheckpointManager.save_dir = None

    return {
        "z_values": z_values,
        "qubo_value": qubo_value,
        "cim_call_time_s": cim_call_time,
        "qubo_variable_count": total_steps * ess_count,
        "step_configs": step_configs,
        "step_graphs": step_graphs
    }


def solve_all_steps_once(case_df, config, task_suffix=""):
    """Build the batch QUBO numerically, then submit it to the same CIM solver."""
    task_tag = os.environ.get("ESS_QUBO_TASK_TAG", "").strip()
    if task_tag and not task_tag.replace("_", "").isalnum():
        raise ValueError("ESS_QUBO_TASK_TAG must be alphanumeric or underscores")
    return solve_numeric_batch_qubo(
        case_df=case_df,
        config=config,
        config_factory=LocalMaxCutConfig,
        update_config=update_config_from_case1_row,
        graph_builder=build_local_graph,
        penalty_fn=adaptive_penalty,
        task_name=(
            f"{CASE_KEY}_{CASE_NAME}_{BATCH_SIZE}s_"
            f"unified_modules_qubo_numeric{task_suffix}"
            f"{('_' + task_tag) if task_tag else ''}"
        ),
    )

# 6. 真实功率分配与SOC更新
# =====================

def _calculate_transfer_result_shared_greedy(config, partition, input_t, solve_time_ms):
    """Decode QUBO preferences with distance-aware continuous power repair."""
    ess_nodes = [
        node_i
        for node_i, node_type in enumerate(config.node_types)
        if node_type == 2
    ]
    ess_states = np.asarray(
        [int(partition[node_i]) for node_i in ess_nodes],
        dtype=int,
    )
    charge_cap = np.asarray(shared_charge_limits(input_t["soc"]), dtype=float)
    discharge_cap = np.asarray(
        shared_discharge_limits(input_t["soc"]),
        dtype=float,
    )
    brake_power = float(sum(input_t["brake_power"]))
    traction_power = float(sum(input_t["traction_power"]))
    is_charge_step = brake_power >= traction_power
    target_power = (
        max(brake_power - traction_power, 0.0)
        if is_charge_step
        else max(traction_power - brake_power, 0.0)
    )
    caps = charge_cap if is_charge_step else discharge_cap
    preferred_state = 0 if is_charge_step else 1
    train_positions = [
        float(position)
        for position, power in zip(
            input_t["brake_position"] if is_charge_step else input_t["traction_position"],
            input_t["brake_power"] if is_charge_step else input_t["traction_power"],
        )
        if float(power) > 1e-9
    ]
    distances = np.asarray([
        min(
            (abs(float(position) - train_position) for train_position in train_positions),
            default=0.0,
        )
        for position in config.ess_positions_km
    ])
    preferred = np.flatnonzero(ess_states == preferred_state)
    fallback = np.flatnonzero(ess_states != preferred_state)
    preferred = preferred[np.argsort(distances[preferred], kind="stable")]
    fallback = fallback[np.argsort(distances[fallback], kind="stable")]

    request = np.zeros(config.ess_count, dtype=float)
    remaining = min(float(target_power), float(np.sum(caps)))
    fallback_power = 0.0
    fallback_ess_count = 0
    fallback_set = set(int(index) for index in fallback)
    for ess_index in np.concatenate([preferred, fallback]):
        allocated = min(remaining, float(caps[ess_index]))
        if allocated <= 1e-12:
            continue
        request[ess_index] = allocated
        remaining -= allocated
        if int(ess_index) in fallback_set:
            fallback_power += allocated
            fallback_ess_count += 1
        if remaining <= 1e-9:
            break

    charge_request = request if is_charge_step else np.zeros(config.ess_count)
    discharge_request = np.zeros(config.ess_count) if is_charge_step else request
    step_result, next_soc, flows = finalize_shared_step(
        input_t,
        charge_request.tolist(),
        discharge_request.tolist(),
        solve_time_ms,
    )

    direct_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "brake_to_traction"
    )
    charge_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "brake_to_storage"
    )
    discharge_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "storage_to_traction"
    )
    ess_charge = np.asarray(
        [
            step_result[f"ESS{ess_index}_charge_kW"]
            for ess_index in range(1, config.ess_count + 1)
        ],
        dtype=float,
    )
    ess_discharge = np.asarray(
        [
            step_result[f"ESS{ess_index}_discharge_kW"]
            for ess_index in range(1, config.ess_count + 1)
        ],
        dtype=float,
    )
    transfer = {
        "brake_power": float(step_result["brake_power_kW"]),
        "traction_power": float(step_result["traction_power_kW"]),
        "p_direct_power": float(step_result["p_direct_kW"]),
        "transfer_power": float(
            step_result["p_direct_kW"] + step_result["ess_charge_kW"]
        ),
        "direct_line_loss": direct_loss,
        "charge_line_loss": charge_loss,
        "discharge_line_loss": discharge_loss,
        "line_loss": float(step_result["loss_kW"]),
        "absorbed_power": float(step_result["absorbed_brake_power_kW"]),
        "discarded_power": float(step_result["wasted_power_kW"]),
        "grid_power": float(step_result["grid_power_kW"]),
        "ess_charge_power": ess_charge,
        "ess_discharge_power": ess_discharge,
        "absorption_rate": (
            float(step_result["absorbed_brake_power_kW"])
            / max(float(step_result["brake_power_kW"]), 1e-12)
        ),
        "min_voltage_V": float(step_result["min_voltage_V"]),
        "decoder_strategy": "qubo_priority_distance_repair",
        "decoder_fallback_power_kW": float(fallback_power),
        "decoder_fallback_ess_count": int(fallback_ess_count),
    }
    transfer.update({
        key: float(step_result[key])
        for key in (
            "p_direct_received_kW", "ess_charge_sent_kW",
            "ess_discharge_received_kW", "source_balance_error_kW",
            "traction_balance_error_kW", "paper_surrogate_absorbed_kW",
        )
        if key in step_result
    })
    return transfer, np.asarray(next_soc, dtype=float)


_DISPATCH_SCORE_EXPONENTS = (0.0, 0.5, 1.0, 1.5, 2.0)


def _evaluate_dispatch_request(input_t, request, is_charge_step):
    """Evaluate one continuous ESS split with the shared physical model."""
    zero_request = np.zeros(len(request), dtype=float)
    charge_request = request if is_charge_step else zero_request
    discharge_request = zero_request if is_charge_step else request
    step_result, _, _ = finalize_shared_step(
        input_t,
        charge_request.tolist(),
        discharge_request.tolist(),
        0.0,
    )
    weights = MILP_OBJECTIVE_WEIGHTS
    score = (
        weights["charge"] * float(step_result["ess_charge_kW"])
        + weights["discharge"] * float(step_result["ess_discharge_kW"])
        - weights["waste"] * float(step_result["wasted_power_kW"])
        - weights["grid"] * float(step_result["grid_power_kW"])
        - float(step_result["loss_kW"])
    )
    return float(score), step_result


def _loss_grid_aware_request(
    config,
    ess_states,
    input_t,
    is_charge_step,
    target_power,
    power_caps,
):
    """Refine a QUBO mode decision into a low-loss continuous power split."""
    power_caps = np.asarray(power_caps, dtype=float)
    preferred_state = 0 if is_charge_step else 1
    decoder_mode = str(
        getattr(config, "dispatch_decoder_mode", "soft")
    ).strip().lower()
    if decoder_mode == "hard":
        power_caps = np.where(
            np.asarray(ess_states, dtype=int) == preferred_state,
            power_caps,
            0.0,
        )
    elif decoder_mode != "soft":
        raise ValueError("dispatch_decoder_mode must be 'soft' or 'hard'")
    target_power = min(
        max(0.0, float(target_power)),
        float(np.sum(np.maximum(power_caps, 0.0))),
    )
    if target_power <= 1e-12:
        return np.zeros(config.ess_count, dtype=float), {
            "candidate_count": 1,
            "successful_optimizations": 0,
            "optimizer_attempts": 0,
            "optimizer_iterations": 0,
            "optimizer_failures": 0,
            "optimizer_statuses": "",
            "optimizer_messages": "",
            "objective_score": 0.0,
            "optimizer_available": minimize is not None,
        }

    train_positions = (
        input_t["brake_position"]
        if is_charge_step
        else input_t["traction_position"]
    )
    train_powers = (
        input_t["brake_power"]
        if is_charge_step
        else input_t["traction_power"]
    )
    location = np.asarray(
        shared_location_scores(
            config.ess_positions_km,
            train_positions,
            train_powers,
        ),
        dtype=float,
    )
    location = np.maximum(location, 1e-9)
    priority_multiplier = np.where(
        np.asarray(ess_states, dtype=int) == preferred_state,
        1.0 + float(config.dispatch_qubo_priority_boost),
        1.0,
    )

    candidate_starts = [
        np.asarray(
            shared_allocate_power(
                target_power,
                power_caps,
                location**exponent * priority_multiplier,
            ),
            dtype=float,
        )
        for exponent in _DISPATCH_SCORE_EXPONENTS
    ]
    step_index = int(round(float(input_t.get("time", 0))))
    random_generator = np.random.default_rng(
        DISPATCH_RANDOM_SEED + step_index * 1009
    )
    for _ in range(DISPATCH_RANDOM_STARTS):
        candidate_starts.append(
            np.asarray(
                shared_allocate_power(
                    target_power,
                    power_caps,
                    (random_generator.random(config.ess_count) + 0.05)
                    * priority_multiplier,
                ),
                dtype=float,
            )
        )

    def objective(candidate):
        score, _ = _evaluate_dispatch_request(
            input_t,
            np.asarray(candidate, dtype=float),
            is_charge_step,
        )
        return -score

    best_request = candidate_starts[0]
    best_objective = objective(best_request)
    for candidate in candidate_starts[1:]:
        candidate_objective = objective(candidate)
        if candidate_objective < best_objective:
            best_request = candidate
            best_objective = candidate_objective

    successful_optimizations = 0
    optimizer_attempts = 0
    optimizer_iterations = 0
    optimizer_failures = 0
    optimizer_statuses = []
    optimizer_messages = []
    if minimize is not None:
        bounds = [(0.0, float(cap)) for cap in power_caps]
        equality_constraint = {
            "type": "eq",
            "fun": lambda candidate: float(np.sum(candidate) - target_power),
        }
        for candidate_start in candidate_starts:
            optimizer_attempts += 1
            optimization = minimize(
                objective,
                candidate_start,
                method="SLSQP",
                bounds=bounds,
                constraints=equality_constraint,
                options={"maxiter": 180, "ftol": 1e-10, "disp": False},
            )
            optimizer_iterations += int(getattr(optimization, "nit", 0))
            optimizer_statuses.append(str(getattr(optimization, "status", "")))
            optimizer_messages.append(str(getattr(optimization, "message", "")))
            if optimization.success:
                successful_optimizations += 1
                candidate = np.asarray(optimization.x, dtype=float)
            else:
                optimizer_failures += 1
                candidate = candidate_start
            candidate_objective = objective(candidate)
            if candidate_objective < best_objective:
                best_request = candidate
                best_objective = candidate_objective

    return np.asarray(best_request, dtype=float), {
        "candidate_count": len(candidate_starts),
        "successful_optimizations": successful_optimizations,
        "optimizer_attempts": optimizer_attempts,
        "optimizer_iterations": optimizer_iterations,
        "optimizer_failures": optimizer_failures,
        "optimizer_statuses": ";".join(optimizer_statuses),
        "optimizer_messages": ";".join(optimizer_messages),
        "objective_score": -float(best_objective),
        "optimizer_available": minimize is not None,
    }


def calculate_transfer_result_shared(config, partition, input_t, solve_time_ms):
    """Use QUBO modes, then refine equal-capture solutions by loss and grid."""
    if minimize is None:
        return _calculate_transfer_result_shared_greedy(
            config,
            partition,
            input_t,
            solve_time_ms,
        )
    decoder_start = perf_counter()
    ess_nodes = [
        node_i
        for node_i, node_type in enumerate(config.node_types)
        if node_type == 2
    ]
    ess_states = np.asarray(
        [int(partition[node_i]) for node_i in ess_nodes],
        dtype=int,
    )
    brake_power = float(sum(input_t["brake_power"]))
    traction_power = float(sum(input_t["traction_power"]))
    is_charge_step = brake_power >= traction_power
    target_power = abs(brake_power - traction_power)
    power_caps = np.asarray(
        shared_charge_limits(input_t["soc"])
        if is_charge_step
        else shared_discharge_limits(input_t["soc"]),
        dtype=float,
    )
    request, diagnostics = _loss_grid_aware_request(
        config,
        ess_states,
        input_t,
        is_charge_step,
        target_power,
        power_caps,
    )
    zero_request = np.zeros(config.ess_count, dtype=float)
    charge_request = request if is_charge_step else zero_request
    discharge_request = zero_request if is_charge_step else request
    step_result, next_soc, flows = finalize_shared_step(
        input_t,
        charge_request.tolist(),
        discharge_request.tolist(),
        solve_time_ms,
    )
    decoder_time_ms = (perf_counter() - decoder_start) * 1000.0
    total_solve_time_ms = float(solve_time_ms) + decoder_time_ms
    step_result["solve_time_ms"] = total_solve_time_ms

    direct_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "brake_to_traction"
    )
    charge_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "brake_to_storage"
    )
    discharge_loss = sum(
        float(flow["loss_kW"])
        for flow in flows
        if flow["type"] == "storage_to_traction"
    )
    ess_charge = np.asarray(
        [
            step_result[f"ESS{ess_index}_charge_kW"]
            for ess_index in range(1, config.ess_count + 1)
        ],
        dtype=float,
    )
    ess_discharge = np.asarray(
        [
            step_result[f"ESS{ess_index}_discharge_kW"]
            for ess_index in range(1, config.ess_count + 1)
        ],
        dtype=float,
    )
    preferred_state = 0 if is_charge_step else 1
    actual_request = ess_charge if is_charge_step else ess_discharge
    fallback_mask = ess_states != preferred_state
    fallback_power = float(np.sum(actual_request[fallback_mask]))
    fallback_ess_count = int(
        np.count_nonzero((actual_request > 1e-9) & fallback_mask)
    )
    transfer = {
        "brake_power": float(step_result["brake_power_kW"]),
        "traction_power": float(step_result["traction_power_kW"]),
        "p_direct_power": float(step_result["p_direct_kW"]),
        "transfer_power": float(
            step_result["p_direct_kW"] + step_result["ess_charge_kW"]
        ),
        "direct_line_loss": direct_loss,
        "charge_line_loss": charge_loss,
        "discharge_line_loss": discharge_loss,
        "line_loss": float(step_result["loss_kW"]),
        "absorbed_power": float(step_result["absorbed_brake_power_kW"]),
        "discarded_power": float(step_result["wasted_power_kW"]),
        "grid_power": float(step_result["grid_power_kW"]),
        "ess_charge_power": ess_charge,
        "ess_discharge_power": ess_discharge,
        "absorption_rate": (
            float(step_result["absorbed_brake_power_kW"])
            / max(float(step_result["brake_power_kW"]), 1e-12)
        ),
        "min_voltage_V": float(step_result["min_voltage_V"]),
        "decoder_strategy": "qubo_multistart_loss_grid_refinement",
        "decoder_fallback_power_kW": fallback_power,
        "decoder_fallback_ess_count": fallback_ess_count,
        "decoder_optimizer_time_ms": decoder_time_ms,
        "decoder_candidate_count": diagnostics["candidate_count"],
        "decoder_successful_optimizations": diagnostics[
            "successful_optimizations"
        ],
        "decoder_optimizer_attempts": diagnostics["optimizer_attempts"],
        "decoder_optimizer_iterations": diagnostics["optimizer_iterations"],
        "decoder_optimizer_failures": diagnostics["optimizer_failures"],
        "decoder_optimizer_statuses": diagnostics["optimizer_statuses"],
        "decoder_optimizer_messages": diagnostics["optimizer_messages"],
        "decoder_objective_score": diagnostics["objective_score"],
        "total_solve_time_ms": total_solve_time_ms,
    }
    transfer.update({
        key: float(step_result[key])
        for key in (
            "p_direct_received_kW", "ess_charge_sent_kW",
            "ess_discharge_received_kW", "source_balance_error_kW",
            "traction_balance_error_kW", "paper_surrogate_absorbed_kW",
        )
        if key in step_result
    })
    return transfer, np.asarray(next_soc, dtype=float)


def calculate_transfer_result(config, partition, G):
    """Compatibility entry point; all flows use the unified graph-aware decoder."""
    return calculate_transfer_result_physical(config, partition, G)

    # Legacy implementation retained below only for source-history reference;
    # it is unreachable so ESS discharge can no longer bypass graph G.
    U = config.V0 * 1000.0

    brake_nodes = [
        i for i in range(len(config.P))
        if config.node_types[i] == 0
    ]

    traction_nodes = [
        i for i in range(len(config.P))
        if config.node_types[i] == 1
    ]

    ess_nodes = [
        i for i in range(len(config.P))
        if config.node_types[i] == 2
    ]

    ess_count = len(ess_nodes)

    brake_power = sum(
        max(config.P[i], 0.0)
        for i in brake_nodes
    )

    traction_power = sum(
        abs(min(config.P[i], 0.0))
        for i in traction_nodes
    )

    brake_remaining = {
        i: max(config.P[i], 0.0)
        for i in brake_nodes
    }

    traction_remaining = {
        i: abs(min(config.P[i], 0.0))
        for i in traction_nodes
    }

    # =====================================================
    # 每个ESS分别根据SOC计算当前时间步允许的最大充/放电功率
    # =====================================================

    soc_room_kWh = np.maximum(
        0.0,
        (config.SOC_max - config.SOC_ess)
        * config.ess_capacity_kWh
    )

    soc_energy_kWh = np.maximum(
        0.0,
        (config.SOC_ess - config.SOC_min)
        * config.ess_capacity_kWh
    )

    actual_P_ch_max = np.minimum(
        config.P_s_max_ch,
        soc_room_kWh
        * 3600.0
        / config.dt
        / config.eta_c
    )

    actual_P_dis_max = np.minimum(
        config.P_s_max_dis,
        soc_energy_kWh
        * 3600.0
        * config.eta_d
        / config.dt
    )

    transfer_power = 0.0
    line_loss = 0.0
    absorbed_direct = 0.0
    absorbed_ess = 0.0
    p_direct_power = 0.0

    ess_charge_power = np.zeros(
        ess_count,
        dtype=float
    )

    ess_discharge_power = np.zeros(
        ess_count,
        dtype=float
    )

    # =====================================================
    # 1. 制动列车 -> 牵引列车
    # 按边权重比例进行分配
    # =====================================================

    bt_edges = []

    for b in brake_nodes:
        for t in traction_nodes:
            if partition[b] == partition[t]:
                continue

            if not G.has_edge(b, t):
                continue

            bt_edges.append(
                (b, t, float(G[b][t]["weight"]))
            )

    total_bt_weight = sum(
        w for _, _, w in bt_edges
    )

    if total_bt_weight > 1e-12:
        direct_total = min(
            brake_power,
            traction_power
        )

        for b, t, weight in bt_edges:
            alpha = weight / total_bt_weight

            allocated_P = direct_total * alpha

            P = min(
                allocated_P,
                brake_remaining[b],
                traction_remaining[t]
            )

            if P <= 1e-12:
                continue

            distance = config.distance_matrix[b][t]
            R = config.Z_unit * distance

            loss = (
                (P * 1000.0) ** 2
                * R
                / (U ** 2)
                / 1000.0
            )

            effective_P = max(
                P - loss,
                0.0
            )

            transfer_power += P
            p_direct_power += P
            line_loss += loss
            absorbed_direct += effective_P

            brake_remaining[b] -= P
            traction_remaining[t] -= P

    # =====================================================
    # 2. 剩余制动能量 -> 各储能站充电
    # =====================================================

    bs_edges = []

    for b in brake_nodes:
        for s in ess_nodes:
            # ESS在荷组时才充电
            if partition[s] != 0:
                continue

            if partition[b] == partition[s]:
                continue

            if not G.has_edge(b, s):
                continue

            bs_edges.append(
                (b, s, float(G[b][s]["weight"]))
            )

    total_bs_weight = sum(
        w for _, _, w in bs_edges
    )

    brake_left = sum(
        brake_remaining.values()
    )

    if (
        total_bs_weight > 1e-12
        and brake_left > 1e-12
    ):
        for b, s, weight in bs_edges:
            e_idx = get_ess_index(config, s)

            available_charge_power = max(
                0.0,
                float(actual_P_ch_max[e_idx])
                - ess_charge_power[e_idx]
            )

            if available_charge_power <= 1e-12:
                continue

            alpha = weight / total_bs_weight

            allocated_P = brake_left * alpha

            P = min(
                allocated_P,
                brake_remaining[b],
                available_charge_power
            )

            if P <= 1e-12:
                continue

            distance = config.distance_matrix[b][s]
            R = config.Z_unit * distance

            loss = (
                (P * 1000.0) ** 2
                * R
                / (U ** 2)
                / 1000.0
            )

            effective_P = (
                max(P - loss, 0.0)
                * config.eta_c
            )

            transfer_power += P
            line_loss += loss
            absorbed_ess += effective_P
            ess_charge_power[e_idx] += P

            brake_remaining[b] -= P

    # =====================================================
    # 3. 各储能站放电 -> 牵引列车
    # 注意：ESS放电不能计入再生制动消纳量
    # =====================================================

    for s in ess_nodes:
        # ESS在源组时才放电
        if partition[s] != 1:
            continue

        e_idx = get_ess_index(config, s)

        demand_gap = sum(
            traction_remaining.values()
        )

        if demand_gap <= 1e-12:
            continue

        available_discharge_power = float(
            actual_P_dis_max[e_idx]
        )

        discharge_total = min(
            demand_gap,
            available_discharge_power
        )

        if discharge_total <= 1e-12:
            continue

        remaining_discharge = discharge_total

        # 按牵引需求比例分配
        valid_traction_nodes = [
            t for t in traction_nodes
            if traction_remaining[t] > 1e-12
        ]

        total_demand = sum(
            traction_remaining[t]
            for t in valid_traction_nodes
        )

        if total_demand <= 1e-12:
            continue

        for t in valid_traction_nodes:
            demand_ratio = (
                traction_remaining[t]
                / total_demand
            )

            supply = min(
                remaining_discharge * demand_ratio,
                traction_remaining[t]
            )

            if supply <= 1e-12:
                continue

            traction_remaining[t] -= supply
            ess_discharge_power[e_idx] += supply

    # =====================================================
    # 汇总指标
    # =====================================================

    absorbed_power = (
        absorbed_direct
        + absorbed_ess
    )

    discarded_power = max(
        sum(brake_remaining.values()),
        0.0
    )

    grid_power = max(
        sum(traction_remaining.values()),
        0.0
    )

    absorption_rate = (
        absorbed_power / brake_power
        if brake_power > 1e-12
        else 0.0
    )

    absorption_rate = float(
        np.clip(
            absorption_rate,
            0.0,
            1.0
        )
    )

    return {
        "brake_power": brake_power,
        "traction_power": traction_power,
        "p_direct_power": p_direct_power,
        "transfer_power": transfer_power,
        "line_loss": line_loss,
        "absorbed_power": absorbed_power,
        "discarded_power": discarded_power,
        "grid_power": grid_power,
        "ess_charge_power": ess_charge_power,
        "ess_discharge_power": ess_discharge_power,
        "absorption_rate": absorption_rate
    }


def update_soc_by_power(
    config,
    ess_charge_power,
    ess_discharge_power
):
    """
    更新SOC，并返回裁剪前SOC及越界标志。

    这样不会因为np.clip而掩盖SOC越界。
    """
    ess_charge_power = np.asarray(
        ess_charge_power,
        dtype=float
    )
    ess_discharge_power = np.asarray(
        ess_discharge_power,
        dtype=float
    )

    delta_charge_kWh = (
        ess_charge_power
        * config.dt
        / 3600.0
        * config.eta_c
    )
    delta_discharge_kWh = (
        ess_discharge_power
        * config.dt
        / 3600.0
        / config.eta_d
    )

    delta_soc = (
        delta_charge_kWh
        - delta_discharge_kWh
    ) / config.ess_capacity_kWh

    raw_soc = config.SOC_ess + delta_soc

    soc_violation = bool(
        np.any(raw_soc < config.SOC_min - 1e-9)
        or np.any(raw_soc > config.SOC_max + 1e-9)
    )

    config.SOC_ess = np.clip(
        raw_soc,
        config.SOC_min,
        config.SOC_max
    )

    return raw_soc, soc_violation


# =====================
# 7. Summary
# =====================

def compute_summary(result_df, config):
    total_regen = result_df["brake_power_kW"].sum() * config.dt / 3600
    used = result_df["absorbed_brake_power_kW"].sum() * config.dt / 3600
    waste = result_df["wasted_brake_power_kW"].sum() * config.dt / 3600
    grid = result_df["grid_power_kW"].sum() * config.dt / 3600
    loss = result_df["loss_kW"].sum() * config.dt / 3600

    summary_result = pd.DataFrame({
        "指标": [
            "方法名称",
            "总再生能量",
            "有效消纳能量",
            "再生消纳率",
            "弃能",
            "电网补能",
            "网损",
            "初始SOC",
            "最终SOC",
            "总求解时间",
            "平均单步时间",
            "电压越限次数",
            "功率越限次数",
            "约束可行步数",
            "平均QUBO变量数",
            "最大QUBO变量数",
        ],
        "数值": [
            f"Dynamic Max-Cut + QUBO + {config.ess_count}ESS",
            total_regen,
            used,
            used / total_regen * 100 if total_regen > 0 else 0,
            waste,
            grid,
            loss,
            50.0,
            result_df["soc_avg_percent"].iloc[-1],
            result_df["total_time_s"].sum(),
            result_df["total_time_s"].mean() * 1000,
            int(result_df["voltage_violation"].sum()),
            int(result_df["power_violation"].sum()),
            int(result_df["feasible"].sum()),
            result_df["qubo_variable_count"].mean(),
            result_df["qubo_variable_count"].max(),
        ],
        "单位": [
            "-",
            "kWh",
            "kWh",
            "%",
            "kWh",
            "kWh",
            "kWh",
            "%",
            "%",
            "s",
            "ms",
            "次",
            "次",
            "步",
            "个",
            "个",
        ]
    })

    return summary_result


# =====================
# 8. 主程序：10个储能，每 BATCH_SIZE 个时间步构建一个QUBO
# =====================
if __name__ == "__main__":

    if not USE_QUANTUM_INTERFACE:
        raise RuntimeError("Quantum interface must remain enabled for this benchmark.")
    is_local_experiment = (
        QUANTUM_SOLVER_BACKEND == "scip"
        and os.environ.get("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT") == "1"
    )
    if QUANTUM_SOLVER_BACKEND != "cim" and not is_local_experiment:
        raise RuntimeError("Production runs require the CIM backend.")

    case_df = load_benchmark_case(INPUT_FILE)

    if len(case_df) == 0:
        raise ValueError("输入工况为空，请检查输入文件。")

    config = LocalMaxCutConfig()
    config.sim_steps = len(case_df)
    config.SOC_ess = np.full(config.ess_count, SOC_INIT, dtype=float)
    config.soc_initialized = True

    expected_submission_count = int(np.ceil(len(case_df) / BATCH_SIZE))

    print(
        f"\n========== {config.ess_count}ESS、{BATCH_SIZE} s分批QUBO求解开始 =========="
    )
    print(f"总时间步数：{len(case_df)}")
    print(f"每批时间步数：{BATCH_SIZE}")
    print(f"储能数量：{config.ess_count}")
    print(f"预计CIM提交次数：{expected_submission_count}")
    print(f"完整批次显式QUBO变量数：{BATCH_SIZE * config.ess_count}")

    time_series_file = (
        EXCEL_DIR / f"TimeSeries_Result_{config.ess_count}ESS_{BATCH_SIZE}sBatch.csv"
    )
    batch_summary_file = (
        EXCEL_DIR / f"Batch_Summary_{config.ess_count}ESS_{BATCH_SIZE}sBatch.csv"
    )
    summary_file = (
        EXCEL_DIR / f"Summary_Result_{config.ess_count}ESS_{BATCH_SIZE}sBatch.csv"
    )
    report_file = (
        TXT_DIR / f"Result_Report_{config.ess_count}ESS_{BATCH_SIZE}sBatch.txt"
    )
    partial_time_series_file = time_series_file.with_name(
        f".{time_series_file.stem}.partial.csv"
    )
    partial_batch_summary_file = batch_summary_file.with_name(
        f".{batch_summary_file.stem}.partial.csv"
    )
    resume_enabled = os.environ.get("ESS_QUBO_RESUME", "1") == "1"

    records = []
    batch_summary_records = []
    total_cim_time_s = 0.0
    submission_count = 0
    resume_start = 0

    if (
        resume_enabled
        and partial_time_series_file.is_file()
        and partial_batch_summary_file.is_file()
    ):
        partial_result_df = pd.read_csv(partial_time_series_file)
        partial_batch_df = pd.read_csv(partial_batch_summary_file)
        if not partial_result_df.empty and not partial_batch_df.empty:
            records = partial_result_df.to_dict("records")
            batch_summary_records = partial_batch_df.to_dict("records")
            resume_start = int(partial_result_df["time_s"].max()) + 1
            submission_count = int(partial_batch_df["batch_id"].max())
            total_cim_time_s = float(
                partial_batch_df["cim_call_time_s"].sum()
            )
            config.SOC_ess = np.asarray(
                [
                    float(
                        partial_result_df.iloc[-1][
                            f"soc_{ess_idx + 1}_percent"
                        ]
                    )
                    / 100.0
                    for ess_idx in range(config.ess_count)
                ],
                dtype=float,
            )
            if config.cross_batch_switch_enabled:
                config.previous_ess_modes = np.asarray(
                    [
                        int(
                            partial_result_df.iloc[-1][
                                f"ess{ess_idx + 1}_state"
                            ]
                        )
                        for ess_idx in range(config.ess_count)
                    ],
                    dtype=int,
                )
            print(
                f"[恢复] 已载入{submission_count}批、{resume_start}个时间步，"
                f"将从t={resume_start:03d}继续。"
            )

    for batch_start in range(resume_start, len(case_df), BATCH_SIZE):

        batch_end_to_end_start = perf_counter()

        batch_end = min(batch_start + BATCH_SIZE, len(case_df))
        batch_df = case_df.iloc[batch_start:batch_end].reset_index(drop=True)

        batch_id = submission_count + 1
        batch_start_soc = config.SOC_ess.copy()
        qubo_proxy_soc = batch_start_soc.copy()

        print(
            f"\n========== 构建并提交第 {batch_id}个QUBO =========="
        )
        print(f"时间范围：{batch_start} ～ {batch_end - 1}")
        print(f"本批时间步数：{len(batch_df)}")
        print(f"本批QUBO变量数：{len(batch_df) * config.ess_count}")
        print(f"本批初始SOC：{np.round(batch_start_soc * 100.0, 4).tolist()} %")

        batch_result = solve_all_steps_once(
            case_df=batch_df,
            config=config,
            task_suffix=f"_B{batch_id:02d}",
        )

        batch_z_values = np.asarray(
            batch_result["z_values"],
            dtype=int
        )

        expected_shape = (len(batch_df), config.ess_count)

        if batch_z_values.shape != expected_shape:
            raise ValueError(
                f"第{batch_id}批返回形状错误："
                f"实际为{batch_z_values.shape}，应为{expected_shape}"
            )

        batch_qubo_value = float(batch_result["qubo_value"])
        batch_cim_time_s = float(batch_result["cim_call_time_s"])
        batch_qubo_variable_count = int(batch_result["qubo_variable_count"])
        batch_solver_backend = str(batch_result.get("solver_backend", "CIM"))
        batch_solver_status = str(batch_result.get("solver_status", "completed"))
        batch_solver_gap = float(batch_result.get("solver_gap", np.nan))
        batch_solver_nodes = float(batch_result.get("solver_nodes", np.nan))
        batch_qubo_nonzero_count = int(
            batch_result.get("qubo_nonzero_count", 0)
        )
        batch_qubo_density_percent = float(
            batch_result.get("qubo_density_percent", np.nan)
        )
        batch_qubo_abs_coefficient_min = float(
            batch_result.get("qubo_abs_coefficient_min", np.nan)
        )
        batch_qubo_abs_coefficient_max = float(
            batch_result.get("qubo_abs_coefficient_max", np.nan)
        )
        phase_timings = dict(batch_result.get("phase_timings", {}))
        batch_graph_build_s = 0.0
        batch_decoder_s = 0.0
        batch_validation_s = 0.0

        total_cim_time_s += batch_cim_time_s
        submission_count += 1

        for local_step_idx, (_, row) in enumerate(batch_df.iterrows()):

            t = int(row["time_s"]) if "time_s" in row.index else batch_start + local_step_idx

            graph_build_start = perf_counter()
            input_t = build_input_t(row, config.SOC_ess)
            update_config_from_case1_row(config, row)
            G = build_local_graph(config)
            step_graph_build_s = perf_counter() - graph_build_start
            batch_graph_build_s += step_graph_build_s

            partition = np.zeros(len(config.node_types), dtype=int)

            step_solve_time_ms = float(
                batch_cim_time_s / max(len(batch_df), 1) * 1000.0
            )

            ess_counter = 0
            for node_i, node_type in enumerate(config.node_types):
                if node_type == 0:
                    partition[node_i] = 1
                elif node_type == 1:
                    partition[node_i] = 0
                else:
                    partition[node_i] = int(
                        batch_z_values[local_step_idx, ess_counter]
                    )
                    ess_counter += 1

            if ess_counter != config.ess_count:
                raise ValueError(
                    f"t={t}时检测到{ess_counter}个ESS，"
                    f"应为{config.ess_count}个。"
                )

            step_modes = batch_z_values[local_step_idx]
            qubo_proxy_charge_kW = (
                (1 - step_modes) * config.P_s_max_ch
            )
            qubo_proxy_discharge_kW = (
                step_modes * config.P_s_max_dis
            )
            qubo_mode_balance_error_kW = (
                sum(input_t["brake_power"])
                + float(np.sum(qubo_proxy_discharge_kW))
                - sum(input_t["traction_power"])
                - float(np.sum(qubo_proxy_charge_kW))
            )
            qubo_balance_resolution_kW = 0.5 * min(
                float(np.min(config.P_s_max_ch)),
                float(np.min(config.P_s_max_dis)),
            )
            qubo_balance_violation = bool(
                abs(qubo_mode_balance_error_kW)
                > qubo_balance_resolution_kW + 1e-9
            )
            qubo_substation_gap_kW = max(
                0.0,
                sum(input_t["traction_power"])
                + float(np.sum(qubo_proxy_charge_kW))
                - sum(input_t["brake_power"])
                - float(np.sum(qubo_proxy_discharge_kW))
                - config.substation_max_power_kW,
            )
            qubo_proxy_soc = (
                qubo_proxy_soc
                + qubo_proxy_charge_kW
                * config.dt
                / 3600.0
                * config.eta_c
                / config.ess_capacity_kWh
                - qubo_proxy_discharge_kW
                * config.dt
                / 3600.0
                / config.eta_d
                / config.ess_capacity_kWh
            )
            qubo_soc_violation = bool(
                np.any(qubo_proxy_soc < config.SOC_min - 1e-9)
                or np.any(qubo_proxy_soc > config.SOC_max + 1e-9)
            )

            transfer, next_soc = calculate_transfer_result_shared(
                config,
                partition.tolist(),
                input_t,
                step_solve_time_ms,
            )
            step_solve_time_ms = float(
                transfer.get("total_solve_time_ms", step_solve_time_ms)
            )
            step_decoder_s = float(
                transfer.get("decoder_optimizer_time_ms", 0.0)
            ) / 1000.0
            batch_decoder_s += step_decoder_s
            validation_start = perf_counter()
            raw_soc = next_soc.copy()
            soc_violation = bool(
                np.any(raw_soc < config.SOC_min - 1e-9)
                or np.any(raw_soc > config.SOC_max + 1e-9)
            )
            config.SOC_ess = np.clip(raw_soc, config.SOC_min, config.SOC_max)

            ess_charge = np.asarray(
                transfer["ess_charge_power"],
                dtype=float
            )
            ess_discharge = np.asarray(
                transfer["ess_discharge_power"],
                dtype=float
            )

            # ===== 真实硬约束校验 =====
            power_balance_error_kW = (
                float(transfer["brake_power"])
                + float(np.sum(ess_discharge))
                + float(transfer["grid_power"])
                - float(transfer["traction_power"])
                - float(np.sum(ess_charge))
                - float(transfer["discarded_power"])
                - float(transfer["line_loss"])
            )

            power_violation = bool(
                np.any(ess_charge > config.P_s_max_ch + 1e-9)
                or np.any(ess_discharge > config.P_s_max_dis + 1e-9)
            )

            substation_violation = bool(
                transfer["grid_power"]
                > config.substation_max_power_kW + 1e-9
            )

            loss_violation = bool(
                transfer["line_loss"]
                > config.P_loss_max + 1e-9
            )

            # 简化节点电压估计：按总传输电流与最大有效距离估算压降。
            # 该估计用于统一Benchmark可行性检查，不替代完整潮流计算。
            total_transfer_kW = (
                float(transfer["transfer_power"])
                + float(np.sum(ess_discharge))
            )
            max_distance_km = (
                float(np.max(config.distance_matrix))
                if config.distance_matrix.size > 0
                else 0.0
            )
            estimated_current_A = (
                total_transfer_kW * 1000.0
                / max(config.V0 * 1000.0, 1e-9)
            )
            estimated_voltage_drop_V = (
                estimated_current_A
                * config.Z_unit
                * max_distance_km
            )
            estimated_min_voltage_kV = (
                config.V0
                - estimated_voltage_drop_V / 1000.0
            )
            estimated_min_voltage_kV = float(transfer["min_voltage_V"]) / 1000.0
            voltage_violation = bool(
                estimated_min_voltage_kV < config.V_min - 1e-9
                or estimated_min_voltage_kV > config.V_max + 1e-9
            )

            feasible_step = bool(
                abs(power_balance_error_kW) <= config.balance_tolerance_kW
                and not soc_violation
                and not voltage_violation
                and not power_violation
                and not substation_violation
                and not loss_violation
            )
            step_validation_s = perf_counter() - validation_start
            batch_validation_s += step_validation_s

            record = {
                "time_s": t,
                "batch_id": batch_id,
                "batch_local_step": local_step_idx,
                "brake_power_kW": float(transfer["brake_power"]),
                "traction_power_kW": float(transfer["traction_power"]),
                "p_direct_kW": float(transfer.get("p_direct_power", 0.0)),
                "ess_charge_kW": float(np.sum(ess_charge)),
                "ess_discharge_kW": float(np.sum(ess_discharge)),
                "wasted_power_kW": float(transfer["discarded_power"]),
                "soc_average": float(np.mean(config.SOC_ess)),
                "solve_time_ms": step_solve_time_ms,
                "power_surplus_kW": float(
                    transfer["brake_power"] - transfer["traction_power"]
                ),
                "ess_total_charge_kW": float(np.sum(ess_charge)),
                "ess_total_discharge_kW": float(np.sum(ess_discharge)),
                "soc_avg_percent": float(np.mean(config.SOC_ess) * 100.0),
                "grid_power_kW": float(transfer["grid_power"]),
                "direct_line_loss_kW": float(transfer["direct_line_loss"]),
                "ess_charge_line_loss_kW": float(transfer["charge_line_loss"]),
                "ess_discharge_line_loss_kW": float(transfer["discharge_line_loss"]),
                "loss_kW": float(transfer["line_loss"]),
                "absorbed_brake_power_kW": float(transfer["absorbed_power"]),
                "wasted_brake_power_kW": float(transfer["discarded_power"]),
                "absorption_rate_percent": float(
                    transfer["absorption_rate"] * 100.0
                ),
                "batch_qubo_variable_count": batch_qubo_variable_count,
                "batch_qubo_value": batch_qubo_value,
                "batch_solver_backend": batch_solver_backend,
                "batch_solver_status": batch_solver_status,
                "batch_solver_gap": batch_solver_gap,
                "batch_solver_nodes": batch_solver_nodes,
                "ablation_graph_mode": config.graph_mode,
                "ablation_maxcut_enabled": config.maxcut_enabled,
                "ablation_decoder_priority_boost": (
                    config.dispatch_qubo_priority_boost
                ),
                "batch_cim_call_time_s": (
                    batch_cim_time_s if local_step_idx == 0 else 0.0
                ),
                "phase_graph_build_ms": step_graph_build_s * 1000.0,
                "phase_decoder_ms": step_decoder_s * 1000.0,
                "phase_validation_ms": step_validation_s * 1000.0,
                "qubo_mode_balance_error_kW": qubo_mode_balance_error_kW,
                "qubo_balance_resolution_kW": qubo_balance_resolution_kW,
                "qubo_balance_violation": qubo_balance_violation,
                "qubo_substation_gap_kW": qubo_substation_gap_kW,
                "qubo_substation_violation": qubo_substation_gap_kW > 1e-9,
                "qubo_proxy_soc_min_percent": float(
                    np.min(qubo_proxy_soc) * 100.0
                ),
                "qubo_proxy_soc_max_percent": float(
                    np.max(qubo_proxy_soc) * 100.0
                ),
                "qubo_soc_violation": qubo_soc_violation,
                "partition": str(partition.tolist()),
                "power_balance_error_kW": power_balance_error_kW,
                "soc_violation": soc_violation,
                "substation_violation": substation_violation,
                "loss_violation": loss_violation,
                "dispatch_loss_weight": config.dispatch_loss_weight,
                "decoder_strategy": transfer["decoder_strategy"],
                "decoder_fallback_power_kW": transfer["decoder_fallback_power_kW"],
                "decoder_fallback_ess_count": transfer["decoder_fallback_ess_count"],
                "decoder_optimizer_time_ms": transfer.get(
                    "decoder_optimizer_time_ms", 0.0
                ),
                "decoder_candidate_count": transfer.get("decoder_candidate_count", 1),
                "decoder_successful_optimizations": transfer.get(
                    "decoder_successful_optimizations", 0
                ),
                "decoder_optimizer_attempts": transfer.get(
                    "decoder_optimizer_attempts", 0
                ),
                "decoder_optimizer_iterations": transfer.get(
                    "decoder_optimizer_iterations", 0
                ),
                "decoder_optimizer_failures": transfer.get(
                    "decoder_optimizer_failures", 0
                ),
                "decoder_optimizer_statuses": transfer.get(
                    "decoder_optimizer_statuses", ""
                ),
                "decoder_optimizer_messages": transfer.get(
                    "decoder_optimizer_messages", ""
                ),
                "decoder_objective_score": transfer.get("decoder_objective_score", np.nan),
                "qubo_loss_weight": config.lambda_loss_qubo,
                "qubo_balance_weight": config.lambda_balance_base,
                "qubo_soc_dynamic_weight": config.lambda_soc_dynamic,
                "qubo_soc_boundary_weight": config.lambda_soc_boundary,
                "qubo_substation_weight": config.lambda_substation,
                "qubo_waste_weight": config.lambda_waste_qubo,
                "qubo_switch_weight": config.lambda_switch,
                "qubo_grid_weight": config.lambda_grid_qubo,
                "qubo_discharge_reward_weight": config.lambda_discharge_reward_qubo,
                "estimated_min_voltage_kV": estimated_min_voltage_kV,
                "voltage_violation": voltage_violation,
                "power_violation": power_violation,
                "feasible": feasible_step
            }

            for key in (
                "p_direct_received_kW", "ess_charge_sent_kW",
                "ess_discharge_received_kW", "source_balance_error_kW",
                "traction_balance_error_kW", "paper_surrogate_absorbed_kW",
            ):
                if key in transfer:
                    record[key] = transfer[key]

            for ess_idx in range(config.ess_count):
                ess_no = ess_idx + 1
                record[f"ess{ess_no}_state"] = int(
                    batch_z_values[local_step_idx, ess_idx]
                )
                record[f"ess{ess_no}_charge_kW"] = float(
                    ess_charge[ess_idx]
                )
                record[f"ess{ess_no}_discharge_kW"] = float(
                    ess_discharge[ess_idx]
                )
                record[f"ESS{ess_no}_charge_kW"] = float(
                    ess_charge[ess_idx]
                )
                record[f"ESS{ess_no}_discharge_kW"] = float(
                    ess_discharge[ess_idx]
                )
                soc_percent = float(
                    config.SOC_ess[ess_idx] * 100.0
                )
                record[f"soc_{ess_no}_percent"] = soc_percent
                record[f"ESS{ess_no}_soc_percent"] = soc_percent

            records.append(record)

            states_text = "".join(
                str(int(v)) for v in batch_z_values[local_step_idx]
            )
            soc_text = ", ".join(
                f"{soc * 100.0:.2f}%"
                for soc in config.SOC_ess
            )

            print(
                f"t={t:03d}, batch={batch_id}, "
                f"states={states_text}, "
                f"absorption={transfer['absorption_rate'] * 100:.2f}%, "
                f"SOC=[{soc_text}]"
            )

        batch_end_soc = config.SOC_ess.copy()
        batch_end_to_end_s = perf_counter() - batch_end_to_end_start

        batch_record = {
            "batch_id": batch_id,
            "start_step": batch_start,
            "end_step": batch_end - 1,
            "steps": len(batch_df),
            "qubo_variable_count": batch_qubo_variable_count,
            "qubo_value": batch_qubo_value,
            "cim_call_time_s": batch_cim_time_s,
            "solver_backend": batch_solver_backend,
            "solver_status": batch_solver_status,
            "solver_gap": batch_solver_gap,
            "solver_nodes": batch_solver_nodes,
            "cross_batch_switch_enabled": config.cross_batch_switch_enabled,
            "qubo_nonzero_count": batch_qubo_nonzero_count,
            "qubo_density_percent": batch_qubo_density_percent,
            "qubo_abs_coefficient_min": batch_qubo_abs_coefficient_min,
            "qubo_abs_coefficient_max": batch_qubo_abs_coefficient_max,
            "quantization_original_nonzero": float(
                phase_timings.get("quantization_original_nonzero", np.nan)
            ),
            "quantization_nonzero": float(
                phase_timings.get("quantization_nonzero", np.nan)
            ),
            "quantization_retention_percent": float(
                phase_timings.get("quantization_retention_percent", np.nan)
            ),
            "phase_qubo_build_s": float(
                phase_timings.get("qubo_build_s", np.nan)
            ),
            "phase_qubo_to_model_s": float(
                phase_timings.get("qubo_to_model_s", np.nan)
            ),
            "phase_quantization_s": float(
                phase_timings.get("quantization_s", np.nan)
            ),
            "phase_sdk_platform_wall_s": float(
                phase_timings.get("sdk_platform_wall_s", np.nan)
            ),
            "phase_solver_framework_overhead_s": float(
                phase_timings.get("solver_framework_overhead_s", np.nan)
            ),
            "phase_backend_solve_s": float(
                phase_timings.get("backend_solve_s", np.nan)
            ),
            "phase_result_parse_s": float(
                phase_timings.get("result_parse_s", np.nan)
            ),
            "phase_graph_build_s": batch_graph_build_s,
            "phase_decoder_s": batch_decoder_s,
            "phase_validation_s": batch_validation_s,
            "phase_batch_end_to_end_s": batch_end_to_end_s,
        }

        for ess_idx in range(config.ess_count):
            ess_no = ess_idx + 1
            batch_record[f"start_soc_{ess_no}_percent"] = (
                batch_start_soc[ess_idx] * 100.0
            )
            batch_record[f"end_soc_{ess_no}_percent"] = (
                batch_end_soc[ess_idx] * 100.0
            )

        batch_summary_records.append(batch_record)

        if config.cross_batch_switch_enabled:
            config.previous_ess_modes = batch_z_values[-1].copy()

        pd.DataFrame(records).to_csv(
            partial_time_series_file,
            index=False,
            encoding="utf-8-sig",
        )
        pd.DataFrame(batch_summary_records).to_csv(
            partial_batch_summary_file,
            index=False,
            encoding="utf-8-sig",
        )
        print(
            f"[检查点] 已保存到t={batch_end - 1:03d}，"
            f"完成{submission_count}/{expected_submission_count}批。"
        )

    result_df = pd.DataFrame(records)
    batch_summary_df = pd.DataFrame(batch_summary_records)
    backend_labels = sorted(
        set(batch_summary_df["solver_backend"].astype(str))
    )
    backend_label = " + ".join(backend_labels)
    cim_batch_count = int(
        batch_summary_df["solver_backend"]
        .astype(str)
        .str.upper()
        .eq("CIM")
        .sum()
    )
    local_fallback_batch_count = int(
        len(batch_summary_df) - cim_batch_count
    )

    total_regen_kWh = (
        result_df["brake_power_kW"].sum() * config.dt / 3600.0
    )
    absorbed_kWh = (
        result_df["absorbed_brake_power_kW"].sum() * config.dt / 3600.0
    )
    wasted_kWh = (
        result_df["wasted_brake_power_kW"].sum() * config.dt / 3600.0
    )
    grid_kWh = (
        result_df["grid_power_kW"].sum() * config.dt / 3600.0
    )
    loss_kWh = (
        result_df["loss_kW"].sum() * config.dt / 3600.0
    )

    absorption_rate_percent = (
        absorbed_kWh / total_regen_kWh * 100.0
        if total_regen_kWh > 1e-12 else 0.0
    )

    total_solver_time_s = float(result_df["solve_time_ms"].sum() / 1000.0)
    equivalent_avg_time_ms = total_solver_time_s / len(result_df) * 1000.0
    avg_batch_time_s = (
        total_cim_time_s / submission_count
        if submission_count > 0 else 0.0
    )

    graph_label = "Dynamic" if config.graph_mode == "dynamic" else "Static-t0"
    objective_label = "Max-Cut" if config.maxcut_enabled else "No-Max-Cut"
    decoder_label = (
        "Decoder-only control"
        if config.dispatch_qubo_priority_boost <= 0.0
        else "QUBO-guided decoder"
    )

    # 使用统一evaluation模块计算Summary
    summary_result = calculate_summary(
        result_df=result_df,
        total_runtime=total_solver_time_s,
        method_name=(
            f"{graph_label} {objective_label} + QUBO + {backend_label} "
            f"+ {decoder_label} ({config.ess_count}ESS)"
        ),
    )

    # 补充量子批次指标
    quantum_extra = pd.DataFrame({
        "指标": [
            "求解模式",
            "总时间步数",
            "每批时间步数",
            "储能数量",
            "求解批次数",
            "完整批次QUBO变量数",
            "最大批次QUBO变量数",
            "平均每批求解时间",
            "平台CIM批次数",
            "本地后备批次数",
            "线路损耗权重",
            "图模型",
            "Max-Cut目标",
            "解码器QUBO偏好权重",
        ],
        "数值": [
            f"{config.ess_count}ESS, {BATCH_SIZE} s QUBO batch, "
            f"backend={backend_label}",
            len(result_df),
            BATCH_SIZE,
            config.ess_count,
            submission_count,
            BATCH_SIZE * config.ess_count,
            int(batch_summary_df["qubo_variable_count"].max()),
            avg_batch_time_s,
            cim_batch_count,
            local_fallback_batch_count,
            config.dispatch_loss_weight,
            config.graph_mode,
            "enabled" if config.maxcut_enabled else "disabled",
            config.dispatch_qubo_priority_boost,
        ],
        "单位": [
            "-", "步", "步/批", "个", "次", "个", "个", "s/批",
            "次", "次", "-", "-", "-", "-"
        ],
    })

    summary_result = pd.concat(
        [summary_result, quantum_extra],
        ignore_index=True,
    )

    result_df.to_csv(
        time_series_file,
        index=False,
        encoding="utf-8-sig"
    )
    batch_summary_df.to_csv(
        batch_summary_file,
        index=False,
        encoding="utf-8-sig"
    )
    summary_result.to_csv(
        summary_file,
        index=False,
        encoding="utf-8-sig"
    )
    partial_time_series_file.unlink(missing_ok=True)
    partial_batch_summary_file.unlink(missing_ok=True)

    with open(report_file, "w", encoding="utf-8") as f:
        f.write(
            f"{graph_label} {objective_label} + QUBO + {backend_label} "
            f"+ {decoder_label}\n"
        )
        f.write(
            f"{config.ess_count}ESS，每{BATCH_SIZE} s构建一个QUBO（全约束QUBO版）\n"
        )
        f.write("=" * 60 + "\n\n")

        for _, row in summary_result.iterrows():
            f.write(
                f"{row['指标']}: {row['数值']} {row['单位']}\n"
            )

    print(
        f"\n========== {config.ess_count}ESS、{BATCH_SIZE} s分批QUBO求解完成 =========="
    )
    print(summary_result)
    print("\n逐时结果：", time_series_file)
    print("批次结果：", batch_summary_file)
    print("汇总结果：", summary_file)
    print("文字报告：", report_file)
