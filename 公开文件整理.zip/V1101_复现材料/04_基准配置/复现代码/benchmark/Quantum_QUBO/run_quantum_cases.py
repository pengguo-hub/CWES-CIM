"""Explicit runner for the four Quantum_QUBO benchmark cases."""

import argparse
import os
from pathlib import Path
import subprocess
import sys

import certifi


ROOT = Path(__file__).resolve().parent
BENCHMARK_ROOT = ROOT.parent
CONFIG_DIR = BENCHMARK_ROOT / "config"
DATA_DIR = BENCHMARK_ROOT / "data"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import CASE_FILES, TIME_STEPS


QUANTUM_SCRIPT = ROOT / "quantum_10ess.py"
BATCH_SIZE = 10
EXPECTED_SUBMISSIONS = (TIME_STEPS + BATCH_SIZE - 1) // BATCH_SIZE


def case_path(case_key):
    """Return the configured workbook path for one benchmark case."""
    try:
        filename = CASE_FILES[case_key]
    except KeyError as error:
        choices = ", ".join(CASE_FILES)
        raise ValueError(f"Unknown case {case_key!r}; choose from {choices}") from error
    path = DATA_DIR / filename
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def list_cases():
    """Print the four configured cases without starting a solver."""
    for case_key in CASE_FILES:
        print(f"{case_key}: {case_path(case_key).name}")
    print(
        f"CIM is enabled; batch size={BATCH_SIZE}; "
        f"expected submissions per case={EXPECTED_SUBMISSIONS}."
    )


def run_case(case_key):
    """Run one explicitly selected case through the quantum entry point."""
    input_file = case_path(case_key)
    environment = os.environ.copy()
    environment.update(
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND="cim",
        ESS_QUBO_BATCH_SIZE=str(BATCH_SIZE),
        SSL_CERT_FILE=certifi.where(),
    )
    command = [sys.executable, str(QUANTUM_SCRIPT), str(input_file)]
    print(
        f"Running {case_key}: {TIME_STEPS} steps, "
        f"{EXPECTED_SUBMISSIONS} expected CIM submissions."
    )
    subprocess.run(command, cwd=ROOT, env=environment, check=True)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("list", help="list cases without running the solver")
    case_parser = subparsers.add_parser("case", help="run one selected case")
    case_parser.add_argument("case_key", choices=tuple(CASE_FILES))
    subparsers.add_parser("all", help="run all four cases in configured order")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.command in (None, "list"):
        list_cases()
        return
    if args.command == "case":
        run_case(args.case_key)
        return
    for case_key in CASE_FILES:
        run_case(case_key)


if __name__ == "__main__":
    main()
