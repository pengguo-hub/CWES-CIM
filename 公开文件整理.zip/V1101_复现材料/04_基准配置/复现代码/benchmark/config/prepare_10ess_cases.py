"""Generate the four 5B+5T+10ESS cases from the legacy variable-size cases."""

from pathlib import Path
import pandas as pd

from data_loader import convert_legacy_case_dataframe


ROOT = Path(__file__).resolve().parent.parent


def _legacy_power_total(frame, kind):
    columns = [
        f"{kind}_train_{i}_kW" for i in range(1, 6)
        if f"{kind}_train_{i}_kW" in frame
    ]
    if not columns:
        raise ValueError(f"No {kind} train columns")
    return frame[columns].sum(axis=1).to_numpy()


def prepare_cases():
    source_files = sorted(ROOT.glob("Case[1-4]_150s_hard_dynamic_condition_3B3T1ESS.csv"))
    if len(source_files) != 4:
        raise RuntimeError(f"Expected four legacy cases, found {len(source_files)}")
    outputs = []
    for source in source_files:
        legacy = pd.read_csv(source).dropna(how="all").reset_index(drop=True)
        converted = convert_legacy_case_dataframe(legacy)
        output = ROOT / source.name.replace("3B3T1ESS", "5B5T10ESS")
        converted.to_csv(output, index=False, encoding="utf-8-sig", float_format="%.6f")
        if abs(converted["brake_total_kW"].to_numpy() - _legacy_power_total(legacy, "brake")).max() > 1e-5:
            raise RuntimeError(f"Brake power changed during conversion: {source.name}")
        if abs(converted["traction_total_kW"].to_numpy() - _legacy_power_total(legacy, "traction")).max() > 1e-5:
            raise RuntimeError(f"Traction power changed during conversion: {source.name}")
        outputs.append(output)
    return outputs

if __name__ == "__main__":
    for path in prepare_cases():
        print(path)
