"""Unified dynamic graph and edge weights for the 10ESS benchmark."""

from benchmark_config import (
    DC_VOLTAGE, ESS_CAPACITY_KWH, ESS_POSITIONS, ETA_CH, ETA_DIS,
    LINE_RESISTANCE, NUM_BRAKE, NUM_ESS, NUM_TRACTION, P_CH_MAX_KW,
    SOC_MAX, SOC_MIN,
)

GAMMA = 0.8


def node_impedance(node_i, node_j):
    return LINE_RESISTANCE * abs(node_i["pos"] - node_j["pos"])


def _distance_factor(node_i, node_j):
    return 1.0 / (1.0 + GAMMA * node_impedance(node_i, node_j))


def _line_loss(power_kw, node_i, node_j):
    current_a = power_kw * 1000.0 / DC_VOLTAGE
    return current_a * current_a * node_impedance(node_i, node_j) / 1000.0


def weight_bt(brake, traction):
    power = min(brake["power"], traction["power"])
    return max(0.0, power * _distance_factor(brake, traction) - _line_loss(power, brake, traction))


def weight_bs(brake, storage):
    if storage["soc"] >= SOC_MAX:
        return 0.0
    factor = (SOC_MAX - storage["soc"]) / (SOC_MAX - SOC_MIN)
    power = min(brake["power"], storage["power_rated"])
    return max(0.0, power * ETA_CH * factor * _distance_factor(brake, storage))


def weight_ts(storage, traction):
    if storage["soc"] <= SOC_MIN:
        return 0.0
    factor = (storage["soc"] - SOC_MIN) / (SOC_MAX - SOC_MIN)
    power = min(storage["power_rated"], traction["power"])
    return max(0.0, power * ETA_DIS * factor * _distance_factor(storage, traction))


def edge_weight(node_i, node_j):
    types = {node_i["type"], node_j["type"]}
    if types == {"brake", "traction"}:
        brake = node_i if node_i["type"] == "brake" else node_j
        traction = node_i if node_i["type"] == "traction" else node_j
        return weight_bt(brake, traction)
    if types == {"brake", "storage"}:
        brake = node_i if node_i["type"] == "brake" else node_j
        storage = node_i if node_i["type"] == "storage" else node_j
        return weight_bs(brake, storage)
    if types == {"storage", "traction"}:
        storage = node_i if node_i["type"] == "storage" else node_j
        traction = node_i if node_i["type"] == "traction" else node_j
        return weight_ts(storage, traction)
    return 0.0


def build_nodes(input_t):
    nodes = []
    for i in range(NUM_BRAKE):
        nodes.append({"id": f"B{i + 1}", "type": "brake", "power": input_t["brake_power"][i], "pos": input_t["brake_position"][i]})
    for i in range(NUM_TRACTION):
        nodes.append({"id": f"T{i + 1}", "type": "traction", "power": input_t["traction_power"][i], "pos": input_t["traction_position"][i]})
    for i in range(NUM_ESS):
        nodes.append({
            "id": f"ESS{i + 1}", "type": "storage", "power_rated": P_CH_MAX_KW,
            "capacity": ESS_CAPACITY_KWH, "soc": input_t["soc"][i], "pos": ESS_POSITIONS[i],
        })
    return nodes


def build_edges(nodes):
    edges = []
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            weight = edge_weight(nodes[i], nodes[j])
            if weight > 0:
                edges.append((i, j, weight))
    return edges


def cut_value(partition, edges):
    return sum(weight for i, j, weight in edges if partition[i] != partition[j])