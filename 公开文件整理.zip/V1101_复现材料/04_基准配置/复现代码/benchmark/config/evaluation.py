"""Unified result validation and metric calculation for all benchmark methods."""

import pandas as pd

from benchmark_config import DT, NUM_ESS, RESULT_COLUMNS, SOC_INIT


def calculate_loss(result_df):
    if "loss_kW" not in result_df:
        return 0.0
    return float(result_df["loss_kW"].sum() * DT / 3600.0)


def calculate_soc_statistics(result_df):
    columns = [f"ESS{i}_soc_percent" for i in range(1, NUM_ESS + 1)]
    missing = [column for column in columns if column not in result_df]
    if missing:
        raise ValueError(f"Missing per-ESS SOC columns: {missing}")
    values = result_df[columns]
    return {
        "final_average_soc": float(values.iloc[-1].mean()),
        "max_soc": float(values.max().max()),
        "min_soc": float(values.min().min()),
    }


def validate_result_frame(result_df):
    missing = [column for column in RESULT_COLUMNS if column not in result_df]
    for i in range(1, NUM_ESS + 1):
        for suffix in ("charge_kW", "discharge_kW", "soc_percent"):
            column = f"ESS{i}_{suffix}"
            if column not in result_df:
                missing.append(column)
    if missing:
        raise ValueError(f"Result fields missing: {missing}")
    if len(result_df) == 0:
        raise ValueError("Result is empty")
    if result_df["power_balance_error_kW"].abs().max() > 1e-5:
        raise ValueError("Power balance residual exceeds tolerance")
    for i in range(1, NUM_ESS + 1):
        simultaneous = (
            (result_df[f"ESS{i}_charge_kW"] > 1e-8)
            & (result_df[f"ESS{i}_discharge_kW"] > 1e-8)
        )
        if simultaneous.any():
            raise ValueError(f"ESS{i} charges and discharges simultaneously")
    return True


def calculate_summary(result_df, total_runtime, method_name):
    validate_result_frame(result_df)
    total_regen = result_df["brake_power_kW"].sum() * DT / 3600.0
    direct_energy = result_df["p_direct_kW"].sum() * DT / 3600.0
    charge_energy = result_df["ess_charge_kW"].sum() * DT / 3600.0
    loss_energy = calculate_loss(result_df)
    if "p_direct_received_kW" in result_df:
        used_energy = float(
            result_df["absorbed_brake_power_kW"].sum() * DT / 3600.0
        )
    else:
        used_energy = max(0.0, direct_energy + charge_energy - loss_energy)
    wasted_energy = result_df["wasted_power_kW"].sum() * DT / 3600.0
    grid_energy = result_df["grid_power_kW"].sum() * DT / 3600.0
    absorption_rate = used_energy / total_regen * 100.0 if total_regen > 0 else 0.0
    soc = calculate_soc_statistics(result_df)

    values = [
        method_name, total_regen, used_energy, absorption_rate, wasted_energy,
        grid_energy, loss_energy, SOC_INIT * 100.0, soc["final_average_soc"],
        soc["max_soc"], soc["min_soc"], total_runtime,
        result_df["solve_time_ms"].mean(), result_df["solve_time_ms"].max(),
        int(result_df["voltage_violation"].sum()),
        int(result_df["power_violation"].sum()),
        int((~result_df["feasible"].astype(bool)).sum()),
    ]
    units = [
        "-", "kWh", "kWh", "%", "kWh", "kWh", "kWh", "%", "%", "%", "%",
        "s", "ms", "ms", "次", "次", "步",
    ]
    metrics = [
        "方法名称", "总再生能量", "有效消纳能量", "再生消纳率", "弃能",
        "电网补能", "网损", "初始SOC", "最终平均SOC", "最大SOC", "最小SOC",
        "总求解时间", "平均单步时间", "最大单步时间", "电压越限次数",
        "功率越限次数", "不可行步数",
    ]
    return pd.DataFrame({"指标": metrics, "数值": values, "单位": units})
