"""Case loading, validation, and the unified per-step input interface."""

from pathlib import Path

import numpy as np
import pandas as pd

from benchmark_config import (
    ESS_CAPACITY_KWH, ESS_POSITIONS, NUM_BRAKE, NUM_ESS, NUM_TRACTION,
    P_CH_MAX_KW, P_DIS_MAX_KW, SIM_TIME, SOC_INIT, TIME_STEPS,
)


def load_case_data(file_path):
    path = Path(file_path)
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    elif path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
    else:
        raise ValueError(f"Unsupported case format: {path.suffix}")
    validate_case_data(df, path.name)
    return df


def _value(row, column):
    value = row.get(column, 0.0)
    return 0.0 if pd.isna(value) else float(value)


def get_brake_power_list(row):
    return [_value(row, f"brake_train_{i}_kW") for i in range(1, NUM_BRAKE + 1)]


def get_brake_position_list(row):
    return [_value(row, f"brake_train_{i}_pos_km") for i in range(1, NUM_BRAKE + 1)]


def get_traction_power_list(row):
    return [_value(row, f"traction_train_{i}_kW") for i in range(1, NUM_TRACTION + 1)]


def get_traction_position_list(row):
    return [_value(row, f"traction_train_{i}_pos_km") for i in range(1, NUM_TRACTION + 1)]


def get_total_brake_power(row):
    return sum(get_brake_power_list(row))


def get_total_traction_power(row):
    return sum(get_traction_power_list(row))


def build_input_t(row, soc_list):
    if len(soc_list) != NUM_ESS:
        raise ValueError(f"soc_list must contain {NUM_ESS} values")
    return {
        "time": int(_value(row, "time_s")),
        "brake_power": get_brake_power_list(row),
        "brake_position": get_brake_position_list(row),
        "traction_power": get_traction_power_list(row),
        "traction_position": get_traction_position_list(row),
        "soc": [float(value) for value in soc_list],
    }


def validate_case_data(df, source="<dataframe>"):
    required = ["time_s"]
    for prefix, count in (("brake", NUM_BRAKE), ("traction", NUM_TRACTION)):
        for i in range(1, count + 1):
            required.extend([f"{prefix}_train_{i}_kW", f"{prefix}_train_{i}_pos_km"])
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(f"{source} is not a 5B+5T case; missing: {missing}")
    if len(df) != TIME_STEPS:
        raise ValueError(f"{source} must contain {TIME_STEPS} rows, got {len(df)}")
    expected = np.arange(0, SIM_TIME, dtype=float)
    actual = pd.to_numeric(df["time_s"], errors="coerce").to_numpy(dtype=float)
    if not np.array_equal(actual, expected):
        raise ValueError(f"{source} time_s must be 0..{SIM_TIME - 1}")
    numeric = df[required].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().any().any():
        raise ValueError(f"{source} contains non-numeric or missing required values")
    power_columns = [c for c in required if c.endswith("_kW")]
    if (numeric[power_columns] < 0).any().any():
        raise ValueError(f"{source} contains negative train power")


def _resample_fleet(row, kind, target_count=5):
    indices = [
        i for i in range(1, target_count + 1)
        if f"{kind}_train_{i}_kW" in row.index
        and f"{kind}_train_{i}_pos_km" in row.index
    ]
    if not indices:
        raise ValueError(f"No {kind} trains found in legacy case")
    powers = np.array([_value(row, f"{kind}_train_{i}_kW") for i in indices])
    positions = np.array([_value(row, f"{kind}_train_{i}_pos_km") for i in indices])
    source_axis = np.linspace(0.0, 1.0, len(indices))
    target_axis = np.linspace(0.0, 1.0, target_count)
    new_power = np.interp(target_axis, source_axis, powers)
    if new_power.sum() > 0:        new_power *= powers.sum() / new_power.sum()
    return new_power, np.interp(target_axis, source_axis, positions)


def convert_legacy_case_dataframe(df):
    """Convert a variable-size legacy case to a power-preserving 5B+5T+10ESS case."""
    converted = pd.DataFrame({
        "time_s": pd.to_numeric(df["time_s"]).astype(int),
        "phase": df["phase"] if "phase" in df else "",    })
    for row_index, row in df.iterrows():
        for kind in ("brake", "traction"):
            powers, positions = _resample_fleet(row, kind)
            for i, (power, position) in enumerate(zip(powers, positions), start=1):
                converted.loc[row_index, f"{kind}_train_{i}_kW"] = power
                converted.loc[row_index, f"{kind}_train_{i}_pos_km"] = position
    for i, position in enumerate(ESS_POSITIONS, start=1):
        converted[f"ess_{i}_pos_km"] = position
        converted[f"ess_{i}_capacity_kWh"] = ESS_CAPACITY_KWH
        converted[f"ess_{i}_max_charge_kW"] = P_CH_MAX_KW
        converted[f"ess_{i}_max_discharge_kW"] = P_DIS_MAX_KW
        converted[f"ess_{i}_initial_soc_percent"] = SOC_INIT * 100.0
    converted["brake_total_kW"] = sum(converted[f"brake_train_{i}_kW"] for i in range(1, NUM_BRAKE + 1))
    converted["traction_total_kW"] = sum(converted[f"traction_train_{i}_kW"] for i in range(1, NUM_TRACTION + 1))
    converted["power_surplus_kW"] = converted["brake_total_kW"] - converted["traction_total_kW"]
    validate_case_data(converted, "converted case")
    return converted