"""
统一线路损耗计算模块。

只负责根据传输功率和传输距离计算线路功率损耗。
不参与功率分配、ESS充放电、SOC更新、优化决策或结果评价。
"""

from benchmark_config import DC_VOLTAGE, LINE_RESISTANCE


def calculate_line_loss(power_kW, distance_km):
    """
    按 P²R/U² 计算单条传输路径的线路损耗。

    Parameters
    ----------
    power_kW : float
        发送端传输功率，单位 kW。

    distance_km : float
        传输距离，单位 km。

    Returns
    -------
    float
        线路损耗功率，单位 kW。
    """

    power_kW = float(power_kW)
    distance_km = float(distance_km)

    if power_kW <= 0.0:
        return 0.0

    if distance_km <= 0.0:
        return 0.0

    voltage_V = float(DC_VOLTAGE)
    resistance_per_km = float(LINE_RESISTANCE)

    if voltage_V <= 0.0:
        raise ValueError("DC_VOLTAGE 必须大于 0。")

    if resistance_per_km < 0.0:
        raise ValueError("LINE_RESISTANCE 不能小于 0。")

    resistance_ohm = resistance_per_km * distance_km
    current_A = power_kW * 1000.0 / voltage_V
    loss_kW = current_A**2 * resistance_ohm / 1000.0

    return max(0.0, loss_kW)