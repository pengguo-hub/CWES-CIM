"""Opt-in sending/receiving-terminal accounting for benchmark reproduction.

Flow ``power_kW`` is measured at the sending terminal. A sink is reduced by
``power_kW - loss_kW``. ESS charging is measured at the receiving converter
terminal; ESS discharging is measured at the sending converter terminal.
The legacy evaluator remains the default in runtime.py.
"""

from copy import deepcopy

from benchmark_config import (
    DC_VOLTAGE, DC_VOLTAGE_MIN, DT, ESS_POSITIONS, LINE_RESISTANCE,
    NUM_ESS, P_SUB_MAX_KW,
)
from line_loss import calculate_line_loss
from runtime import (
    allocate_power, calculate_flow_metrics, charge_limits, discharge_limits,
    update_soc,
)


def _voltage_safe_sent_limit(distance_km):
    resistance = LINE_RESISTANCE * distance_km
    if resistance <= 1e-12:
        return float("inf")
    return (DC_VOLTAGE - DC_VOLTAGE_MIN) * DC_VOLTAGE / (1000.0 * resistance)


def _sent_for_receiver(receive_kw, distance_km, maximum_sent_kw):
    """Find sending power that meets, without exceeding, receiver demand."""
    maximum_sent_kw = max(0.0, maximum_sent_kw)
    if receive_kw <= 0.0 or maximum_sent_kw <= 0.0:
        return 0.0
    if distance_km <= 0.0:
        return min(receive_kw, maximum_sent_kw)
    available_at_receiver = maximum_sent_kw - calculate_line_loss(
        maximum_sent_kw, distance_km
    )
    if available_at_receiver <= receive_kw:
        return maximum_sent_kw
    low, high = 0.0, maximum_sent_kw
    for _ in range(55):
        mid = (low + high) / 2.0
        if mid - calculate_line_loss(mid, distance_km) < receive_kw:
            low = mid
        else:
            high = mid
    return high


def _allocate(sources, sinks, flow_type):
    sources, sinks = deepcopy(sources), deepcopy(sinks)
    flows = []
    pairs = sorted(
        (abs(source["pos"] - sink["pos"]), i, j)
        for i, source in enumerate(sources)
        for j, sink in enumerate(sinks)
    )
    for distance, i, j in pairs:
        maximum_sent = min(
            sources[i]["remaining"], _voltage_safe_sent_limit(distance)
        )
        sent = _sent_for_receiver(sinks[j]["remaining"], distance, maximum_sent)
        if sent <= 1e-9:
            continue
        loss = calculate_line_loss(sent, distance)
        received = sent - loss
        flows.append({
            "from": sources[i]["id"], "to": sinks[j]["id"],
            "from_pos": sources[i]["pos"], "to_pos": sinks[j]["pos"],
            "power_kW": sent, "received_power_kW": received,
            "loss_kW": loss, "type": flow_type,
        })
        sources[i]["remaining"] = max(0.0, sources[i]["remaining"] - sent)
        sinks[j]["remaining"] = max(0.0, sinks[j]["remaining"] - received)
    return flows, sources, sinks


def _flows(input_t, charge_request, discharge_request):
    brake = [
        {"id": f"B{i + 1}", "pos": input_t["brake_position"][i],
         "remaining": input_t["brake_power"][i]}
        for i in range(len(input_t["brake_power"]))
    ]
    traction = [
        {"id": f"T{i + 1}", "pos": input_t["traction_position"][i],
         "remaining": input_t["traction_power"][i]}
        for i in range(len(input_t["traction_power"]))
    ]
    direct, remaining_brake, remaining_traction = _allocate(
        brake, traction, "brake_to_traction"
    )
    charge_sinks = [
        {"id": f"ESS{i + 1}", "pos": ESS_POSITIONS[i],
         "remaining": charge_request[i]}
        for i in range(NUM_ESS)
    ]
    charge_flows, _, _ = _allocate(
        remaining_brake, charge_sinks, "brake_to_storage"
    )
    discharge_sources = [
        {"id": f"ESS{i + 1}", "pos": ESS_POSITIONS[i],
         "remaining": discharge_request[i]}
        for i in range(NUM_ESS)
    ]
    discharge_flows, _, _ = _allocate(
        discharge_sources, remaining_traction, "storage_to_traction"
    )
    actual_charge = [0.0] * NUM_ESS
    actual_discharge = [0.0] * NUM_ESS
    for flow in charge_flows:
        actual_charge[int(flow["to"][3:]) - 1] += flow["received_power_kW"]
    for flow in discharge_flows:
        actual_discharge[int(flow["from"][3:]) - 1] += flow["power_kW"]
    return direct + charge_flows + discharge_flows, actual_charge, actual_discharge


def finalize_step_terminal(input_t, charge_kw, discharge_kw, solve_time_ms,
                           extras=None):
    if len(charge_kw) != NUM_ESS or len(discharge_kw) != NUM_ESS:
        raise ValueError(f"dispatch must contain {NUM_ESS} charge and discharge values")

    ch_limits = charge_limits(input_t["soc"])
    dis_limits = discharge_limits(input_t["soc"])
    requested_violation = any(
        charge_kw[i] < -1e-9 or discharge_kw[i] < -1e-9
        or charge_kw[i] > ch_limits[i] + 1e-6
        or discharge_kw[i] > dis_limits[i] + 1e-6
        or (charge_kw[i] > 1e-9 and discharge_kw[i] > 1e-9)
        for i in range(NUM_ESS)
    )
    charge_kw = [min(max(0.0, charge_kw[i]), ch_limits[i]) for i in range(NUM_ESS)]
    discharge_kw = [min(max(0.0, discharge_kw[i]), dis_limits[i]) for i in range(NUM_ESS)]

    brake = sum(input_t["brake_power"])
    traction = sum(input_t["traction_power"])
    charge_kw = allocate_power(min(sum(charge_kw), max(0.0, brake - traction)), charge_kw)
    discharge_kw = allocate_power(
        min(sum(discharge_kw), max(0.0, traction - brake)), discharge_kw
    )
    flows, charge_kw, discharge_kw = _flows(input_t, charge_kw, discharge_kw)
    total_loss, min_voltage = calculate_flow_metrics(flows)

    def sent(kind):
        return sum(f["power_kW"] for f in flows if f["type"] == kind)

    def received(kind):
        return sum(f["received_power_kW"] for f in flows if f["type"] == kind)

    def loss(kind):
        return sum(f["loss_kW"] for f in flows if f["type"] == kind)

    direct_sent = sent("brake_to_traction")
    direct_received = received("brake_to_traction")
    charge_sent = sent("brake_to_storage")
    charge_received = sum(charge_kw)
    discharge_sent = sum(discharge_kw)
    discharge_received = received("storage_to_traction")
    wasted = max(0.0, brake - direct_sent - charge_sent)
    grid = max(0.0, traction - direct_received - discharge_received)
    next_soc = update_soc(input_t["soc"], charge_kw, discharge_kw)
    source_error = brake - direct_sent - charge_sent - wasted
    traction_error = direct_received + discharge_received + grid - traction
    balance_error = (
        brake + discharge_sent + grid - traction - charge_received
        - total_loss - wasted
    )
    voltage_violation = min_voltage < DC_VOLTAGE_MIN - 1e-6
    power_violation = requested_violation or grid > P_SUB_MAX_KW + 1e-9
    feasible = (
        not voltage_violation and not power_violation
        and max(abs(source_error), abs(traction_error), abs(balance_error)) <= 1e-6
    )
    # Energy originating from braking and delivered to a traction or ESS terminal.
    physically_used_regen = direct_received + charge_received
    result = {
        "time_s": input_t["time"],
        "brake_power_kW": brake,
        "traction_power_kW": traction,
        "power_surplus_kW": brake - traction,
        "p_direct_kW": direct_sent,
        "p_direct_received_kW": direct_received,
        "ess_charge_kW": charge_received,
        "ess_charge_sent_kW": charge_sent,
        "ess_discharge_kW": discharge_sent,
        "ess_discharge_received_kW": discharge_received,
        "grid_power_kW": grid,
        "wasted_power_kW": wasted,
        "loss_kW": total_loss,
        "direct_line_loss_kW": loss("brake_to_traction"),
        "ess_charge_line_loss_kW": loss("brake_to_storage"),
        "ess_discharge_line_loss_kW": loss("storage_to_traction"),
        "absorbed_brake_power_kW": physically_used_regen,
        "absorption_rate_percent": physically_used_regen / brake * 100.0 if brake > 0 else 0.0,
        "paper_surrogate_absorbed_kW": max(
            0.0, direct_sent + charge_received - total_loss
        ),
        "soc_average": sum(next_soc) / NUM_ESS,
        "solve_time_ms": float(solve_time_ms),
        "min_voltage_V": min_voltage,
        "voltage_violation": voltage_violation,
        "power_violation": power_violation,
        "feasible": feasible,
        "power_balance_error_kW": balance_error,
        "source_balance_error_kW": source_error,
        "traction_balance_error_kW": traction_error,
        "terminal_accounting": True,
    }
    for i in range(NUM_ESS):
        result[f"ESS{i + 1}_charge_kW"] = charge_kw[i]
        result[f"ESS{i + 1}_discharge_kW"] = discharge_kw[i]
        result[f"ESS{i + 1}_soc_percent"] = next_soc[i] * 100.0
    if extras:
        result.update(extras)
    return result, next_soc, flows
