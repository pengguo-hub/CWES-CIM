"""Deterministic completion checks for all 150s 3B3T10ESS classic-method outputs."""

import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parent
CONFIG_DIR = ROOT / "config"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import CASE_FILES, ESS_POSITIONS, NUM_ESS, RESULT_ROOT, SIM_TIME

CASE_NAMES = list(CASE_FILES.keys())

METHODS = [
    "Gao2015",
    "Ground_SC",
    "k_flip",
    "MILP",
    "Genetic_Algorithm",
]


def verify():

    errors = []
    checked = 0

    # =========================
    # Result directory check
    # =========================

    for case_name in CASE_NAMES:
        for method in METHODS:
            output = ROOT / RESULT_ROOT / case_name / method

            time_series = output / "excel_result" / "TimeSeries_Result.xlsx"
            summary_xlsx = output / "excel_result" / "Summary_Result.xlsx"
            summary_csv = output / "excel_result" / "Summary_Result.csv"
            report = output / "txt" / "Result_Report.txt"
            figures = list((output / "figure").glob("*.png"))

            # File existence check
            for required in (time_series, summary_xlsx, summary_csv, report):
                if not required.exists() or required.stat().st_size == 0:
                    errors.append(f"{method}/{case_name}: missing {required.name}")

            if len(figures) < 5:
                errors.append(
                    f"{method}/{case_name}: expected >=5 figures, found {len(figures)}"
                )

            if not time_series.exists():
                continue

            # =========================
            # Read time series result
            # =========================

            result = pd.read_excel(time_series)
            checked += 1

            if len(result) != SIM_TIME:
                errors.append(
                    f"{method}/{case_name}: wrong time steps {len(result)}, expected {SIM_TIME}"
                )

            required_columns = [
                "time_s",
                "brake_power_kW",
                "traction_power_kW",
                "p_direct_kW",
                "ess_charge_kW",
                "ess_discharge_kW",
                "grid_power_kW",
                "wasted_power_kW",
                "loss_kW",
                "solve_time_ms",
                "feasible",
                "power_balance_error_kW",
            ]

            missing = [col for col in required_columns if col not in result]
            if missing:
                errors.append(f"{method}/{case_name}: missing columns {missing}")
                continue

            # Null value check
            if result[required_columns].isna().any().any():
                errors.append(f"{method}/{case_name}: NaN exists")

            # Power balance
            if result["power_balance_error_kW"].abs().max() > 1e-5:
                errors.append(f"{method}/{case_name}: power balance error")

            # =========================
            # 10 ESS constraint check
            # =========================

            for i in range(1, NUM_ESS + 1):
                ch = result[f"ESS{i}_charge_kW"]
                dis = result[f"ESS{i}_discharge_kW"]
                soc = result[f"ESS{i}_soc_percent"]

                # Charge power limit
                if ch.min() < -1e-8 or ch.max() > 500 + 1e-6:
                    errors.append(f"{method}/{case_name}: ESS{i} charge bound")

                # Discharge power limit
                if dis.min() < -1e-8 or dis.max() > 500 + 1e-6:
                    errors.append(f"{method}/{case_name}: ESS{i} discharge bound")

                # No simultaneous charge/discharge
                if ((ch > 1e-8) & (dis > 1e-8)).any():
                    errors.append(f"{method}/{case_name}: ESS{i} simultaneous charge/discharge")

                # SOC range
                if soc.min() < 20 - 1e-6 or soc.max() > 90 + 1e-6:
                    errors.append(f"{method}/{case_name}: ESS{i} SOC bound")

            # Feasibility
            if not result["feasible"].astype(bool).all():
                errors.append(f"{method}/{case_name}: infeasible step")

            # =========================
            # Summary check
            # =========================

            if summary_xlsx.exists():
                summary = pd.read_excel(summary_xlsx)
                if list(summary.columns) != ["指标", "数值", "单位"]:
                    errors.append(f"{method}/{case_name}: invalid summary schema")

    # =========================
    # Unified comparison check
    # =========================

    comparison = ROOT / "Unified_Comparison" / "Summary_All.csv"
    if not comparison.exists() or len(pd.read_csv(comparison)) != len(CASE_NAMES) * len(METHODS):
        errors.append("unified comparison does not contain all result sets")

    # =========================
    # Output
    # =========================

    if errors:
        raise AssertionError("\n".join(errors))

    print(
        f"PASS: {len(CASE_NAMES)} cases, "
        f"{checked} method-case outputs, "
        "all constraints and files verified"
    )


if __name__ == "__main__":
    verify()
