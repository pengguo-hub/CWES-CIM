"""Refresh opt-in summaries and charts from saved terminal-accounting time series.

This never reads from or writes to the legacy reference_results directory.
Running it after interrupted CIM work is safe; completed result sets are
refreshed in place and incomplete sets are skipped.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parent
BENCHMARK = ROOT / "benchmark"
sys.path.insert(0, str(BENCHMARK / "config"))
from evaluation import calculate_summary  # noqa: E402
from reporting import plot_standard_results, style_workbook  # noqa: E402

RESULTS = ROOT / "outputs" / "terminal_recalculation_20261025"


def value_of(summary: pd.DataFrame, metric: str):
    matches = summary.loc[summary["指标"] == metric, "数值"]
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one {metric!r} row")
    return matches.iloc[0]


def refresh_report(path: Path, summary: pd.DataFrame) -> None:
    if not path.is_file():
        return
    lines = path.read_text(encoding="utf-8").splitlines()
    replacement = {
        str(row["指标"]): f'{row["指标"]}: {row["数值"]} {row["单位"]}'
        for _, row in summary.iterrows()
    }
    updated = []
    for line in lines:
        label = line.split(": ", 1)[0]
        updated.append(replacement.get(label, line))
    path.write_text("\n".join(updated) + "\n", encoding="utf-8")


def refresh_classical() -> int:
    count = 0
    for time_path in sorted((RESULTS / "benchmark").glob(
        "Case*/*/excel_result/TimeSeries_Result.xlsx"
    )):
        excel_dir = time_path.parent
        method_dir = excel_dir.parent
        summary_path = excel_dir / "Summary_Result.csv"
        if not summary_path.exists():
            continue
        old = pd.read_csv(summary_path)
        frame = pd.read_excel(time_path)
        if "p_direct_received_kW" not in frame:
            raise ValueError(f"Missing terminal fields in {time_path}")
        summary = calculate_summary(
            frame, float(value_of(old, "总求解时间")),
            str(value_of(old, "方法名称")),
        )
        summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
        xlsx_path = excel_dir / "Summary_Result.xlsx"
        summary.to_excel(xlsx_path, index=False)
        style_workbook(xlsx_path)
        refresh_report(method_dir / "txt" / "Result_Report.txt", summary)
        figure_dir = method_dir / "figure"
        soc_files = list(figure_dir.glob("*_SOC.png"))
        if len(soc_files) == 1:
            prefix = soc_files[0].name.removesuffix("_SOC.png")
            plot_standard_results(frame, figure_dir, prefix=prefix)
        count += 1
    return count


def refresh_quantum() -> int:
    paths = list((RESULTS / "benchmark").glob(
        "Case*/Quantum_QUBO/TimeSeries_Result*.csv"
    )) + list((RESULTS / "core_attribution").glob(
        "CORE_*/Quantum_QUBO/TimeSeries_Result*.csv"
    ))
    count = 0
    for time_path in sorted(paths):
        frame = pd.read_csv(time_path)
        if len(frame) not in (30, 150):
            continue
        if "p_direct_received_kW" not in frame:
            raise ValueError(f"Missing terminal fields in {time_path}")
        summary_path = next(time_path.parent.glob("Summary_Result*.csv"), None)
        if summary_path is None:
            continue
        old = pd.read_csv(summary_path)
        base = calculate_summary(
            frame, float(value_of(old, "总求解时间")),
            str(value_of(old, "方法名称")),
        )
        for _, row in base.iterrows():
            mask = old["指标"] == row["指标"]
            if mask.any():
                old.loc[mask, "数值"] = row["数值"]
            else:
                old = pd.concat([old, pd.DataFrame([row])], ignore_index=True)
        old.to_csv(summary_path, index=False, encoding="utf-8-sig")
        refresh_report(
            time_path.parent / summary_path.name.replace("Summary_Result", "Result_Report").replace(".csv", ".txt"),
            old,
        )
        count += 1
    return count


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scope", choices=("classical", "quantum", "all"))
    options = parser.parse_args()
    if options.scope in ("classical", "all"):
        print("classical refreshed", refresh_classical())
    if options.scope in ("quantum", "all"):
        print("quantum refreshed", refresh_quantum())


if __name__ == "__main__":
    main()
