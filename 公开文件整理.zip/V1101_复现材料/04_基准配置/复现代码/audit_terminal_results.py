"""Independently audit reproduced terminal flows and per-device SOC."""

from __future__ import annotations

import csv
from pathlib import Path

import openpyxl


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "outputs" / "terminal_recalculation_20261025"
ETA_CH = ETA_DIS = 0.95
CAPACITY_KWH = 1000.0
DT = 1.0


def inspect(path: Path, kind: str) -> dict[str, object]:
    if kind == "csv":
        with path.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
    else:
        workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
        values = workbook.active.values
        headers = next(values)
        rows = [dict(zip(headers, values_row)) for values_row in values]
        workbook.close()
    largest = {key: 0.0 for key in (
        "brake_source_kW", "traction_receiver_kW", "line_loss_kW",
        "physical_absorption_kW", "soc_percentage_points",
    )}
    simultaneous = 0
    previous_soc = [0.5] * 10
    for row in rows:
        number = lambda key: float(row[key] or 0.0)
        brake = number("brake_power_kW")
        traction = number("traction_power_kW")
        direct_sent = number("p_direct_kW")
        direct_received = number("p_direct_received_kW")
        charge_sent = number("ess_charge_sent_kW")
        charge_received = number("ess_charge_kW")
        discharge_sent = number("ess_discharge_kW")
        discharge_received = number("ess_discharge_received_kW")
        grid = number("grid_power_kW")
        wasted = number("wasted_power_kW")
        loss = number("loss_kW" if "loss_kW" in row else "line_loss_kW")
        absorbed = number("absorbed_brake_power_kW")
        checks = {
            "brake_source_kW": brake - direct_sent - charge_sent - wasted,
            "traction_receiver_kW": direct_received + discharge_received + grid - traction,
            "line_loss_kW": (
                direct_sent - direct_received + charge_sent - charge_received
                + discharge_sent - discharge_received - loss
            ),
            "physical_absorption_kW": absorbed - direct_received - charge_received,
        }
        for name, value in checks.items():
            largest[name] = max(largest[name], abs(value))
        simultaneous += grid > 1e-9 and wasted > 1e-9
        for i in range(10):
            index = i + 1
            prefix = "ESS" if f"ESS{index}_charge_kW" in row else "ess"
            charge = number(f"{prefix}{index}_charge_kW")
            discharge = number(f"{prefix}{index}_discharge_kW")
            observed = number(f"{prefix}{index}_soc_percent") / 100.0
            expected = previous_soc[i] + (
                ETA_CH * charge - discharge / ETA_DIS
            ) * DT / (3600.0 * CAPACITY_KWH)
            error = (observed - expected) * 100.0
            largest["soc_percentage_points"] = max(
                largest["soc_percentage_points"], abs(error)
            )
            previous_soc[i] = observed
    return {
        "file": str(path.relative_to(ROOT)), "steps": len(rows),
        "simultaneous_grid_and_curtailment_steps": simultaneous,
        **{"max_" + key: value for key, value in largest.items()},
        "audit_pass": all(value < 1e-6 for value in largest.values()),
    }


def main() -> None:
    inspected = []
    for path in sorted((RESULTS / "benchmark").glob("Case*/Quantum_QUBO/TimeSeries_Result*.csv")):
        inspected.append(inspect(path, "csv"))
    for path in sorted((RESULTS / "benchmark").glob("Case*/*/excel_result/TimeSeries_Result.xlsx")):
        inspected.append(inspect(path, "xlsx"))
    for path in sorted((RESULTS / "core_attribution").glob("CORE_*/Quantum_QUBO/TimeSeries_Result*.csv")):
        inspected.append(inspect(path, "csv"))
    for path in sorted((RESULTS / "cim_decoder_contribution").glob("*_TimeSeries.csv")):
        inspected.append(inspect(path, "csv"))
    if not inspected:
        raise SystemExit("No terminal reproduction files found")
    output = RESULTS / "Terminal_Endpoint_SOC_Audit.csv"
    with output.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=inspected[0].keys())
        writer.writeheader()
        writer.writerows(inspected)
    for row in inspected:
        print(row["file"], "PASS" if row["audit_pass"] else "FAIL",
              "steps", row["steps"])
    print(output)
    if not all(row["audit_pass"] for row in inspected):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
