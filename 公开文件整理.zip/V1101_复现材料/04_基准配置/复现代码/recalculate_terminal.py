"""Recalculate selected benchmark results with terminal power accounting.

The original evaluator and archived outputs stay unchanged. This entry point
writes only to outputs/terminal_recalculation_20261025. No platform credentials
are stored or printed. CIM mode requires an explicit switch and process env.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
BENCHMARK = ROOT / "benchmark"
OUTPUT = ROOT / "outputs" / "terminal_recalculation_20261025"
COMPAT = BENCHMARK / "experiments" / "terminal_compat"
CASES = ("Case1", "Case2", "Case3", "Case4")
CASE_FILES = {
    "Case1": "Case1_150s_traction_dominant_10ESS.xlsx",
    "Case2": "Case2_150s_regeneration_dominant_10ESS.xlsx",
    "Case3": "Case3_150s_balanced_10ESS.xlsx",
    "Case4": "Case4_150s_dynamic_mixed_10ESS.xlsx",
}


def environment() -> dict[str, str]:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(
        BENCHMARK_TERMINAL_ACCOUNTING="1",
        BENCHMARK_RESULT_ROOT=str(OUTPUT / "benchmark"),
        CORE_ATTRIBUTION_RESULT_ROOT=str(OUTPUT / "core_attribution"),
        MPLBACKEND="Agg",
        MPLCONFIGDIR=str(OUTPUT / ".matplotlib"),
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONUTF8="1",
        ESS_QUBO_RESUME="1",
        ESS_QUBO_TASK_TAG="TERMINAL_20261025",
    )
    env["PYTHONPATH"] = str(COMPAT) + os.pathsep + env.get("PYTHONPATH", "")
    return env


def execute(args: list[str], env: dict[str, str], cwd: Path) -> None:
    print("RUN", " ".join(args), flush=True)
    subprocess.run(args, cwd=cwd, env=env, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "mode", choices=("classical", "cim", "cim-resume-scip", "core-local", "core-cim", "core-collect", "decoder-replay")
    )
    parser.add_argument("--case", choices=CASES)
    parser.add_argument("--submit-cim", action="store_true")
    options = parser.parse_args()
    env = environment()
    if options.mode in ("cim", "core-cim"):
        if not options.submit_cim:
            parser.error("CIM mode requires --submit-cim")
        for name in ("KAIWU_USER_ID", "KAIWU_SDK_CODE"):
            if not env.get(name, "").strip():
                parser.error(f"CIM mode requires {name} in the process environment")
    if options.mode == "cim-resume-scip":
        if not options.case:
            parser.error("cim-resume-scip requires --case")
        env.update(
            ESS_USE_QUANTUM_INTERFACE="1",
            ESS_QUANTUM_SOLVER_BACKEND="scip",
            ESS_ALLOW_LOCAL_QUBO_EXPERIMENT="1",
            ESS_QUBO_BATCH_SIZE="10",
            BENCHMARK_CASE_KEY=options.case,
        )
        script = BENCHMARK / "Quantum_QUBO" / "quantum_10ess.py"
        input_file = BENCHMARK / "data" / CASE_FILES[options.case]
        execute([sys.executable, "-B", str(script), str(input_file)], env, script.parent)
    elif options.mode in ("classical", "cim"):
        cases = (options.case,) if options.case else CASES
        for case in cases:
            if options.mode == "classical":
                command = [
                    sys.executable, "-B", str(BENCHMARK / "run_all_caseV1.py"),
                    "case", case,
                ]
                cwd = BENCHMARK
            else:
                command = [
                    sys.executable, "-B",
                    str(BENCHMARK / "Quantum_QUBO" / "run_quantum_cases.py"),
                    "case", case,
                ]
                cwd = BENCHMARK / "Quantum_QUBO"
            execute(command, env, cwd)
    elif options.mode == "core-collect":
        script = BENCHMARK / "experiments" / "run_core_attribution_ablation.py"
        execute([sys.executable, "-B", str(script), "collect"],
                env, BENCHMARK / "experiments")
    elif options.mode == "decoder-replay":
        env["CIM_DECODER_SOURCE_ROOT"] = str(OUTPUT / "core_attribution")
        env["CIM_DECODER_RESULT_ROOT"] = str(OUTPUT / "cim_decoder_contribution")
        script = BENCHMARK / "experiments" / "run_cim_decoder_contribution.py"
        execute([sys.executable, "-B", str(script)], env, BENCHMARK / "experiments")
    else:
        script = BENCHMARK / "experiments" / "run_core_attribution_ablation.py"
        if options.mode == "core-local":
            for arm in ("A", "B", "C", "E"):
                execute([sys.executable, "-B", str(script), "run-local", "--arm", arm],
                        env, BENCHMARK / "experiments")
        else:
            execute([sys.executable, "-B", str(script), "run-cim", "--arm", "D"],
                    env, BENCHMARK / "experiments")


if __name__ == "__main__":
    main()
