"""Build the six-method comparison only after all corrected runs pass audit."""

from __future__ import annotations

import csv
from pathlib import Path
import sys

import openpyxl


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "terminal_recalculation_20261025"
OLD = (ROOT / "reference_results" / "05_第五章" / "03_六算法统一Benchmark"
       / "02_算法逐时与汇总结果")
METHODS = ("Ground_SC", "Gao2015", "MILP", "Genetic_Algorithm", "k_flip", "Quantum_QUBO")


def read_summary(path: Path) -> dict[str, str]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {row["指标"]: row["数值"] for row in csv.DictReader(stream)}


def read_steps(case: str, method: str) -> list[dict[str, object]]:
    base = OUT / "benchmark" / case / method
    if method == "Quantum_QUBO":
        path = next(base.glob("TimeSeries_Result*.csv"))
        with path.open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))
    workbook = openpyxl.load_workbook(
        base / "excel_result" / "TimeSeries_Result.xlsx",
        read_only=True, data_only=True,
    )
    values = workbook.active.values
    headers = next(values)
    rows = [dict(zip(headers, row)) for row in values]
    workbook.close()
    return rows


def main() -> None:
    audit = OUT / "Terminal_Endpoint_SOC_Audit.csv"
    if not audit.is_file():
        raise SystemExit("Run audit_terminal_results.py first")
    with audit.open(encoding="utf-8-sig", newline="") as stream:
        audited = list(csv.DictReader(stream))
    if any(row["audit_pass"].lower() != "true" for row in audited):
        raise SystemExit("Audit contains failures")
    results = []
    for case in ("Case1", "Case2", "Case3", "Case4"):
        for method in METHODS:
            new_base = OUT / "benchmark" / case / method
            old_base = OLD / case / method
            new_summary_path = (
                next(new_base.glob("Summary_Result*.csv"))
                if method == "Quantum_QUBO"
                else new_base / "excel_result" / "Summary_Result.csv"
            )
            old_summary_path = (
                next(old_base.glob("Summary_Result*.csv"))
                if method == "Quantum_QUBO"
                else old_base / "excel_result" / "Summary_Result.csv"
            )
            new = read_summary(new_summary_path)
            old = read_summary(old_summary_path)
            steps = read_steps(case, method)
            if len(steps) != 150:
                raise ValueError(f"Incomplete {case}/{method}: {len(steps)} steps")
            number = lambda row, key: float(row[key] or 0.0)
            brake_energy = sum(number(r, "brake_power_kW") for r in steps) / 3600.0
            physical_energy = sum(number(r, "absorbed_brake_power_kW") for r in steps) / 3600.0
            paper_surrogate = max(0.0, sum(
                number(r, "p_direct_kW") + number(r, "ess_charge_kW")
                - number(r, "loss_kW") for r in steps
            ) / 3600.0)
            reported = float(new["有效消纳能量"])
            if abs(reported - physical_energy) > 1e-6:
                raise ValueError(f"Summary/steps disagree for {case}/{method}")
            if method == "Quantum_QUBO":
                batch_path = next(new_base.glob("Batch_Summary*.csv"))
                with batch_path.open(encoding="utf-8-sig", newline="") as stream:
                    batches = list(csv.DictReader(stream))
                if len(batches) != 15:
                    raise ValueError(f"Incomplete QUBO batches for {case}")
            else:
                batches = []
            results.append({
                "case": case, "method": method, "steps": len(steps),
                "new_cim_submissions": sum(
                    str(row.get("solver_backend", "")).upper() == "CIM"
                    for row in batches
                ),
                "local_scip_completion_batches": sum(
                    str(row.get("solver_backend", "")).upper() == "QUBO_SCIP"
                    for row in batches
                ),
                "old_absorption_percent": float(old["再生消纳率"]),
                "physical_absorption_percent": physical_energy / brake_energy * 100.0,
                "physical_absorbed_kWh": physical_energy,
                "paper_surrogate_absorbed_kWh": paper_surrogate,
                "wasted_kWh": float(new["弃能"]),
                "grid_kWh": float(new["电网补能"]),
                "line_loss_kWh": float(new["网损"]),
                "final_mean_soc_percent": float(new["最终平均SOC"]),
                "infeasible_steps": int(float(new["不可行步数"])),
            })
    output = OUT / "Six_Method_Terminal_Comparison.csv"
    with output.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=results[0])
        writer.writeheader()
        writer.writerows(results)
    print(output)
    print("rows", len(results), "CIM submissions", sum(r["new_cim_submissions"] for r in results))


if __name__ == "__main__":
    main()
