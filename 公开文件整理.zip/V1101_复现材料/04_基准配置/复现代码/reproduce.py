"""Single entry point for the paper's benchmark and engineering reproductions."""

from __future__ import annotations

import argparse
import ast
import csv
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from time import time


ROOT = Path(__file__).resolve().parent
BENCHMARK = ROOT / "benchmark"
ENGINEERING = ROOT / "engineering"
OUTPUTS = ROOT / "outputs"
BENCHMARK_OUTPUT = OUTPUTS / "benchmark"
BENCHMARK_SCIP_OUTPUT = OUTPUTS / "benchmark_scip_debug"
PENALTY_OUTPUT = OUTPUTS / "penalty_sensitivity_scip"
SCALE_OUTPUT = OUTPUTS / "scale_ablation"
ENGINEERING_OUTPUT = OUTPUTS / "engineering"

CORE_MODULES = (
    "numpy",
    "pandas",
    "matplotlib",
    "openpyxl",
    "networkx",
    "scipy",
    "pulp",
    "certifi",
)
QUANTUM_MODULES = ("kaiwu", "pyscipopt")
CASE_FILES = {
    "Case1": "Case1_150s_traction_dominant_10ESS.xlsx",
    "Case2": "Case2_150s_regeneration_dominant_10ESS.xlsx",
    "Case3": "Case3_150s_balanced_10ESS.xlsx",
    "Case4": "Case4_150s_dynamic_mixed_10ESS.xlsx",
}


def log_event(event: str, **fields: object) -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    record = {"time_unix": time(), "event": event, **fields}
    with (OUTPUTS / "reproduction_log.jsonl").open(
        "a", encoding="utf-8"
    ) as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + "\n")


def run(command: list[str], *, cwd: Path, env: dict[str, str]) -> None:
    printable = [str(item) for item in command]
    print("RUN:", " ".join(printable), flush=True)
    log_event("start", command=printable, cwd=str(cwd))
    try:
        subprocess.run(command, cwd=cwd, env=env, check=True)
    except Exception as error:
        log_event("failure", command=printable, error=repr(error))
        raise
    log_event("complete", command=printable)


def base_environment(result_root: Path) -> dict[str, str]:
    result_root.mkdir(parents=True, exist_ok=True)
    matplotlib_config = OUTPUTS / ".matplotlib"
    matplotlib_config.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(
        BENCHMARK_RESULT_ROOT=str(result_root.resolve()),
        MPLBACKEND="Agg",
        MPLCONFIGDIR=str(matplotlib_config.resolve()),
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONUTF8="1",
    )
    return env


def engineering_environment() -> dict[str, str]:
    env = base_environment(ENGINEERING_OUTPUT)
    env.update(
        BENCHMARK_NUM_BRAKE="3",
        BENCHMARK_NUM_TRACTION="3",
        BENCHMARK_NUM_ESS="10",
        BENCHMARK_DT="1.0",
        BENCHMARK_SIM_TIME="150",
        BENCHMARK_ESS_POSITIONS=(
            "3.448,6.039,9.039,11.999,14.083,19.7,"
            "20.521,22.58,25.385,27.055"
        ),
        BENCHMARK_CASE_KEY="BeijingLine5_EngineeringCase",
    )
    return env


def require_platform_confirmation(args: argparse.Namespace) -> None:
    if not args.confirm_platform:
        raise SystemExit(
            "CIM command not started. Add --confirm-platform to acknowledge "
            "that this submits paid/limited remote QBoson tasks."
        )
    missing = [
        name
        for name in ("KAIWU_USER_ID", "KAIWU_SDK_CODE")
        if not os.environ.get(name, "").strip()
    ]
    if missing:
        raise SystemExit("Missing process environment variables: " + ", ".join(missing))


def check_environment(profile: str) -> None:
    required_paths = [
        BENCHMARK / "config" / "benchmark_config.py",
        BENCHMARK / "Quantum_QUBO" / "quantum_10ess.py",
        BENCHMARK / "experiments" / "scale_cases" / "scale_manifest.csv",
        ENGINEERING
        / "reused_from_previous_algorithms"
        / "prepared_inputs"
        / "BeijingLine5_150s_3B3T10ESS.csv",
    ]
    missing_paths = [str(path) for path in required_paths if not path.is_file()]
    modules = CORE_MODULES + (QUANTUM_MODULES if profile == "quantum" else ())
    missing_modules = [
        module for module in modules if importlib.util.find_spec(module) is None
    ]
    syntax_errors: list[str] = []
    parsed_count = 0
    for path in ROOT.rglob("*.py"):
        if ".venv" in path.parts:
            continue
        parsed_count += 1
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        except SyntaxError as error:
            syntax_errors.append(f"{path}: {error}")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Profile: {profile}")
    print(f"Python files parsed: {parsed_count}")
    print("Required files:", "PASS" if not missing_paths else "FAIL")
    print("Dependencies:", "PASS" if not missing_modules else "MISSING")
    if missing_paths:
        print("Missing files:")
        print("\n".join(f"  - {item}" for item in missing_paths))
    if missing_modules:
        print("Missing modules:", ", ".join(missing_modules))
    if syntax_errors:
        print("Syntax errors:")
        print("\n".join(f"  - {item}" for item in syntax_errors))
    if missing_paths or missing_modules or syntax_errors:
        raise SystemExit(2)


def smoke() -> None:
    env = base_environment(OUTPUTS / "smoke")
    run(
        [sys.executable, "-B", str(BENCHMARK / "run_all_caseV1.py"), "list"],
        cwd=BENCHMARK,
        env=env,
    )
    run(
        [
            sys.executable,
            "-B",
            str(BENCHMARK / "Quantum_QUBO" / "run_quantum_cases.py"),
            "list",
        ],
        cwd=BENCHMARK / "Quantum_QUBO",
        env=env,
    )
    run(
        [
            sys.executable,
            "-B",
            str(BENCHMARK / "Quantum_QUBO" / "validate_setup.py"),
        ],
        cwd=BENCHMARK / "Quantum_QUBO",
        env=env,
    )


def run_classical(case: str | None) -> None:
    env = base_environment(BENCHMARK_OUTPUT)
    command = [sys.executable, "-B", str(BENCHMARK / "run_all_caseV1.py")]
    command += ["case", case] if case else ["all"]
    run(command, cwd=BENCHMARK, env=env)


def run_benchmark_cim(args: argparse.Namespace) -> None:
    require_platform_confirmation(args)
    env = base_environment(BENCHMARK_OUTPUT)
    runner = BENCHMARK / "Quantum_QUBO" / "run_quantum_cases.py"
    command = [sys.executable, "-B", str(runner)]
    command += ["case", args.case] if args.case else ["all"]
    run(command, cwd=runner.parent, env=env)


def run_benchmark_scip(case: str | None) -> None:
    env = base_environment(BENCHMARK_SCIP_OUTPUT)
    env.update(
        ESS_USE_QUANTUM_INTERFACE="1",
        ESS_QUANTUM_SOLVER_BACKEND="scip",
        ESS_ALLOW_LOCAL_QUBO_EXPERIMENT="1",
        ESS_QUBO_BATCH_SIZE="10",
    )
    script = BENCHMARK / "Quantum_QUBO" / "quantum_10ess.py"
    cases = [case] if case else list(CASE_FILES)
    for case_key in cases:
        case_env = env.copy()
        case_env["BENCHMARK_CASE_KEY"] = case_key
        run(
            [sys.executable, "-B", str(script), str(BENCHMARK / "data" / CASE_FILES[case_key])],
            cwd=script.parent,
            env=case_env,
        )


def run_penalty(force: bool) -> None:
    env = base_environment(PENALTY_OUTPUT)
    env["REPRO_PENALTY_RESULT_ROOT"] = str(PENALTY_OUTPUT.resolve())
    script = BENCHMARK / "experiments" / "run_penalty_sensitivity.py"
    command = [sys.executable, "-B", str(script), "run"]
    if force:
        command.append("--force")
    run(command, cwd=script.parent, env=env)


def run_scale(args: argparse.Namespace, backend: str) -> None:
    if backend == "cim":
        require_platform_confirmation(args)
    env = base_environment(SCALE_OUTPUT / backend)
    env.update(
        SCALE_QUANTUM_BACKEND=backend,
        REPRO_SCALE_RESULT_ROOT=str((SCALE_OUTPUT / backend).resolve()),
        REPRO_PENALTY_RECOMMENDATION=str(
            (PENALTY_OUTPUT / "Recommended_Hyperparameters.csv").resolve()
        ),
    )
    script = BENCHMARK / "experiments" / "run_scale_ablation.py"
    command = [sys.executable, "-B", str(script), args.scale_scope]
    if args.force:
        command.append("--force")
    run(command, cwd=script.parent, env=env)


def engineering_paths() -> tuple[Path, Path, Path]:
    reuse = ENGINEERING / "reused_from_previous_algorithms"
    snapshot = reuse / "legacy_benchmark_snapshot"
    tools = reuse / "tools"
    case_file = reuse / "prepared_inputs" / "BeijingLine5_150s_3B3T10ESS.csv"
    return snapshot, tools, case_file


def run_engineering_classical() -> None:
    snapshot, tools, case_file = engineering_paths()
    env = engineering_environment()
    scripts = (
        snapshot / "Ground_SC_Control" / "ground.sc.py",
        snapshot / "Gao2015_Voltage_SOC" / "gao2015.py",
        snapshot / "MILP" / "MILP.py",
        snapshot / "Genetic_Algorithm" / "genetic_algorithm.py",
        snapshot / "k_flip" / "k-flip.py",
    )
    for script in scripts:
        run([sys.executable, "-B", str(script), str(case_file)], cwd=script.parent, env=env)
    geng = tools / "run_geng_hierarchical_baseline.py"
    run([sys.executable, "-B", str(geng)], cwd=geng.parent, env=env)


def run_engineering_cim(args: argparse.Namespace) -> None:
    require_platform_confirmation(args)
    snapshot, tools, case_file = engineering_paths()
    env = engineering_environment()
    wrapper = tools / "run_engineering_quantum.py"
    script = snapshot / "Quantum_QUBO" / "quantum_10ess.py"
    run(
        [sys.executable, "-B", str(wrapper), str(script), str(case_file)],
        cwd=wrapper.parent,
        env=env,
    )


def analyze_engineering() -> None:
    _, tools, _ = engineering_paths()
    env = engineering_environment()
    script = tools / "analyze_engineering_results.py"
    run([sys.executable, "-B", str(script)], cwd=script.parent, env=env)


def inspect_batch_file(path: Path, expected: str, expected_rows: int) -> list[str]:
    errors: list[str] = []
    if not path.is_file():
        return [f"missing: {path}"]
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != expected_rows:
        errors.append(f"{path}: rows={len(rows)}, expected={expected_rows}")
    backends = {row.get("solver_backend", "") for row in rows}
    if backends != {expected}:
        errors.append(f"{path}: backends={sorted(backends)}, expected={[expected]}")
    return errors


def verify_outputs() -> None:
    errors: list[str] = []
    for case_key in CASE_FILES:
        errors += inspect_batch_file(
            BENCHMARK_OUTPUT
            / case_key
            / "Quantum_QUBO"
            / "Batch_Summary_10ESS_10sBatch.csv",
            "CIM",
            15,
        )
    errors += inspect_batch_file(
        ENGINEERING_OUTPUT
        / "BeijingLine5_EngineeringCase"
        / "Quantum_QUBO"
        / "Batch_Summary_10ESS_10sBatch.csv",
        "CIM",
        15,
    )
    if errors:
        print("Verification incomplete or failed:")
        print("\n".join(f"  - {item}" for item in errors))
        raise SystemExit(3)
    print("PASS: four benchmark cases and engineering case are complete CIM results.")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument(
        "command",
        choices=(
            "check",
            "smoke",
            "classical",
            "benchmark-cim",
            "benchmark-scip",
            "penalty-scip",
            "scale-cim",
            "scale-scip",
            "engineering-classical",
            "engineering-cim",
            "engineering-analyze",
            "verify",
        ),
    )
    result.add_argument("--profile", choices=("classical", "quantum"), default="classical")
    result.add_argument("--case", choices=tuple(CASE_FILES))
    result.add_argument("--force", action="store_true")
    result.add_argument("--confirm-platform", action="store_true")
    result.add_argument(
        "--scale-scope",
        choices=("classic", "quantum", "all", "collect"),
        default="quantum",
    )
    return result


def main() -> None:
    args = parser().parse_args()
    dispatch = {
        "check": lambda: check_environment(args.profile),
        "smoke": smoke,
        "classical": lambda: run_classical(args.case),
        "benchmark-cim": lambda: run_benchmark_cim(args),
        "benchmark-scip": lambda: run_benchmark_scip(args.case),
        "penalty-scip": lambda: run_penalty(args.force),
        "scale-cim": lambda: run_scale(args, "cim"),
        "scale-scip": lambda: run_scale(args, "scip"),
        "engineering-classical": run_engineering_classical,
        "engineering-cim": lambda: run_engineering_cim(args),
        "engineering-analyze": analyze_engineering,
        "verify": verify_outputs,
    }
    dispatch[args.command]()


if __name__ == "__main__":
    main()
