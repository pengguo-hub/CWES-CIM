"""Run the preserved Quantum_QUBO snapshot with external credentials.

The legacy source keeps the credential used by the archived experiment.  This
wrapper leaves that source byte-for-byte unchanged and redirects only the
license initialisation call to KAIWU_USER_ID/KAIWU_SDK_CODE supplied at run
time.  All solver/model code still executes from the preserved snapshot.
"""

import os
from pathlib import Path
import runpy
import sys

import kaiwu


def main():
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: run_engineering_quantum.py QUANTUM_SCRIPT CASE_FILE"
        )
    quantum_script = Path(sys.argv[1]).resolve()
    case_file = Path(sys.argv[2]).resolve()
    user_id = os.environ.get("KAIWU_USER_ID", "").strip()
    sdk_code = os.environ.get("KAIWU_SDK_CODE", "").strip()
    if not user_id or not sdk_code:
        raise RuntimeError("KAIWU_USER_ID and KAIWU_SDK_CODE are required")

    original_init = kaiwu.license.init

    def environment_license_init(*_args, **_kwargs):
        return original_init(user_id=user_id, sdk_code=sdk_code)

    kaiwu.license.init = environment_license_init
    sys.argv = [str(quantum_script), str(case_file)]
    runpy.run_path(str(quantum_script), run_name="__main__")


if __name__ == "__main__":
    main()
