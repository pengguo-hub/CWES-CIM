"""Run a Beijing Line 5 adaptation of Geng et al.'s hierarchical baseline.

The literature strategy installs energy-feedback devices along the full line,
ranks substations by returned energy, and then adds storage at the highest-
contribution sites.  This adaptation uses the supplied 16 substations, the
paper's 4 MW feedback-device rating, and the corrected 0.5 MW / 1000 kWh ESS
units.  It is a literature-normalized baseline, not the paper's unnamed line.
"""

import csv
import json
import os
from pathlib import Path
import sys
import time

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "legacy_benchmark_snapshot"
CONFIG_DIR = SNAPSHOT / "config"
PREPARED_DIR = ROOT / "prepared_inputs"
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))

from benchmark_config import (  # noqa: E402
    DC_VOLTAGE,
    DC_VOLTAGE_MIN,
    DT,
    ESS_POSITIONS,
    NUM_ESS,
    P_SUB_MAX_KW,
    SOC_INIT,
)
from data_loader import build_input_t, load_case_data  # noqa: E402
from runtime import (  # noqa: E402
    _greedy_allocate,
    calculate_flow_metrics,
    charge_limits,
    discharge_limits,
    update_soc,
)


CASE_FILE = PREPARED_DIR / "BeijingLine5_150s_3B3T10ESS.csv"
NETWORK_FILE = PREPARED_DIR / "BeijingLine5_station_network.csv"
CASE_CONFIG_FILE = PREPARED_DIR / "BeijingLine5_case_config.json"
CASE_KEY = os.environ.get("BENCHMARK_CASE_KEY", "BeijingLine5_EngineeringCase")
RESULT_ROOT = Path(os.environ.get("BENCHMARK_RESULT_ROOT", ROOT.parent / "results"))
OUTPUT_DIR = RESULT_ROOT / CASE_KEY / "Geng_Hierarchical_Baseline"
FEEDBACK_CAPACITY_KW = 4000.0
ESS_CANDIDATE_COUNT = 3


def load_substations():
    with NETWORK_FILE.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    substations = [
        {
            "id": row["substation_id"],
            "station": row["station"],
            "pos": float(row["chainage_km"]),
        }
        for row in rows
        if row["substation_id"]
    ]
    if len(substations) != 16:
        raise ValueError(f"Expected 16 traction substations, found {len(substations)}")
    return substations


def train_nodes(input_t):
    brake = [
        {
            "id": f"B{i + 1}",
            "pos": input_t["brake_position"][i],
            "remaining": input_t["brake_power"][i],
        }
        for i in range(len(input_t["brake_power"]))
    ]
    traction = [
        {
            "id": f"T{i + 1}",
            "pos": input_t["traction_position"][i],
            "remaining": input_t["traction_power"][i],
        }
        for i in range(len(input_t["traction_power"]))
    ]
    return brake, traction


def feedback_dispatch(remaining_brake, substations):
    sinks = [
        {
            "id": station["id"],
            "pos": station["pos"],
            "remaining": FEEDBACK_CAPACITY_KW,
        }
        for station in substations
    ]
    return _greedy_allocate(remaining_brake, sinks, "brake_to_feedback")


def rank_substations(condition, substations):
    returned_kwh = {station["id"]: 0.0 for station in substations}
    for _, row in condition.iterrows():
        input_t = build_input_t(row, [SOC_INIT] * NUM_ESS)
        brake, traction = train_nodes(input_t)
        _, remaining_brake, _ = _greedy_allocate(
            brake, traction, "brake_to_traction"
        )
        feedback_flows, _, _ = feedback_dispatch(remaining_brake, substations)
        for flow in feedback_flows:
            returned_kwh[flow["to"]] += flow["power_kW"] * DT / 3600.0
    ranking = sorted(
        (
            {
                **station,
                "feedback_energy_kWh": returned_kwh[station["id"]],
            }
            for station in substations
        ),
        key=lambda item: (-item["feedback_energy_kWh"], item["id"]),
    )
    return ranking


def map_candidates_to_ess(ranking):
    selected = []
    unused = set(range(NUM_ESS))
    for station in ranking[:ESS_CANDIDATE_COUNT]:
        ess_index = min(
            unused,
            key=lambda index: abs(float(ESS_POSITIONS[index]) - station["pos"]),
        )
        unused.remove(ess_index)
        selected.append(
            {
                "substation_id": station["id"],
                "substation_station": station["station"],
                "substation_position_km": station["pos"],
                "feedback_energy_kWh": station["feedback_energy_kWh"],
                "ess_index": ess_index,
                "ess_id": f"ESS{ess_index + 1}",
                "ess_position_km": float(ESS_POSITIONS[ess_index]),
                "mapping_distance_km": abs(float(ESS_POSITIONS[ess_index]) - station["pos"]),
            }
        )
    return selected


def run(condition, substations, selected):
    selected_indices = [item["ess_index"] for item in selected]
    soc = [SOC_INIT] * NUM_ESS
    records = []
    flow_records = []
    start = time.perf_counter()

    for _, row in condition.iterrows():
        step_start = time.perf_counter()
        input_t = build_input_t(row, soc)
        brake, traction = train_nodes(input_t)
        direct_flows, remaining_brake, remaining_traction = _greedy_allocate(
            brake, traction, "brake_to_traction"
        )
        feedback_flows, remaining_brake, _ = feedback_dispatch(
            remaining_brake, substations
        )

        charge_limit_values = charge_limits(soc)
        charge_sinks = [
            {
                "id": f"ESS{index + 1}",
                "pos": float(ESS_POSITIONS[index]),
                "remaining": charge_limit_values[index],
            }
            for index in selected_indices
        ]
        charge_flows, remaining_brake, _ = _greedy_allocate(
            remaining_brake, charge_sinks, "brake_to_storage"
        )

        discharge_limit_values = discharge_limits(soc)
        discharge_sources = [
            {
                "id": f"ESS{index + 1}",
                "pos": float(ESS_POSITIONS[index]),
                "remaining": discharge_limit_values[index],
            }
            for index in selected_indices
        ]
        discharge_flows, _, remaining_traction = _greedy_allocate(
            discharge_sources, remaining_traction, "storage_to_traction"
        )

        flows = direct_flows + feedback_flows + charge_flows + discharge_flows
        loss_kw, min_voltage = calculate_flow_metrics(flows)
        charge_kw = [0.0] * NUM_ESS
        discharge_kw = [0.0] * NUM_ESS
        for flow in charge_flows:
            charge_kw[int(flow["to"][3:]) - 1] += flow["power_kW"]
        for flow in discharge_flows:
            discharge_kw[int(flow["from"][3:]) - 1] += flow["power_kW"]
        next_soc = update_soc(soc, charge_kw, discharge_kw)

        direct_kw = sum(flow["power_kW"] for flow in direct_flows)
        feedback_kw = sum(flow["power_kW"] for flow in feedback_flows)
        feedback_loss_kw = sum(flow["loss_kW"] for flow in feedback_flows)
        feedback_delivered_kw = max(0.0, feedback_kw - feedback_loss_kw)
        charge_total_kw = sum(charge_kw)
        discharge_total_kw = sum(discharge_kw)
        brake_kw = sum(input_t["brake_power"])
        traction_kw = sum(input_t["traction_power"])
        balance_without_grid_waste = (
            brake_kw
            + discharge_total_kw
            - traction_kw
            - charge_total_kw
            - feedback_delivered_kw
            - loss_kw
        )
        wasted_kw = max(0.0, balance_without_grid_waste)
        grid_kw = max(0.0, -balance_without_grid_waste)
        absorbed_kw = max(
            0.0, direct_kw + charge_total_kw + feedback_kw - loss_kw
        )
        solve_time_ms = (time.perf_counter() - step_start) * 1000.0
        voltage_violation = min_voltage < DC_VOLTAGE_MIN - 1e-6
        power_violation = grid_kw > P_SUB_MAX_KW + 1e-9

        record = {
            "time_s": input_t["time"],
            "brake_power_kW": brake_kw,
            "traction_power_kW": traction_kw,
            "power_surplus_kW": brake_kw - traction_kw,
            "p_direct_kW": direct_kw,
            "feedback_power_kW": feedback_kw,
            "feedback_delivered_kW": feedback_delivered_kw,
            "ess_charge_kW": charge_total_kw,
            "ess_discharge_kW": discharge_total_kw,
            "grid_power_kW": grid_kw,
            "wasted_power_kW": wasted_kw,
            "loss_kW": loss_kw,
            "absorbed_brake_power_kW": absorbed_kw,
            "absorption_rate_percent": absorbed_kw / brake_kw * 100.0 if brake_kw else 0.0,
            "soc_average": sum(next_soc) / NUM_ESS,
            "solve_time_ms": solve_time_ms,
            "min_voltage_V": min_voltage,
            "voltage_violation": voltage_violation,
            "power_violation": power_violation,
            "feasible": not voltage_violation and not power_violation,
            "power_balance_error_kW": (
                brake_kw
                + grid_kw
                + discharge_total_kw
                - traction_kw
                - charge_total_kw
                - feedback_delivered_kw
                - loss_kw
                - wasted_kw
            ),
        }
        for index in range(NUM_ESS):
            record[f"ESS{index + 1}_charge_kW"] = charge_kw[index]
            record[f"ESS{index + 1}_discharge_kW"] = discharge_kw[index]
            record[f"ESS{index + 1}_soc_percent"] = next_soc[index] * 100.0
        records.append(record)

        for flow in flows:
            flow_records.append(
                {
                    "time_s": input_t["time"],
                    "flow_type": flow["type"],
                    "from_node": flow["from"],
                    "to_node": flow["to"],
                    "from_pos_km": flow["from_pos"],
                    "to_pos_km": flow["to_pos"],
                    "distance_km": abs(flow["from_pos"] - flow["to_pos"]),
                    "power_kW": flow["power_kW"],
                    "loss_kW": flow["loss_kW"],
                    "receiving_voltage_V": flow["receiving_voltage_V"],
                }
            )
        soc = next_soc

    return pd.DataFrame(records), pd.DataFrame(flow_records), time.perf_counter() - start


def build_summary(result_df, total_runtime):
    total_regen = result_df["brake_power_kW"].sum() * DT / 3600.0
    direct = result_df["p_direct_kW"].sum() * DT / 3600.0
    feedback = result_df["feedback_power_kW"].sum() * DT / 3600.0
    charge = result_df["ess_charge_kW"].sum() * DT / 3600.0
    discharge = result_df["ess_discharge_kW"].sum() * DT / 3600.0
    loss = result_df["loss_kW"].sum() * DT / 3600.0
    used = max(0.0, direct + feedback + charge - loss)
    soc_columns = [f"ESS{i}_soc_percent" for i in range(1, NUM_ESS + 1)]
    metrics = [
        ("方法名称", "Geng2025 hierarchical feedback-priority baseline", "-"),
        ("总再生能量", total_regen, "kWh"),
        ("有效消纳能量", used, "kWh"),
        ("再生消纳率", used / total_regen * 100.0 if total_regen else 0.0, "%"),
        ("直接车车利用", direct, "kWh"),
        ("能馈回送", feedback, "kWh"),
        ("ESS充电", charge, "kWh"),
        ("ESS放电", discharge, "kWh"),
        ("弃能", result_df["wasted_power_kW"].sum() * DT / 3600.0, "kWh"),
        ("电网补能", result_df["grid_power_kW"].sum() * DT / 3600.0, "kWh"),
        ("网损", loss, "kWh"),
        ("初始SOC", SOC_INIT * 100.0, "%"),
        ("最终平均SOC", result_df[soc_columns].iloc[-1].mean(), "%"),
        ("最大SOC", result_df[soc_columns].max().max(), "%"),
        ("最小SOC", result_df[soc_columns].min().min(), "%"),
        ("总求解时间", total_runtime, "s"),
        ("平均单步时间", result_df["solve_time_ms"].mean(), "ms"),
        ("最大单步时间", result_df["solve_time_ms"].max(), "ms"),
        ("电压越限次数", int(result_df["voltage_violation"].sum()), "次"),
        ("功率越限次数", int(result_df["power_violation"].sum()), "次"),
        ("不可行步数", int((~result_df["feasible"].astype(bool)).sum()), "步"),
    ]
    return pd.DataFrame(metrics, columns=["指标", "数值", "单位"])


def main():
    case_config = json.loads(CASE_CONFIG_FILE.read_text(encoding="utf-8"))
    if case_config["ess"]["capacity_kWh"] != 1000.0:
        raise ValueError("Corrected ESS capacity must be 1000 kWh")
    condition = load_case_data(CASE_FILE)
    substations = load_substations()
    ranking = rank_substations(condition, substations)
    selected = map_candidates_to_ess(ranking)
    result_df, flow_df, total_runtime = run(condition, substations, selected)
    if result_df["power_balance_error_kW"].abs().max() > 1e-5:
        raise ValueError("Hierarchical baseline power balance residual exceeds tolerance")
    summary_df = build_summary(result_df, total_runtime)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    result_df.to_csv(
        OUTPUT_DIR / "TimeSeries_Result.csv", index=False, encoding="utf-8-sig"
    )
    flow_df.to_csv(
        OUTPUT_DIR / "Flow_Result.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(ranking).to_csv(
        OUTPUT_DIR / "Substation_Ranking.csv", index=False, encoding="utf-8-sig"
    )
    summary_df.to_csv(
        OUTPUT_DIR / "Summary_Result.csv", index=False, encoding="utf-8-sig"
    )
    selection = {
        "method": "Geng2025 hierarchical full-line feedback then storage",
        "adaptation_boundary": (
            "The paper's unnamed line is not treated as Beijing Line 5 field data."
        ),
        "feedback_device_count": len(substations),
        "feedback_capacity_per_station_kW": FEEDBACK_CAPACITY_KW,
        "selected_ess_candidates": selected,
        "selection_rule": "top 3 substations by returned regenerative energy, mapped to the nearest supplied ESS site",
    }
    (OUTPUT_DIR / "Selected_ESS_Candidates.json").write_text(
        json.dumps(selection, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(summary_df.to_string(index=False))
    print(json.dumps(selection, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
