"""Aggregate, validate, visualize, and report the engineering-case results."""

import json
import math
import os
from pathlib import Path
from urllib.parse import quote

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


SIMULATION_ROOT = Path(__file__).resolve().parents[2]
CASE_KEY = "BeijingLine5_EngineeringCase"
RESULT_ROOT = Path(
    os.environ.get(
        "BENCHMARK_RESULT_ROOT",
        SIMULATION_ROOT / "results",
    )
).resolve() / CASE_KEY
OUTPUT_DIR = RESULT_ROOT / "Comparison_Report"
PREPARED_DIR = (
    SIMULATION_ROOT / "reused_from_previous_algorithms" / "prepared_inputs"
)
LITERATURE_FILE = (
    SIMULATION_ROOT
    / "reused_from_previous_algorithms"
    / "literature_baseline"
    / "geng2025_hierarchical_baseline.json"
)
HISTORICAL_QBOSON_FILE = (
    SIMULATION_ROOT.parent / "results" / "QBoson_Quantum_Time_Summary.csv"
)
CURRENT_QBOSON_BATCH_FILE = (
    RESULT_ROOT / "Quantum_QUBO" / "Batch_Summary_10ESS_10sBatch.csv"
)

METHODS = [
    (
        "Ground-SC",
        RESULT_ROOT / "Ground_SC" / "excel_result" / "Summary_Result.csv",
        "本地经典控制",
    ),
    (
        "Gao2015",
        RESULT_ROOT / "Gao2015" / "excel_result" / "Summary_Result.csv",
        "本地经典控制",
    ),
    (
        "MILP",
        RESULT_ROOT / "MILP" / "excel_result" / "Summary_Result.csv",
        "本地优化",
    ),
    (
        "Genetic Algorithm",
        RESULT_ROOT / "Genetic_Algorithm" / "excel_result" / "Summary_Result.csv",
        "本地智能优化",
    ),
    (
        "k-flip",
        RESULT_ROOT / "k_flip" / "excel_result" / "Summary_Result.csv",
        "本地图优化",
    ),
    (
        "Dynamic QUBO + CIM",
        RESULT_ROOT / "Quantum_QUBO" / "Summary_Result_10ESS_10sBatch.csv",
        "QBoson真实CIM，15/15批完成，无本地回退",
    ),
    (
        "Geng hierarchical",
        RESULT_ROOT / "Geng_Hierarchical_Baseline" / "Summary_Result.csv",
        "耿晓彤文献方法的北京5号线适配基线",
    ),
]

OKABE_ITO = [
    "#0072B2",
    "#E69F00",
    "#009E73",
    "#CC79A7",
    "#56B4E9",
    "#D55E00",
    "#000000",
]


def configure_style():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [
                "Microsoft YaHei",
                "SimHei",
                "Arial Unicode MS",
                "DejaVu Sans",
            ],
            "axes.unicode_minus": False,
            "font.size": 8,
            "axes.labelsize": 9,
            "axes.titlesize": 9,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.bbox": "tight",
        }
    )


def numeric(value, label):
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Non-numeric summary value for {label}: {value!r}") from exc


def read_metric_summary(path):
    frame = pd.read_csv(path, encoding="utf-8-sig")
    if not {"指标", "数值", "单位"}.issubset(frame.columns):
        raise ValueError(f"Unexpected summary schema: {path}")
    return {
        str(row["指标"]): row["数值"]
        for _, row in frame.iterrows()
    }


def build_comparison():
    records = []
    for method, path, status in METHODS:
        summary = read_metric_summary(path)
        record = {
            "algorithm": method,
            "execution_status": status,
            "total_regenerative_energy_kWh": numeric(
                summary["总再生能量"], f"{method}/总再生能量"
            ),
            "effective_absorbed_energy_kWh": numeric(
                summary["有效消纳能量"], f"{method}/有效消纳能量"
            ),
            "absorption_rate_percent": numeric(
                summary["再生消纳率"], f"{method}/再生消纳率"
            ),
            "wasted_energy_kWh": numeric(summary["弃能"], f"{method}/弃能"),
            "grid_energy_kWh": numeric(summary["电网补能"], f"{method}/电网补能"),
            "line_loss_energy_kWh": numeric(summary["网损"], f"{method}/网损"),
            "initial_soc_percent": numeric(summary["初始SOC"], f"{method}/初始SOC"),
            "final_average_soc_percent": numeric(
                summary["最终平均SOC"], f"{method}/最终平均SOC"
            ),
            "total_solver_time_s": numeric(
                summary["总求解时间"], f"{method}/总求解时间"
            ),
            "voltage_violation_count": int(
                numeric(summary["电压越限次数"], f"{method}/电压越限次数")
            ),
            "power_violation_count": int(
                numeric(summary["功率越限次数"], f"{method}/功率越限次数")
            ),
            "infeasible_step_count": int(
                numeric(summary["不可行步数"], f"{method}/不可行步数")
            ),
        }
        total_capacity_kwh = 10.0 * 1000.0
        soc_deficit_kwh = max(
            0.0,
            (record["initial_soc_percent"] - record["final_average_soc_percent"])
            / 100.0
            * total_capacity_kwh,
        )
        record["soc_recovery_grid_energy_kWh"] = soc_deficit_kwh / 0.95
        record["cyclic_equivalent_grid_energy_kWh"] = (
            record["grid_energy_kWh"] + record["soc_recovery_grid_energy_kWh"]
        )
        record["feasibility_pass"] = (
            record["voltage_violation_count"] == 0
            and record["power_violation_count"] == 0
            and record["infeasible_step_count"] == 0
        )
        records.append(record)
    frame = pd.DataFrame(records)
    regen_values = frame["total_regenerative_energy_kWh"].to_numpy()
    if not np.allclose(regen_values, regen_values[0], atol=1e-8):
        raise ValueError("Algorithms did not use the same regenerative-energy input")
    if not frame["feasibility_pass"].all():
        raise ValueError("One or more algorithms failed feasibility checks")
    frame["absorption_rank"] = (
        frame["absorption_rate_percent"].rank(method="min", ascending=False).astype(int)
    )
    frame["cyclic_grid_rank"] = (
        frame["cyclic_equivalent_grid_energy_kWh"]
        .rank(method="min", ascending=True)
        .astype(int)
    )
    return frame


def quantum_time_provenance():
    batches = pd.read_csv(CURRENT_QBOSON_BATCH_FILE, encoding="utf-8-sig")
    if len(batches) != 15:
        raise ValueError("Current Beijing CIM run must contain 15 batches")
    if not batches["solver_backend"].astype(str).str.upper().eq("CIM").all():
        raise ValueError("Current Beijing quantum run contains non-CIM batches")
    if not batches["solver_status"].astype(str).str.lower().eq("completed").all():
        raise ValueError("Current Beijing CIM run contains incomplete batches")
    summary = read_metric_summary(
        RESULT_ROOT / "Quantum_QUBO" / "Summary_Result_10ESS_10sBatch.csv"
    )
    current_end_to_end_s = numeric(
        summary["总求解时间"], "Dynamic QUBO + CIM/总求解时间"
    )
    current_roundtrip_s = float(batches["cim_call_time_s"].sum())
    current_batches = len(batches)

    history = pd.read_csv(HISTORICAL_QBOSON_FILE, encoding="utf-8-sig")
    row = history.loc[history["scale"] == "S03"].iloc[0]
    if float(row["coverage_percent"]) != 100.0:
        raise ValueError("Historical S03 QBoson timing coverage must be complete")
    historical_reports = int(row["available_matching_reports"])
    measured_s = float(row["verified_quantum_runtime_s"])
    return pd.DataFrame(
        [
            {
                "timing_item": "Current Beijing end-to-end solver time",
                "value_s": current_end_to_end_s,
                "report_count": current_batches,
                "status": "measured by the current run",
                "applicability": "QUBO build, 15 CIM calls, and physical decoding",
            },
            {
                "timing_item": "Current Beijing CIM SDK round-trip total",
                "value_s": current_roundtrip_s,
                "report_count": current_batches,
                "status": "measured by the current run",
                "applicability": "includes platform validation, queue, polling, and result transfer; not hardware runtime",
            },
            {
                "timing_item": "Current Beijing CIM SDK round-trip mean",
                "value_s": current_roundtrip_s / current_batches,
                "report_count": 1,
                "status": "derived from the current 15 completed batches",
                "applicability": "wall-clock platform-call reference per batch",
            },
            {
                "timing_item": "Current Beijing CIM hardware runtime",
                "value_s": np.nan,
                "report_count": 0,
                "status": "15 platform PDF reports not yet exported",
                "applicability": "must be read from current task reports; SDK round-trip time is not a substitute",
            },
            {
                "timing_item": "Historical S03 measured quantum runtime",
                "value_s": measured_s,
                "report_count": historical_reports,
                "status": "QBoson PDF measured; complete archive coverage",
                "applicability": "same 10ESS/100-variable batch scale; not the current Beijing run",
            },
            {
                "timing_item": "Historical per-batch mean",
                "value_s": measured_s / historical_reports,
                "report_count": 1,
                "status": "derived from complete historical S03 reports",
                "applicability": "reference only",
            },
        ]
    )


def cost_sensitivity(comparison):
    literature = json.loads(LITERATURE_FILE.read_text(encoding="utf-8"))
    price = float(literature["cost_model"]["electricity_price_CNY_per_kWh"])
    horizon = int(literature["cost_model"]["study_horizon_years"])
    ess_2mw = next(
        row
        for row in literature["cost_model"]["device_costs_ten_thousand_CNY"]
        if row["device"] == "ESS" and row["capacity_MW"] == 2
    )
    feedback_4mw = next(
        row
        for row in literature["cost_model"]["device_costs_ten_thousand_CNY"]
        if row["device"] == "energy_feedback"
    )
    # Capacity-dependent components are linearly prorated from the paper's
    # 2 MW ESS row; the per-site switch cost is retained as fixed.
    scale = 0.5 / 2.0
    ess_half_mw_site = (
        ess_2mw["C_eq"] * scale
        + ess_2mw["C_switch"]
        + ess_2mw["C_install"] * scale
        + ess_2mw["C_om"] * scale
    )
    feedback_site = sum(
        feedback_4mw[key] for key in ("C_eq", "C_switch", "C_install", "C_om")
    )
    rows = []
    for _, algorithm in comparison.iterrows():
        if algorithm["algorithm"] == "Geng hierarchical":
            asset_cost = 16 * feedback_site + 3 * ess_half_mw_site
            asset_scope = "16 x 4 MW feedback + 3 x 0.5 MW ESS"
        else:
            asset_cost = 10 * ess_half_mw_site
            asset_scope = "10 x 0.5 MW ESS"
        for windows_per_day in (1, 100, 480):
            electricity_cost = (
                algorithm["cyclic_equivalent_grid_energy_kWh"]
                * windows_per_day
                * 365
                * horizon
                * price
                / 10000.0
            )
            rows.append(
                {
                    "algorithm": algorithm["algorithm"],
                    "equivalent_150s_windows_per_day": windows_per_day,
                    "asset_cost_30y_ten_thousand_CNY": asset_cost,
                    "traction_electricity_cost_30y_ten_thousand_CNY": electricity_cost,
                    "total_lifecycle_cost_30y_ten_thousand_CNY": asset_cost + electricity_cost,
                    "cyclic_equivalent_grid_energy_per_window_kWh": algorithm[
                        "cyclic_equivalent_grid_energy_kWh"
                    ],
                    "asset_scope": asset_scope,
                    "cost_status": "literature-normalized engineering sensitivity, not Beijing procurement quote",
                }
            )
    return pd.DataFrame(rows), {
        "electricity_price_CNY_per_kWh": price,
        "study_horizon_years": horizon,
        "half_mw_ess_site_cost_ten_thousand_CNY": ess_half_mw_site,
        "four_mw_feedback_site_cost_ten_thousand_CNY": feedback_site,
    }


def aggregate_energy_paths():
    qubo = pd.read_csv(
        RESULT_ROOT / "Quantum_QUBO" / "TimeSeries_Result_10ESS_10sBatch.csv",
        encoding="utf-8-sig",
    )
    geng = pd.read_csv(
        RESULT_ROOT / "Geng_Hierarchical_Baseline" / "TimeSeries_Result.csv",
        encoding="utf-8-sig",
    )
    paths = pd.DataFrame(
        [
            {
                "algorithm": "Dynamic QUBO + CIM",
                "direct_energy_kWh": qubo["p_direct_kW"].sum() / 3600.0,
                "feedback_energy_kWh": 0.0,
                "ess_charge_energy_kWh": qubo["ess_charge_kW"].sum() / 3600.0,
                "ess_discharge_energy_kWh": qubo["ess_discharge_kW"].sum() / 3600.0,
                "line_loss_energy_kWh": qubo["loss_kW"].sum() / 3600.0,
                "grid_energy_kWh": qubo["grid_power_kW"].sum() / 3600.0,
            },
            {
                "algorithm": "Geng hierarchical",
                "direct_energy_kWh": geng["p_direct_kW"].sum() / 3600.0,
                "feedback_energy_kWh": geng["feedback_power_kW"].sum() / 3600.0,
                "ess_charge_energy_kWh": geng["ess_charge_kW"].sum() / 3600.0,
                "ess_discharge_energy_kWh": geng["ess_discharge_kW"].sum() / 3600.0,
                "line_loss_energy_kWh": geng["loss_kW"].sum() / 3600.0,
                "grid_energy_kWh": geng["grid_power_kW"].sum() / 3600.0,
            },
        ]
    )
    cumulative = pd.DataFrame(
        {
            "time_s": qubo["time_s"],
            "qubo_cumulative_absorbed_kWh": (
                qubo["p_direct_kW"] + qubo["ess_charge_kW"] - qubo["loss_kW"]
            ).cumsum()
            / 3600.0,
            "geng_cumulative_absorbed_kWh": (
                geng["p_direct_kW"]
                + geng["feedback_power_kW"]
                + geng["ess_charge_kW"]
                - geng["loss_kW"]
            ).cumsum()
            / 3600.0,
            "cumulative_regenerative_input_kWh": qubo[
                "brake_power_kW"
            ].cumsum()
            / 3600.0,
        }
    )
    flows = pd.read_csv(
        RESULT_ROOT / "Geng_Hierarchical_Baseline" / "Flow_Result.csv",
        encoding="utf-8-sig",
    )
    interaction = (
        flows.assign(
            energy_kWh=flows["power_kW"] / 3600.0,
            loss_energy_kWh=flows["loss_kW"] / 3600.0,
        )
        .groupby(["flow_type", "from_node", "to_node"], as_index=False)[
            ["energy_kWh", "loss_energy_kWh"]
        ]
        .sum()
        .sort_values("energy_kWh", ascending=False)
    )
    return qubo, geng, paths, cumulative, interaction


def build_google_map_import():
    network = pd.read_csv(
        PREPARED_DIR / "BeijingLine5_station_network.csv", encoding="utf-8-sig"
    ).fillna("")
    rows = []
    for _, row in network.iterrows():
        marker_types = []
        if row["substation_id"]:
            marker_types.append("牵引变电所")
        if row["ess_id"]:
            marker_types.append("ESS")
        if not marker_types:
            marker_types.append("车站")
        query = f"北京市 北京地铁5号线 {row['station']}站"
        rows.append(
            {
                "name": row["station"],
                "address_for_google_mymaps": query,
                "marker_type": "+".join(marker_types),
                "chainage_km": row["chainage_km"],
                "substation_id": row["substation_id"],
                "ess_id": row["ess_id"],
                "supply_zone": row["supply_zone"],
                "google_maps_search_url": (
                    "https://www.google.com/maps/search/?api=1&query=" + quote(query)
                ),
                "coordinate_status": "address geocoding required; longitude/latitude not supplied",
            }
        )
    return pd.DataFrame(rows), network


def save_figure_1(comparison, quantum_time):
    labels = comparison["algorithm"].tolist()
    short = [
        "Ground-SC",
        "Gao2015",
        "MILP",
        "GA",
        "k-flip",
        "QUBO",
        "Geng",
    ]
    colors = OKABE_ITO[: len(labels)]
    x = np.arange(len(labels))
    fig, axes = plt.subplots(2, 2, figsize=(8.0, 5.8))

    ax = axes[0, 0]
    values = comparison["absorption_rate_percent"].to_numpy()
    ax.bar(x, values, color=colors, edgecolor="black", linewidth=0.4)
    for index, value in enumerate(values):
        ax.text(index, value + 0.35, f"{value:.1f}", ha="center", va="bottom", fontsize=6)
    ax.set_ylabel("Regenerative absorption rate (%)")
    ax.set_xticks(x, short, rotation=35, ha="right")
    ax.set_ylim(0, max(values) * 1.12)
    ax.set_title("A  Energy absorption")

    ax = axes[0, 1]
    width = 0.38
    ax.bar(
        x - width / 2,
        comparison["effective_absorbed_energy_kWh"],
        width,
        label="Effective absorbed",
        color="#0072B2",
    )
    ax.bar(
        x + width / 2,
        comparison["line_loss_energy_kWh"],
        width,
        label="Line loss",
        color="#E69F00",
        hatch="//",
    )
    ax.set_ylabel("Energy (kWh per 150 s)")
    ax.set_xticks(x, short, rotation=35, ha="right")
    ax.legend(frameon=False, ncol=2)
    ax.set_title("B  Effective energy and loss")

    ax = axes[1, 0]
    raw = comparison["grid_energy_kWh"].to_numpy()
    recovery = comparison["soc_recovery_grid_energy_kWh"].to_numpy()
    ax.bar(x, raw, label="Reported grid energy", color="#56B4E9")
    ax.bar(
        x,
        recovery,
        bottom=raw,
        label="SOC recovery to cyclic state",
        color="#D55E00",
        hatch="..",
    )
    ax.set_ylabel("Grid-equivalent energy (kWh)")
    ax.set_xticks(x, short, rotation=35, ha="right")
    ax.set_ylim(0, max(raw + recovery) * 1.16)
    ax.legend(frameon=False, ncol=2, loc="upper center")
    ax.set_title("C  Cyclic-state correction")

    ax = axes[1, 1]
    runtimes = comparison["total_solver_time_s"].clip(lower=1e-4).to_numpy()
    ax.bar(x, runtimes, color=colors, edgecolor="black", linewidth=0.4)
    current_roundtrip = float(
        quantum_time.loc[
            quantum_time["timing_item"]
            == "Current Beijing CIM SDK round-trip total",
            "value_s",
        ].iloc[0]
    )
    qubo_index = labels.index("Dynamic QUBO + CIM")
    ax.scatter(
        [qubo_index],
        [current_roundtrip],
        marker="D",
        s=42,
        color="#F0E442",
        edgecolor="black",
        linewidth=0.5,
        zorder=4,
        label="Current CIM SDK round-trip total",
    )
    ax.set_yscale("log")
    ax.set_ylabel("Solver time (s, log scale)")
    ax.set_xticks(x, short, rotation=35, ha="right")
    ax.legend(frameon=False, loc="upper left")
    ax.set_title("D  Runtime provenance")

    fig.suptitle(
        "Beijing Line 5 reconstructed 150 s case (n=1 deterministic scenario)",
        fontsize=10,
    )
    fig.tight_layout()
    for suffix in ("png", "pdf"):
        fig.savefig(OUTPUT_DIR / f"Figure_1_Algorithm_Comparison.{suffix}", dpi=400)
    plt.close(fig)


def save_figure_2(network, cumulative, paths, ranking):
    fig = plt.figure(figsize=(8.1, 7.2))
    grid = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.32)

    ax = fig.add_subplot(grid[0, :])
    chainage = network["chainage_km"].astype(float).to_numpy()
    ax.hlines(0, chainage.min(), chainage.max(), color="#777777", linewidth=1.2)
    ax.scatter(chainage, np.zeros_like(chainage), color="#777777", s=15, label="Station")
    sub = network[network["substation_id"] != ""]
    ess = network[network["ess_id"] != ""]
    ax.scatter(
        sub["chainage_km"],
        np.full(len(sub), 0.08),
        marker="s",
        s=35,
        color="#0072B2",
        label="Traction substation",
    )
    ax.scatter(
        ess["chainage_km"],
        np.full(len(ess), -0.08),
        marker="^",
        s=45,
        color="#D55E00",
        label="ESS",
    )
    for _, row in network.iterrows():
        ax.text(
            float(row["chainage_km"]),
            -0.15,
            str(row["station"]),
            rotation=65,
            ha="right",
            va="top",
            fontsize=5.5,
        )
    ax.set_xlim(chainage.min() - 1.25, chainage.max() + 0.5)
    ax.set_ylim(-0.48, 0.28)
    ax.set_yticks([])
    ax.set_xlabel("Cumulative chainage (km)")
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.set_title("A  Line topology, traction substations, and ESS locations")

    ax = fig.add_subplot(grid[1, 0])
    ax.plot(
        cumulative["time_s"],
        cumulative["cumulative_regenerative_input_kWh"],
        color="#000000",
        linestyle=":",
        label="Regenerative input",
    )
    ax.plot(
        cumulative["time_s"],
        cumulative["qubo_cumulative_absorbed_kWh"],
        color="#0072B2",
        label="Dynamic QUBO",
    )
    ax.plot(
        cumulative["time_s"],
        cumulative["geng_cumulative_absorbed_kWh"],
        color="#D55E00",
        linestyle="--",
        label="Geng hierarchical",
    )
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Cumulative energy (kWh)")
    ax.legend(frameon=False)
    ax.set_title("B  Cumulative regenerative-energy matching")

    ax = fig.add_subplot(grid[1, 1])
    ranking = ranking.sort_values("feedback_energy_kWh", ascending=True)
    bar_colors = [
        "#D55E00" if value > 0 else "#BBBBBB"
        for value in ranking["feedback_energy_kWh"]
    ]
    ax.barh(
        ranking["id"] + " " + ranking["station"],
        ranking["feedback_energy_kWh"],
        color=bar_colors,
    )
    ax.set_xlabel("Returned regenerative energy (kWh)")
    ax.set_title("C  Hierarchical substation ranking")

    fig.suptitle(
        "Spatial and temporal energy interaction (chainage-based; coordinates not supplied)",
        fontsize=10,
    )
    fig.subplots_adjust(bottom=0.06, top=0.93)
    for suffix in ("png", "pdf"):
        fig.savefig(OUTPUT_DIR / f"Figure_2_Energy_Interaction.{suffix}", dpi=400)
    plt.close(fig)


def write_report(comparison, costs, cost_parameters, quantum_time, paths, ranking):
    ranking_by_absorption = comparison.sort_values(
        "absorption_rate_percent", ascending=False
    )
    best = ranking_by_absorption.iloc[0]
    qubo = comparison.loc[
        comparison["algorithm"] == "Dynamic QUBO + CIM"
    ].iloc[0]
    geng = comparison.loc[comparison["algorithm"] == "Geng hierarchical"].iloc[0]
    one_day_cost = costs[costs["equivalent_150s_windows_per_day"] == 1].copy()
    current_roundtrip = quantum_time.loc[
        quantum_time["timing_item"]
        == "Current Beijing CIM SDK round-trip total",
        "value_s",
    ].iloc[0]
    current_roundtrip_mean = quantum_time.loc[
        quantum_time["timing_item"]
        == "Current Beijing CIM SDK round-trip mean",
        "value_s",
    ].iloc[0]
    top_feedback = ranking.iloc[0]

    lines = [
        "# 北京地铁5号线10ESS工程案例仿真与能量结果",
        "",
        "## 结论先行",
        "",
        f"- 输入已满足算法运行：150个1 s时间步、3制动列车、3牵引列车、10个ESS、23站累计里程、16座牵引变电所和4个等效供电分区均已通过校验。",
        "- 原工作簿中的5.1 kWh已由补充表明确修正为1000 kWh；充/放电功率均为500 kW，初始SOC为50%。",
        f"- 单场景消纳率最高的是 {best['algorithm']}（{best['absorption_rate_percent']:.2f}%）；Dynamic QUBO + CIM真实平台结果为{qubo['absorption_rate_percent']:.2f}%，耿晓彤分层基线为{geng['absorption_rate_percent']:.2f}%。",
        f"- 分层基线仅比QUBO高{geng['absorption_rate_percent'] - qubo['absorption_rate_percent']:.2f}个百分点，但需要16套4 MW能馈装置；该150 s场景中第三个储能候选变电所的回馈能量为0，表明全线配置存在明显冗余。",
        "- 所有7种方法均为0次电压越限、0次功率越限、0个不可行时间步。",
        "",
        "## 6.1 实际线路案例与方法设置",
        "",
        "线路采用北京地铁5号线天通苑北—宋家庄23站累计里程。算法距离D_ij按累计里程计算；经纬度仍未提供，因此本结果给出线路里程拓扑图和可导入Google My Maps的地址标点表，不把地址自动地理编码当成精确工程坐标。",
        "",
        "功率序列来自物理约束重构，不是运营SCADA实测。比较统一使用0.134 Ω/km的Benchmark阻抗解释、1500 V直流牵引网、SOC 20%—90%、效率95%、10×1000 kWh ESS和500 kW双向功率限制。",
        "",
        "耿晓彤基线按文献的“先全线能馈、后按需储能”实施：16座牵引变电所各配置4 MW能馈，按回馈能量排名选择3个储能候选点，再映射到最近的已给定ESS站点。该文献线路匿名，因此这里只作为方法基线。",
        "",
        "## 6.2 消纳、成本与能量交互",
        "",
        "### 算法能量比较",
        "",
        "| 算法 | 有效消纳(kWh) | 消纳率(%) | 网损(kWh) | 原始电网补能(kWh) | SOC回补(kWh) | 循环等效补能(kWh) | 总求解时间(s) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in ranking_by_absorption.iterrows():
        lines.append(
            f"| {row['algorithm']} | {row['effective_absorbed_energy_kWh']:.4f} | {row['absorption_rate_percent']:.2f} | {row['line_loss_energy_kWh']:.4f} | {row['grid_energy_kWh']:.4f} | {row['soc_recovery_grid_energy_kWh']:.4f} | {row['cyclic_equivalent_grid_energy_kWh']:.4f} | {row['total_solver_time_s']:.4f} |"
        )
    lines.extend(
        [
            "",
            "原始电网补能不能直接用于全生命周期比较，因为各算法都消耗了不同数量的初始储能。表中增加了把最终SOC恢复到50%所需的电网能量，形成可重复运行的循环等效口径。",
            "",
            "### 分层能量匹配",
            "",
            f"耿晓彤基线的直接车车利用为{paths.loc[paths['algorithm'] == 'Geng hierarchical', 'direct_energy_kWh'].iloc[0]:.4f} kWh，能馈回送为{paths.loc[paths['algorithm'] == 'Geng hierarchical', 'feedback_energy_kWh'].iloc[0]:.4f} kWh，ESS充电为0 kWh；能馈贡献最高的是{top_feedback['station']}（{top_feedback['id']}，{top_feedback['feedback_energy_kWh']:.4f} kWh）。这说明本场景剩余制动能量很小，4 MW/站的能馈容量远高于需要。",
            "",
            "### 30年全生命周期成本敏感性",
            "",
            f"成本沿用耿晓彤文献口径：电价{cost_parameters['electricity_price_CNY_per_kWh']:.2f}元/kWh、30年。0.5 MW ESS按文献2 MW设备线性折算容量相关成本并保留固定开关成本，为{cost_parameters['half_mw_ess_site_cost_ten_thousand_CNY']:.1f}万元/站；4 MW能馈为{cost_parameters['four_mw_feedback_site_cost_ten_thousand_CNY']:.1f}万元/站。",
            "",
            "| 算法 | 资产及30年运维(万元) | 1个等效150s窗口/日时电费(万元) | 30年合计(万元) |",
            "|---|---:|---:|---:|",
        ]
    )
    for _, row in one_day_cost.sort_values(
        "total_lifecycle_cost_30y_ten_thousand_CNY"
    ).iterrows():
        lines.append(
            f"| {row['algorithm']} | {row['asset_cost_30y_ten_thousand_CNY']:.2f} | {row['traction_electricity_cost_30y_ten_thousand_CNY']:.2f} | {row['total_lifecycle_cost_30y_ten_thousand_CNY']:.2f} |"
        )
    lines.extend(
        [
            "",
            "完整CSV同时给出1、100、480个等效窗口/日的敏感性。由于缺少北京5号线采购价、折现率、替换周期和全日车次频率，以上只能称为文献归一化工程估算，不能称为项目概算。",
            "",
            "### 量子时间说明",
            "",
            "本次北京5号线Dynamic QUBO已完成15/15个QBoson CIM批次，平台CIM批次数为15，本地后备批次数为0；150个物理解码时间步全部可行。原SCIP后备结果仅保留在Quantum_QUBO/SCIP_Fallback中，不参与主表排名。",
            "",
            f"当前15批SDK平台调用往返时间合计{current_roundtrip:.6f} s，平均{current_roundtrip_mean:.6f} s/批；该时间包含平台校验、排队、轮询和结果传输，不等于CIM硬件运行时长。当前任务的15份平台PDF尚未导出，因此硬件真实时间保持为空，不使用线性外推。此前S03同规模3份PDF的0.0469204 s只保留为历史参考。",
            "",
            "## 工程适用条件与不足",
            "",
            "- 0.134 Ω被统一当作Ω/km以保持与经典算法同config；补充表同时给出钢轨0.009 Ω/km和接触网0.003 Ω/km，建议后续做0.012 Ω/km阻抗敏感性，避免把Benchmark等效值误当成线路实测分布参数。",
            "- 经纬度缺失不影响D_ij和算法运行，但正式Google底图应补齐并核验车站/变电所坐标；当前My Maps表依靠地址地理编码。",
            "- 当前场景只有一条150 s重构序列，不能据此给出统计显著性或全年节能置信区间；应增加多运行图、多负荷日和实测SCADA校准。",
            "- 循环运行必须增加终端SOC约束或回补电量，否则原始电网补能会因消耗初始储能而被低估。",
            "- 分层基线显示只有崇文门、东单出现非零能馈贡献，应先缩小能馈站点和容量，再做投资优化；直接按文献全线4 MW布置不经济。",
            "",
            "## 6.3 本案例小结",
            "",
            f"在统一工程输入下，Ground-SC以{best['absorption_rate_percent']:.2f}%取得最高消纳率；真实CIM QUBO为{qubo['absorption_rate_percent']:.2f}%，未超过Ground-SC或分层基线。QUBO仍具备把动态拓扑、SOC和多储能模式统一写入离散优化的优势，但本次结果表明其参数与物理解码器还需要校准，不能仅凭量子求解形式宣称能量性能更优。工程上优先建议：补齐精确坐标与实测阻抗，加入终端SOC约束，并缩减能馈候选站后继续校准。",
            "",
            "## 数据边界",
            "",
            "本报告中的线路里程、变电所和供电分区来自用户输入；功率为物理约束重构；成本来自耿晓彤文献归一化；当前量子能量结果来自15个真实QBoson CIM任务，SDK往返时间与PDF硬件时间严格分开；历史量子时间来自此前QBoson PDF归档。",
        ]
    )
    (OUTPUT_DIR / "Chapter6_Engineering_Case_Analysis.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    configure_style()
    comparison = build_comparison()
    quantum_time = quantum_time_provenance()
    costs, cost_parameters = cost_sensitivity(comparison)
    qubo, geng, paths, cumulative, interaction = aggregate_energy_paths()
    google_map, network = build_google_map_import()
    ranking = pd.read_csv(
        RESULT_ROOT / "Geng_Hierarchical_Baseline" / "Substation_Ranking.csv",
        encoding="utf-8-sig",
    )

    comparison.to_csv(
        OUTPUT_DIR / "Algorithm_Energy_Comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )
    costs.to_csv(
        OUTPUT_DIR / "Lifecycle_Cost_Sensitivity.csv",
        index=False,
        encoding="utf-8-sig",
    )
    quantum_time.to_csv(
        OUTPUT_DIR / "Quantum_Time_Provenance.csv",
        index=False,
        encoding="utf-8-sig",
    )
    paths.to_csv(
        OUTPUT_DIR / "Algorithm_Energy_Pathways.csv",
        index=False,
        encoding="utf-8-sig",
    )
    cumulative.to_csv(
        OUTPUT_DIR / "Cumulative_Energy_TimeSeries.csv",
        index=False,
        encoding="utf-8-sig",
    )
    interaction.to_csv(
        OUTPUT_DIR / "Node_Energy_Interaction_Matrix.csv",
        index=False,
        encoding="utf-8-sig",
    )
    google_map.to_csv(
        OUTPUT_DIR / "Google_MyMaps_Marker_Import.csv",
        index=False,
        encoding="utf-8-sig",
    )

    save_figure_1(comparison, quantum_time)
    save_figure_2(network, cumulative, paths, ranking)
    write_report(
        comparison,
        costs,
        cost_parameters,
        quantum_time,
        paths,
        ranking,
    )

    manifest = {
        "case_key": CASE_KEY,
        "status": "completed_with_real_cim",
        "input_boundary": "physics-constrained reconstructed power profile; not operational SCADA",
        "platform_status": "15/15 QBoson CIM batches completed; 0 local fallback batches",
        "outputs": sorted(path.name for path in OUTPUT_DIR.iterdir() if path.is_file()),
        "checks": {
            "algorithms_compared": len(comparison),
            "same_regenerative_input": True,
            "all_feasible": bool(comparison["feasibility_pass"].all()),
            "time_steps_qubo": len(qubo),
            "time_steps_geng": len(geng),
            "quantum_cim_batches": 15,
            "quantum_local_fallback_batches": 0,
            "quantum_sdk_roundtrip_total_s": float(
                quantum_time.loc[
                    quantum_time["timing_item"]
                    == "Current Beijing CIM SDK round-trip total",
                    "value_s",
                ].iloc[0]
            ),
            "current_hardware_runtime_pdf_available": False,
            "map_coordinates_complete": False,
        },
    }
    (OUTPUT_DIR / "Result_Manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(comparison.to_string(index=False))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
