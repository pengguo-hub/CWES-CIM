"""Prepare the Beijing Line 5 input for the reused benchmark interfaces.

This script does not run an optimizer. It only validates and converts the
user-provided workbook into the common 3B+3T case schema and records the
provenance of the copied benchmark source files.
"""

import csv
import hashlib
import json
from bisect import bisect_right
from pathlib import Path

from openpyxl import load_workbook


SIMULATION_ROOT = Path(__file__).resolve().parents[2]
REUSE_ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = SIMULATION_ROOT / "input"
PREPARED_DIR = REUSE_ROOT / "prepared_inputs"
SNAPSHOT_DIR = REUSE_ROOT / "legacy_benchmark_snapshot"
BENCHMARK_ROOT = SIMULATION_ROOT.parent

# The original reconstructed train trajectories use a compact reference axis.
# These five route endpoints are explicitly named in the train plan, so they
# provide a traceable piecewise-linear calibration to the supplied cumulative
# Beijing Line 5 chainage.  No geographic coordinate is used by the optimizer.
POSITION_ANCHOR_STATIONS = [
    (4.0, "立水桥南"),
    (7.0, "大屯路东"),
    (10.0, "和平里北街"),
    (16.0, "东单"),
    (22.0, "宋家庄"),
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def numeric(value, label):
    if value is None:
        raise ValueError(f"Missing numeric value: {label}")
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Non-numeric value for {label}: {value!r}") from exc


def integer_time(value, label):
    parsed = numeric(value, label)
    if not parsed.is_integer():
        raise ValueError(f"Time value must be an integer: {label}={value!r}")
    return int(parsed)


def write_csv(path, headers, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


def unique_workbook(pattern, label):
    matches = sorted(INPUT_DIR.glob(pattern))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one {label} workbook, found {len(matches)}")
    return matches[0]


def sheet_key_values(sheet, key_col=1, value_col=2):
    values = {}
    for row_index in range(2, sheet.max_row + 1):
        key = sheet.cell(row_index, key_col).value
        if key is not None:
            values[str(key).strip()] = sheet.cell(row_index, value_col).value
    return values


def station_zone(station, station_order, zones):
    index = station_order.index(station)
    for zone in zones:
        if zone["start_index"] <= index <= zone["end_index"]:
            return zone["zone"]
    return ""


def calibrate_position(position, anchors):
    """Map the source reference position to cumulative line chainage."""
    source_axis = [item[0] for item in anchors]
    segment = bisect_right(source_axis, position) - 1
    segment = max(0, min(segment, len(anchors) - 2))
    x0, y0 = anchors[segment]
    x1, y1 = anchors[segment + 1]
    return y0 + (position - x0) * (y1 - y0) / (x1 - x0)


def load_engineering_data(workbook_path):
    workbook = load_workbook(workbook_path, data_only=True, read_only=False)
    required = {
        "01_站点累计里程",
        "02_站点经纬度",
        "03_牵引变电所",
        "04_等效供电分区",
        "05_线路阻抗参数",
        "06_ESS参数修正",
    }
    missing = sorted(required.difference(workbook.sheetnames))
    if missing:
        raise ValueError(f"Engineering workbook is missing sheets: {missing}")

    station_sheet = workbook["01_站点累计里程"]
    coordinate_sheet = workbook["02_站点经纬度"]
    substation_sheet = workbook["03_牵引变电所"]
    zone_sheet = workbook["04_等效供电分区"]
    impedance_sheet = workbook["05_线路阻抗参数"]
    correction_sheet = workbook["06_ESS参数修正"]

    stations = []
    for row_index in range(2, station_sheet.max_row + 1):
        station_id = station_sheet.cell(row_index, 1).value
        station = station_sheet.cell(row_index, 2).value
        if station_id is None or station is None:
            continue
        stations.append(
            {
                "station_id": str(station_id).strip(),
                "station": str(station).strip(),
                "chainage_km": numeric(
                    station_sheet.cell(row_index, 3).value,
                    f"station chainage C{row_index}",
                ),
            }
        )
    if len(stations) != 23:
        raise ValueError(f"Expected 23 Beijing Line 5 stations, found {len(stations)}")
    station_order = [row["station"] for row in stations]
    station_chainage = {row["station"]: row["chainage_km"] for row in stations}
    if any(
        right <= left
        for left, right in zip(
            [row["chainage_km"] for row in stations],
            [row["chainage_km"] for row in stations][1:],
        )
    ):
        raise ValueError("Station cumulative chainage must be strictly increasing")

    coordinates = {}
    for row_index in range(2, coordinate_sheet.max_row + 1):
        station = coordinate_sheet.cell(row_index, 2).value
        if station is None:
            continue
        longitude = coordinate_sheet.cell(row_index, 3).value
        latitude = coordinate_sheet.cell(row_index, 4).value
        coordinates[str(station).strip()] = {
            "longitude": "" if longitude in (None, "待补充") else longitude,
            "latitude": "" if latitude in (None, "待补充") else latitude,
        }

    substations = []
    for row_index in range(2, substation_sheet.max_row + 1):
        substation_id = substation_sheet.cell(row_index, 1).value
        station = substation_sheet.cell(row_index, 2).value
        if substation_id is None or station is None:
            continue
        station = str(station).strip()
        if station not in station_chainage:
            raise ValueError(f"Substation station is missing from chainage table: {station}")
        substations.append(
            {
                "substation_id": str(substation_id).strip(),
                "station": station,
                "chainage_km": station_chainage[station],
            }
        )
    if len(substations) != 16:
        raise ValueError(f"Expected 16 traction substations, found {len(substations)}")

    zones = []
    for row_index in range(2, zone_sheet.max_row + 1):
        zone = zone_sheet.cell(row_index, 1).value
        station_range = zone_sheet.cell(row_index, 2).value
        if zone is None or station_range is None:
            continue
        start_station, end_station = [
            value.strip() for value in str(station_range).split("-", maxsplit=1)
        ]
        if start_station not in station_chainage or end_station not in station_chainage:
            raise ValueError(f"Unknown station in supply zone: {station_range}")
        zones.append(
            {
                "zone": str(zone).strip(),
                "start_station": start_station,
                "end_station": end_station,
                "start_index": station_order.index(start_station),
                "end_index": station_order.index(end_station),
                "start_chainage_km": station_chainage[start_station],
                "end_chainage_km": station_chainage[end_station],
            }
        )
    if len(zones) != 4:
        raise ValueError(f"Expected 4 equivalent supply zones, found {len(zones)}")

    impedance = sheet_key_values(impedance_sheet)
    ess_correction = sheet_key_values(correction_sheet)
    engineering = {
        "source_workbook": str(workbook_path),
        "source_sha256": sha256(workbook_path),
        "stations": stations,
        "station_order": station_order,
        "station_chainage": station_chainage,
        "coordinates": coordinates,
        "substations": substations,
        "zones": zones,
        "line": {
            "equivalent_resistance_ohm": numeric(
                impedance["线路等效电阻"], "线路等效电阻"
            ),
            "traction_voltage_V": numeric(impedance["牵引网电压"], "牵引网电压"),
            "rail_resistance_ohm_per_km": numeric(
                impedance["钢轨电阻"], "钢轨电阻"
            ),
            "catenary_resistance_ohm_per_km": numeric(
                impedance["接触网电阻"], "接触网电阻"
            ),
        },
        "ess": {
            "count": int(numeric(ess_correction["ESS数量"], "ESS数量")),
            "capacity_kWh": numeric(ess_correction["容量"], "ESS容量"),
            "max_charge_kW": numeric(
                ess_correction["最大充电功率"], "ESS最大充电功率"
            ),
            "max_discharge_kW": numeric(
                ess_correction["最大放电功率"], "ESS最大放电功率"
            ),
            "initial_soc_ratio": numeric(ess_correction["初始SOC"], "ESS初始SOC"),
            "efficiency": numeric(ess_correction["效率"], "ESS效率"),
        },
    }
    if engineering["ess"]["count"] != 10:
        raise ValueError("The corrected engineering input must contain 10 ESS")
    return engineering


def prepare_case(workbook_path, engineering):
    workbook = load_workbook(workbook_path, data_only=True, read_only=False)
    required = {
        "03_列车位置150s",
        "04_150s功率输入",
        "05_ESS配置",
    }
    missing = sorted(required.difference(workbook.sheetnames))
    if missing:
        raise ValueError(f"Input workbook is missing sheets: {missing}")

    position_sheet = workbook["03_列车位置150s"]
    power_sheet = workbook["04_150s功率输入"]
    ess_sheet = workbook["05_ESS配置"]
    station_chainage = engineering["station_chainage"]
    position_anchors = [
        (source_position, station_chainage[station])
        for source_position, station in POSITION_ANCHOR_STATIONS
    ]

    expected_time = list(range(150))
    position_time = [
        integer_time(position_sheet.cell(row, 1).value, f"position A{row}")
        for row in range(2, 152)
    ]
    power_time = [
        integer_time(power_sheet.cell(row, 1).value, f"power A{row}")
        for row in range(2, 152)
    ]
    if position_time != expected_time or power_time != expected_time:
        raise ValueError("Position and power sheets must both contain time 0..149")

    case_headers = ["time_s", "phase"]
    for kind in ("brake", "traction"):
        for index in range(1, 4):
            case_headers.extend(
                [f"{kind}_train_{index}_kW", f"{kind}_train_{index}_pos_km"]
            )
    case_headers.extend(["brake_total_kW", "traction_total_kW", "power_surplus_kW"])

    case_rows = []
    positive_brake_inputs = []
    negative_traction_inputs = []
    for excel_row, time_s in zip(range(2, 152), expected_time):
        brake_power = []
        traction_power = []
        row = {"time_s": time_s, "phase": "reconstructed_beijing_line5"}
        for index in range(1, 4):
            raw = numeric(power_sheet.cell(excel_row, index + 1).value, f"brake row {excel_row}")
            if raw > 1e-9:
                positive_brake_inputs.append({"time_s": time_s, "train": f"B{index}", "value": raw})
            converted = max(0.0, -raw)
            source_position = numeric(
                position_sheet.cell(excel_row, index + 1).value,
                f"brake position row {excel_row}",
            )
            position = calibrate_position(source_position, position_anchors)
            row[f"brake_train_{index}_kW"] = converted
            row[f"brake_train_{index}_pos_km"] = position
            brake_power.append(converted)
        for index in range(1, 4):
            raw = numeric(power_sheet.cell(excel_row, index + 4).value, f"traction row {excel_row}")
            if raw < -1e-9:
                negative_traction_inputs.append({"time_s": time_s, "train": f"T{index}", "value": raw})
            converted = max(0.0, raw)
            source_position = numeric(
                position_sheet.cell(excel_row, index + 4).value,
                f"traction position row {excel_row}",
            )
            position = calibrate_position(source_position, position_anchors)
            row[f"traction_train_{index}_kW"] = converted
            row[f"traction_train_{index}_pos_km"] = position
            traction_power.append(converted)
        row["brake_total_kW"] = sum(brake_power)
        row["traction_total_kW"] = sum(traction_power)
        row["power_surplus_kW"] = row["brake_total_kW"] - row["traction_total_kW"]
        case_rows.append(row)

    if positive_brake_inputs or negative_traction_inputs:
        raise ValueError(
            "Unexpected power signs in the source workbook: "
            f"positive braking={len(positive_brake_inputs)}, "
            f"negative traction={len(negative_traction_inputs)}"
        )

    case_path = PREPARED_DIR / "BeijingLine5_150s_3B3T10ESS.csv"
    write_csv(case_path, case_headers, case_rows)

    ess_headers = [
        "ess_id",
        "station_label",
        "capacity_kWh",
        "initial_soc_ratio",
        "max_charge_kW",
        "max_discharge_kW",
        "position_km",
        "position_status",
        "power_limit_interpretation",
    ]
    ess_rows = []
    for row_index in range(2, 12):
        ess_rows.append(
            {
                "ess_id": str(ess_sheet.cell(row_index, 1).value),
                "station_label": str(ess_sheet.cell(row_index, 2).value),
                "capacity_kWh": engineering["ess"]["capacity_kWh"],
                "initial_soc_ratio": engineering["ess"]["initial_soc_ratio"],
                "max_charge_kW": engineering["ess"]["max_charge_kW"],
                "max_discharge_kW": engineering["ess"]["max_discharge_kW"],
                "position_km": station_chainage[str(ess_sheet.cell(row_index, 2).value)],
                "position_status": "confirmed_by_supplemental_station_chainage",
                "power_limit_interpretation": "separate corrected charge/discharge limits supplied as 500 kW",
            }
        )
    ess_path = PREPARED_DIR / "BeijingLine5_10ESS_metadata.csv"
    write_csv(ess_path, ess_headers, ess_rows)

    audit = {
        "source_workbook": str(workbook_path),
        "source_sha256": sha256(workbook_path),
        "prepared_case": str(case_path),
        "prepared_case_sha256": sha256(case_path),
        "prepared_ess_metadata": str(ess_path),
        "prepared_ess_metadata_sha256": sha256(ess_path),
        "time_axis": {"start_s": 0, "end_s": 149, "rows": 150, "step_s": 1},
        "conversion": {
            "brake_power": "source negative regeneration converted to nonnegative benchmark magnitude",
            "traction_power": "source positive traction retained",
            "positions": (
                "piecewise-linear calibration from the source reference axis to "
                "the supplied cumulative station chainage using five named route endpoints"
            ),
            "position_anchors": [
                {
                    "source_position_km": source_position,
                    "station": station,
                    "cumulative_chainage_km": station_chainage[station],
                }
                for source_position, station in POSITION_ANCHOR_STATIONS
            ],
            "ess_position_km": "joined by station label to 01_站点累计里程",
            "ess_capacity": "05_ESS配置 5.1 kWh overridden by 06_ESS参数修正 1000 kWh",
        },
        "totals": {
            "regenerative_energy_kWh": sum(row["brake_total_kW"] for row in case_rows) / 3600.0,
            "traction_energy_kWh": sum(row["traction_total_kW"] for row in case_rows) / 3600.0,
        },
    }
    audit_path = PREPARED_DIR / "input_conversion_audit.json"
    audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    return audit


def write_engineering_outputs(engineering, primary_workbook, ess_metadata_path):
    metadata_rows = list(csv.DictReader(ess_metadata_path.open("r", encoding="utf-8-sig")))
    ess_by_station = {row["station_label"]: row["ess_id"] for row in metadata_rows}
    substation_by_station = {
        row["station"]: row["substation_id"] for row in engineering["substations"]
    }
    network_rows = []
    for station in engineering["stations"]:
        coordinate = engineering["coordinates"].get(station["station"], {})
        network_rows.append(
            {
                "station_id": station["station_id"],
                "station": station["station"],
                "chainage_km": station["chainage_km"],
                "longitude": coordinate.get("longitude", ""),
                "latitude": coordinate.get("latitude", ""),
                "substation_id": substation_by_station.get(station["station"], ""),
                "supply_zone": station_zone(
                    station["station"], engineering["station_order"], engineering["zones"]
                ),
                "ess_id": ess_by_station.get(station["station"], ""),
            }
        )
    network_path = PREPARED_DIR / "BeijingLine5_station_network.csv"
    write_csv(
        network_path,
        [
            "station_id",
            "station",
            "chainage_km",
            "longitude",
            "latitude",
            "substation_id",
            "supply_zone",
            "ess_id",
        ],
        network_rows,
    )

    config = {
        "schema_version": 1,
        "case_key": "BeijingLine5_EngineeringCase",
        "sources": {
            "time_series_workbook": str(primary_workbook),
            "time_series_sha256": sha256(primary_workbook),
            "engineering_workbook": engineering["source_workbook"],
            "engineering_sha256": engineering["source_sha256"],
        },
        "simulation": {
            "duration_s": 150,
            "time_step_s": 1.0,
            "braking_trains": 3,
            "traction_trains": 3,
            "data_status": "physics-constrained reconstructed scenario; not operational SCADA",
        },
        "line": {
            **engineering["line"],
            "simulation_resistance_ohm_per_km": engineering["line"][
                "equivalent_resistance_ohm"
            ],
            "simulation_resistance_reason": (
                "retained as the common Benchmark configuration for cross-algorithm comparability"
            ),
            "component_sum_resistance_ohm_per_km": (
                engineering["line"]["rail_resistance_ohm_per_km"]
                + engineering["line"]["catenary_resistance_ohm_per_km"]
            ),
        },
        "ess": {
            **engineering["ess"],
            "soc_min_ratio": 0.2,
            "soc_max_ratio": 0.9,
            "positions_km": [float(row["position_km"]) for row in metadata_rows],
            "station_labels": [row["station_label"] for row in metadata_rows],
        },
        "network": {
            "station_count": len(engineering["stations"]),
            "traction_substation_count": len(engineering["substations"]),
            "equivalent_supply_zone_count": len(engineering["zones"]),
            "zones": [
                {key: value for key, value in zone.items() if not key.endswith("_index")}
                for zone in engineering["zones"]
            ],
        },
        "display": {
            "coordinates_complete": all(
                engineering["coordinates"].get(station["station"], {}).get("longitude", "") != ""
                and engineering["coordinates"].get(station["station"], {}).get("latitude", "") != ""
                for station in engineering["stations"]
            ),
            "coordinate_status": "not supplied; not used by the optimizer",
        },
    }
    config_path = PREPARED_DIR / "BeijingLine5_case_config.json"
    config_path.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    readiness = {
        "status": "sufficient_with_declared_boundaries",
        "algorithm_blockers": [],
        "checks": {
            "time_series_150x1s": True,
            "train_position_and_power": True,
            "station_cumulative_chainage": True,
            "traction_substations": True,
            "equivalent_supply_zones": True,
            "ess_1000kWh_500kW_correction": True,
            "common_benchmark_configuration": True,
            "coordinates_for_map": config["display"]["coordinates_complete"],
            "operational_scada": False,
        },
        "boundaries": [
            "Longitude/latitude are absent and are not used in D_ij or algorithm execution.",
            "Power profiles are physics-constrained reconstructions, not operational SCADA measurements.",
            "Lifecycle cost must be reported as a literature-normalized engineering estimate because Beijing Line 5 procurement, replacement, discount-rate, and full operating-frequency data were not supplied.",
        ],
    }
    readiness_path = PREPARED_DIR / "input_completeness_audit.json"
    readiness_path.write_text(
        json.dumps(readiness, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return network_path, config_path, readiness_path


def build_source_manifest():
    rows = []
    for copied_path in sorted(
        path
        for path in SNAPSHOT_DIR.rglob("*")
        if path.is_file()
        and "__pycache__" not in path.parts
        and path.suffix.lower() != ".pyc"
    ):
        relative = copied_path.relative_to(SNAPSHOT_DIR)
        source_path = BENCHMARK_ROOT / relative
        rows.append(
            {
                "relative_path": relative.as_posix(),
                "original_source": str(source_path),
                "copied_path": str(copied_path),
                "sha256": sha256(copied_path),
                "source_exists": source_path.exists(),
                "hash_matches_source": source_path.exists() and sha256(source_path) == sha256(copied_path),
            }
        )
    manifest_path = REUSE_ROOT / "source_manifest.csv"
    write_csv(
        manifest_path,
        [
            "relative_path",
            "original_source",
            "copied_path",
            "sha256",
            "source_exists",
            "hash_matches_source",
        ],
        rows,
    )
    return rows


def main():
    primary_workbook = unique_workbook("*最终实验输入数据集*.xlsx", "time-series input")
    engineering_workbook = unique_workbook("*案例补充工程数据表*.xlsx", "engineering supplement")
    PREPARED_DIR.mkdir(parents=True, exist_ok=True)
    engineering = load_engineering_data(engineering_workbook)
    audit = prepare_case(primary_workbook, engineering)
    network_path, config_path, readiness_path = write_engineering_outputs(
        engineering,
        primary_workbook,
        Path(audit["prepared_ess_metadata"]),
    )
    manifest = build_source_manifest()
    print(
        json.dumps(
            {
                "prepared_case": audit["prepared_case"],
                "prepared_ess_metadata": audit["prepared_ess_metadata"],
                "regenerative_energy_kWh": audit["totals"]["regenerative_energy_kWh"],
                "traction_energy_kWh": audit["totals"]["traction_energy_kWh"],
                "station_network": str(network_path),
                "case_config": str(config_path),
                "input_readiness": str(readiness_path),
                "snapshot_files": len(manifest),
                "all_snapshot_hashes_match": all(row["hash_matches_source"] for row in manifest),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
