"""Remove case-insensitive duplicate columns from a Quantum_QUBO CSV.

The preserved legacy writer emits both ``ess1_*`` and ``ESS1_*`` compatibility
aliases.  Windows/Excel importers treat those names as duplicates.  This tool
keeps the canonical uppercase columns after verifying that duplicate values
are identical on every row.
"""

import csv
from pathlib import Path
import sys


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: normalize_quantum_output.py TIME_SERIES.csv")
    path = Path(sys.argv[1]).resolve()
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.reader(stream))
    if not rows:
        raise ValueError("Quantum time-series CSV is empty")

    headers = rows[0]
    groups = {}
    for index, header in enumerate(headers):
        groups.setdefault(header.casefold(), []).append(index)
    duplicate_groups = {
        name: indices for name, indices in groups.items() if len(indices) > 1
    }
    if not duplicate_groups:
        print("PASS: no case-insensitive duplicate columns")
        return

    drop_indices = set()
    for normalized_name, indices in duplicate_groups.items():
        canonical = next(
            (index for index in indices if headers[index].startswith("ESS")),
            indices[0],
        )
        for duplicate in indices:
            if duplicate == canonical:
                continue
            for row_number, row in enumerate(rows[1:], start=2):
                if row[duplicate] != row[canonical]:
                    raise ValueError(
                        f"Duplicate columns differ at row {row_number}: "
                        f"{headers[duplicate]} vs {headers[canonical]}"
                    )
            drop_indices.add(duplicate)

    normalized_rows = [
        [value for index, value in enumerate(row) if index not in drop_indices]
        for row in rows
    ]
    temp_path = path.with_suffix(path.suffix + ".normalized.tmp")
    with temp_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerows(normalized_rows)
    temp_path.replace(path)
    print(
        f"PASS: removed {len(drop_indices)} duplicate columns; "
        f"remaining columns={len(normalized_rows[0])}, rows={len(normalized_rows) - 1}"
    )


if __name__ == "__main__":
    main()
