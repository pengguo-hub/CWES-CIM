"""Shared file-output helpers; algorithm folders remain the output owners."""

from pathlib import Path

import matplotlib.pyplot as plt
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from benchmark_config import DT, NUM_ESS

def make_output_dirs(method_dir, case_name):
    output_dir = Path(method_dir) / case_name
    excel_dir = output_dir / "excel_result"
    figure_dir = output_dir / "figure"
    text_dir = output_dir / "txt"
    for directory in (excel_dir, figure_dir, text_dir):
        directory.mkdir(parents=True, exist_ok=True)
    return output_dir, excel_dir, figure_dir, text_dir


def style_workbook(path):
    workbook = load_workbook(path)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for sheet in workbook.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")
        sheet.row_dimensions[1].height = 24
        for column_index, cells in enumerate(sheet.iter_cols(), start=1):
            maximum = max(len(str(cell.value)) if cell.value is not None else 0 for cell in cells)
            sheet.column_dimensions[get_column_letter(column_index)].width = min(max(maximum + 2, 10), 24)
            for cell in cells[1:]:
                cell.alignment = Alignment(vertical="center")
                if isinstance(cell.value, (int, float)):
                    cell.number_format = "0.000000"
        if sheet.max_column == 3 and sheet["A1"].value == "指标":
            sheet.column_dimensions["A"].width = 22
            sheet.column_dimensions["B"].width = 22
            sheet.column_dimensions["C"].width = 12
    workbook.save(path)

def save_tabular_outputs(result_df, summary_df, excel_dir, text_dir, report_title):
    time_series_path = excel_dir / "TimeSeries_Result.xlsx"
    summary_path = excel_dir / "Summary_Result.xlsx"
    result_df.to_excel(time_series_path, index=False)
    summary_df.to_excel(summary_path, index=False)
    style_workbook(time_series_path)
    style_workbook(summary_path)
    summary_df.to_csv(excel_dir / "Summary_Result.csv", index=False, encoding="utf-8-sig")
    with open(text_dir / "Result_Report.txt", "w", encoding="utf-8") as report:
        report.write(report_title + "\n")
        report.write("=" * 60 + "\n\n")
        for _, row in summary_df.iterrows():
            report.write(f"{row['指标']}: {row['数值']} {row['单位']}\n")


def plot_standard_results(result_df, figure_dir, prefix="", voltage_column=None):
    stem = f"{prefix}_" if prefix else ""
    plt.figure(figsize=(10, 5))
    for i in range(1, NUM_ESS + 1):
        plt.plot(result_df["time_s"], result_df[f"ESS{i}_soc_percent"], linewidth=0.9, alpha=0.75)
    plt.plot(result_df["time_s"], result_df["soc_average"] * 100.0, color="black", linewidth=2.0, label="Average")
    plt.xlabel("Time (s)")
    plt.ylabel("SOC (%)")
    plt.title(f"{prefix or 'ESS'} SOC")
    plt.grid(True)
    plt.legend()
    plt.savefig(figure_dir / f"{stem}SOC.png", dpi=300, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(10, 5))
    plt.plot(result_df["time_s"], result_df["brake_power_kW"], label="Brake")
    plt.plot(result_df["time_s"], result_df["traction_power_kW"], label="Traction")
    plt.plot(result_df["time_s"], result_df["ess_charge_kW"], label="ESS charge")
    plt.plot(result_df["time_s"], result_df["ess_discharge_kW"], label="ESS discharge")
    plt.plot(result_df["time_s"], result_df["grid_power_kW"], label="Grid")
    plt.xlabel("Time (s)")
    plt.ylabel("Power (kW)")
    plt.title(f"{prefix or 'ESS'} Power Dispatch")
    plt.legend(ncol=2)
    plt.grid(True)
    plt.savefig(figure_dir / f"{stem}Power_Dispatch.png", dpi=300, bbox_inches="tight")
    plt.close()

    cumulative_regen = result_df["brake_power_kW"].cumsum() * DT / 3600.0
    cumulative_used = (
        result_df["p_direct_kW"] + result_df["ess_charge_kW"] - result_df["loss_kW"]
    ).clip(lower=0).cumsum() * DT / 3600.0
    cumulative_waste = result_df["wasted_power_kW"].cumsum() * DT / 3600.0
    cumulative_grid = result_df["grid_power_kW"].cumsum() * DT / 3600.0
    plt.figure(figsize=(10, 5))
    plt.plot(result_df["time_s"], cumulative_regen, label="Regenerative")
    plt.plot(result_df["time_s"], cumulative_used, label="Effective absorption")
    plt.plot(result_df["time_s"], cumulative_waste, label="Wasted")
    plt.plot(result_df["time_s"], cumulative_grid, label="Grid")
    plt.xlabel("Time (s)")
    plt.ylabel("Energy (kWh)")
    plt.title(f"{prefix or 'ESS'} Cumulative Energy")
    plt.legend()
    plt.grid(True)
    plt.savefig(figure_dir / f"{stem}Cumulative_Energy.png", dpi=300, bbox_inches="tight")
    plt.close()

    totals = [
        cumulative_used.iloc[-1],
        cumulative_waste.iloc[-1],
        cumulative_grid.iloc[-1],
        result_df["loss_kW"].sum() * DT / 3600.0,
    ]
    plt.figure(figsize=(8, 5))
    plt.bar(["Absorbed", "Wasted", "Grid", "Loss"], totals)
    plt.ylabel("Energy (kWh)")
    plt.title(f"{prefix or 'ESS'} Energy Composition")
    plt.grid(axis="y")
    plt.savefig(figure_dir / f"{stem}Energy_Composition.png", dpi=300, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(9, 5))
    plt.plot(result_df["time_s"], result_df["solve_time_ms"])
    plt.xlabel("Time (s)")
    plt.ylabel("Solve time (ms)")
    plt.title(f"{prefix or 'ESS'} Solve Time")
    plt.grid(True)
    plt.savefig(figure_dir / f"{stem}Solve_Time.png", dpi=300, bbox_inches="tight")
    plt.close()

    if voltage_column and voltage_column in result_df:
        plt.figure(figsize=(9, 5))
        plt.plot(result_df["time_s"], result_df[voltage_column])
        plt.xlabel("Time (s)")
        plt.ylabel("Voltage (V)")
        plt.title(f"{prefix or 'ESS'} Estimated DC Voltage")
        plt.grid(True)
        plt.savefig(figure_dir / f"{stem}Estimated_DC_Voltage.png", dpi=300, bbox_inches="tight")
        plt.close()
