

from copy import deepcopy

from benchmark_config import (
    DC_VOLTAGE, DC_VOLTAGE_MIN, DT, ESS_CAPACITY_KWH, ESS_POSITIONS,
    ETA_CH, ETA_DIS, LINE_RESISTANCE, NUM_ESS, P_CH_MAX_KW,
    P_DIS_MAX_KW, P_SUB_MAX_KW, SOC_MAX, SOC_MIN,
)

from line_loss import calculate_line_loss


def charge_limits(soc_list):
    limits = []
    for soc in soc_list:
        energy_room = max(0.0, (SOC_MAX - soc) * ESS_CAPACITY_KWH)
        limits.append(min(P_CH_MAX_KW, energy_room * 3600.0 / (ETA_CH * DT)))
    return limits


def discharge_limits(soc_list):
    limits = []
    for soc in soc_list:
        available = max(0.0, (soc - SOC_MIN) * ESS_CAPACITY_KWH)
        limits.append(min(P_DIS_MAX_KW, available * ETA_DIS * 3600.0 / DT))
    return limits


def location_scores(ess_positions, train_positions, train_powers):
    active = [(position, power) for position, power in zip(train_positions, train_powers) if power > 0]
    if not active:
        return [1.0] * len(ess_positions)
    return [
        sum(power / (1.0 + abs(position - train_position)) for train_position, power in active)
        for position in ess_positions
    ]


def allocate_power(total, limits, scores=None):
    total = max(0.0, min(float(total), sum(max(0.0, value) for value in limits)))
    result = [0.0] * len(limits)
    active = {i for i, limit in enumerate(limits) if limit > 1e-12}
    scores = [1.0] * len(limits) if scores is None else [max(0.0, float(v)) for v in scores]
    remaining = total
    while active and remaining > 1e-9:
        weight_sum = sum(scores[i] for i in active)
        if weight_sum <= 1e-12:
            weights = {i: 1.0 / len(active) for i in active}
        else:
            weights = {i: scores[i] / weight_sum for i in active}
        saturated = []
        distributed = 0.0
        for i in active:
            room = limits[i] - result[i]
            addition = min(room, remaining * weights[i])
            result[i] += addition
            distributed += addition
            if room - addition <= 1e-9:
                saturated.append(i)
        remaining -= distributed
        active.difference_update(saturated)
        if distributed <= 1e-12:
            break
    return result


def update_soc(soc_list, charge_kw, discharge_kw):
    next_soc = []
    for soc, charge, discharge in zip(soc_list, charge_kw, discharge_kw):
        delta = (
            ETA_CH * charge * DT / 3600.0
            - discharge * DT / (ETA_DIS * 3600.0)
        ) / ESS_CAPACITY_KWH
        next_soc.append(min(SOC_MAX, max(SOC_MIN, soc + delta)))
    return next_soc


def _voltage_safe_power_limit(distance_km):
    resistance = LINE_RESISTANCE * distance_km
    if resistance <= 1e-12:
        return float("inf")
    return (DC_VOLTAGE - DC_VOLTAGE_MIN) * DC_VOLTAGE / (1000.0 * resistance)


def _greedy_allocate(sources, sinks, flow_type):
    sources = deepcopy(sources)
    sinks = deepcopy(sinks)
    flows = []
    pairs = sorted(
        ((abs(source["pos"] - sink["pos"]), i, j)
         for i, source in enumerate(sources)
         for j, sink in enumerate(sinks)),
        key=lambda item: item[0],
    )
    for distance, i, j in pairs:
        power = min(
            sources[i]["remaining"],
            sinks[j]["remaining"],
            _voltage_safe_power_limit(distance),
        )
        if power <= 1e-9:
            continue
        flows.append({
            "from": sources[i]["id"], "to": sinks[j]["id"],
            "from_pos": sources[i]["pos"], "to_pos": sinks[j]["pos"],
            "power_kW": power, "type": flow_type,
        })
        sources[i]["remaining"] -= power
        sinks[j]["remaining"] -= power
    return flows, sources, sinks


def build_power_flows(input_t, charge_kw, discharge_kw):
    brake = [
        {"id": f"B{i + 1}", "pos": input_t["brake_position"][i], "remaining": input_t["brake_power"][i]}
        for i in range(len(input_t["brake_power"]))
    ]
    traction = [
        {"id": f"T{i + 1}", "pos": input_t["traction_position"][i], "remaining": input_t["traction_power"][i]}
        for i in range(len(input_t["traction_power"]))
    ]
    direct, remaining_brake, remaining_traction = _greedy_allocate(brake, traction, "brake_to_traction")
    charge_sinks = [
        {"id": f"ESS{i + 1}", "pos": ESS_POSITIONS[i], "remaining": charge_kw[i]}
        for i in range(NUM_ESS)
    ]
    charge_flows, _, _ = _greedy_allocate(remaining_brake, charge_sinks, "brake_to_storage")
    discharge_sources = [
        {"id": f"ESS{i + 1}", "pos": ESS_POSITIONS[i], "remaining": discharge_kw[i]}
        for i in range(NUM_ESS)
    ]
    discharge_flows, _, _ = _greedy_allocate(discharge_sources, remaining_traction, "storage_to_traction")
    actual_charge = [0.0] * NUM_ESS
    actual_discharge = [0.0] * NUM_ESS
    for flow in charge_flows:
        actual_charge[int(flow["to"][3:]) - 1] += flow["power_kW"]
    for flow in discharge_flows:
        actual_discharge[int(flow["from"][3:]) - 1] += flow["power_kW"]
    return direct + charge_flows + discharge_flows, actual_charge, actual_discharge


def calculate_flow_metrics(flows):
    total_loss = 0.0
    min_voltage = DC_VOLTAGE
    for flow in flows:
        distance = abs(flow["from_pos"] - flow["to_pos"])

        flow["loss_kW"] = calculate_line_loss(
            power_kW=flow["power_kW"],
            distance_km=distance,
        )

        # ↓↓↓下面保持原样↓↓↓

        resistance = LINE_RESISTANCE * distance
        current = flow["power_kW"] * 1000.0 / DC_VOLTAGE
        flow["receiving_voltage_V"] = DC_VOLTAGE - current * resistance
        total_loss += flow["loss_kW"]
        min_voltage = min(min_voltage, flow["receiving_voltage_V"])
    return total_loss, min_voltage


def finalize_step(input_t, charge_kw, discharge_kw, solve_time_ms, extras=None):
    if len(charge_kw) != NUM_ESS or len(discharge_kw) != NUM_ESS:
        raise ValueError(f"dispatch must contain {NUM_ESS} charge and discharge values")

    ch_limits = charge_limits(input_t["soc"])
    dis_limits = discharge_limits(input_t["soc"])
    requested_violation = any(
        charge_kw[i] < -1e-9 or discharge_kw[i] < -1e-9
        or charge_kw[i] > ch_limits[i] + 1e-6
        or discharge_kw[i] > dis_limits[i] + 1e-6
        or (charge_kw[i] > 1e-9 and discharge_kw[i] > 1e-9)
        for i in range(NUM_ESS)
    )
    charge_kw = [min(max(0.0, charge_kw[i]), ch_limits[i]) for i in range(NUM_ESS)]
    discharge_kw = [min(max(0.0, discharge_kw[i]), dis_limits[i]) for i in range(NUM_ESS)]

    brake_power = sum(input_t["brake_power"])
    traction_power = sum(input_t["traction_power"])
    surplus = max(0.0, brake_power - traction_power)
    deficit = max(0.0, traction_power - brake_power)
    charge_kw = allocate_power(min(sum(charge_kw), surplus), charge_kw)
    discharge_kw = allocate_power(min(sum(discharge_kw), deficit), discharge_kw)

    flows, charge_kw, discharge_kw = build_power_flows(input_t, charge_kw, discharge_kw)
    loss_kw, min_voltage = calculate_flow_metrics(flows)
    total_charge = sum(charge_kw)
    total_discharge = sum(discharge_kw)
    balance_without_grid_waste = (
        brake_power + total_discharge - traction_power - total_charge - loss_kw
    )
    wasted_power = max(0.0, balance_without_grid_waste)
    grid_power = max(0.0, -balance_without_grid_waste)
    next_soc = update_soc(input_t["soc"], charge_kw, discharge_kw)

    voltage_violation = min_voltage < DC_VOLTAGE_MIN - 1e-6
    power_violation = requested_violation or grid_power > P_SUB_MAX_KW + 1e-9
    feasible = not voltage_violation and not power_violation
    p_direct = sum(flow["power_kW"] for flow in flows if flow["type"] == "brake_to_traction")
    used_regen = max(0.0, p_direct + total_charge - loss_kw)
    result = {
        "time_s": input_t["time"],
        "brake_power_kW": brake_power,
        "traction_power_kW": traction_power,
        "power_surplus_kW": brake_power - traction_power,
        "p_direct_kW": p_direct,
        "ess_charge_kW": total_charge,
        "ess_discharge_kW": total_discharge,
        "grid_power_kW": grid_power,
        "wasted_power_kW": wasted_power,
        "loss_kW": loss_kw,
        "absorbed_brake_power_kW": used_regen,
        "absorption_rate_percent": used_regen / brake_power * 100.0 if brake_power > 0 else 0.0,
        "soc_average": sum(next_soc) / NUM_ESS,
        "solve_time_ms": float(solve_time_ms),
        "min_voltage_V": min_voltage,
        "voltage_violation": voltage_violation,
        "power_violation": power_violation,
        "feasible": feasible,
        "power_balance_error_kW": (
            brake_power + grid_power + total_discharge
            - traction_power - total_charge - loss_kw - wasted_power
        ),
    }
    for i in range(NUM_ESS):
        result[f"ESS{i + 1}_charge_kW"] = charge_kw[i]
        result[f"ESS{i + 1}_discharge_kW"] = discharge_kw[i]
        result[f"ESS{i + 1}_soc_percent"] = next_soc[i] * 100.0
    if extras:
        result.update(extras)
    return result, next_soc, flows
