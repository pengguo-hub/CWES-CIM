"""Memory-efficient numeric QUBO construction for batched 10ESS solving."""

import os
import re

from queue import Empty, Queue
from threading import Thread
from time import perf_counter

import kaiwu as kw
import numpy as np
from pyscipopt import Model, quicksum


class QuboAccumulator:
    """Accumulate an upper-triangular QUBO matrix and its constant offset."""

    def __init__(self, variable_count):
        self.matrix = np.zeros((variable_count, variable_count), dtype=float)
        self.offset = 0.0

    def add_affine(self, constant, coefficients, weight=1.0):
        self.offset += float(weight) * float(constant)
        for index, coefficient in coefficients.items():
            self.matrix[index, index] += float(weight) * float(coefficient)

    def add_square(self, constant, coefficients, weight=1.0):
        weight = float(weight)
        constant = float(constant)
        terms = sorted(
            (int(index), float(coefficient))
            for index, coefficient in coefficients.items()
            if abs(float(coefficient)) > 0.0
        )

        self.offset += weight * constant * constant

        for position, (index_i, coefficient_i) in enumerate(terms):
            self.matrix[index_i, index_i] += weight * (
                coefficient_i * coefficient_i
                + 2.0 * constant * coefficient_i
            )
            for index_j, coefficient_j in terms[position + 1:]:
                self.matrix[index_i, index_j] += (
                    2.0 * weight * coefficient_i * coefficient_j
                )


def _add_coefficient(coefficients, index, value):
    coefficients[index] = coefficients.get(index, 0.0) + float(value)


def _variable_index(step_index, ess_index, ess_count):
    return step_index * ess_count + ess_index


def build_numeric_batch_qubo(
    case_df,
    config,
    config_factory,
    update_config,
    graph_builder,
    penalty_fn,
):
    """Build the same batched objective directly as a numeric QUBO matrix."""

    total_steps = len(case_df)
    ess_count = config.ess_count
    variable_count = total_steps * ess_count
    accumulator = QuboAccumulator(variable_count)
    step_configs = []
    step_graphs = []

    batch_initial_soc = np.asarray(config.SOC_ess, dtype=float).copy()
    cumulative_soc_constants = batch_initial_soc.copy()
    cumulative_soc_coefficients = [dict() for _ in range(ess_count)]

    build_start = perf_counter()
    print(
        f"  [构建] 直接生成 {variable_count} 变量的数值QUBO矩阵...",
        flush=True,
    )

    for step_index, (_, row) in enumerate(case_df.iterrows()):
        step_config = config_factory()
        step_config.SOC_ess = batch_initial_soc.copy()
        step_config.soc_initialized = True
        update_config(step_config, row)
        graph = graph_builder(step_config)

        step_configs.append(step_config)
        step_graphs.append(graph)

        ess_nodes = [
            node
            for node, node_type in enumerate(step_config.node_types)
            if node_type == 2
        ]
        ess_index_by_node = {
            node: ess_index
            for ess_index, node in enumerate(ess_nodes)
        }

        def node_reference(node):
            node_type = int(step_config.node_types[node])
            if node_type == 0:
                return 1.0, None
            if node_type == 1:
                return 0.0, None
            ess_index = ess_index_by_node[node]
            return 0.0, _variable_index(
                step_index,
                ess_index,
                ess_count,
            )

        # Max-Cut objective: -weight * (x_u - x_v)^2.
        for node_u, node_v, data in graph.edges(data=True):
            constant_u, index_u = node_reference(node_u)
            constant_v, index_v = node_reference(node_v)
            coefficients = {}
            if index_u is not None:
                _add_coefficient(coefficients, index_u, 1.0)
            if index_v is not None:
                _add_coefficient(coefficients, index_v, -1.0)
            accumulator.add_square(
                constant_u - constant_v,
                coefficients,
                -round(float(data["weight"]), config.qubo_round_digits),
            )

        brake_power = sum(max(float(power), 0.0) for power in step_config.P)
        traction_power = sum(
            abs(min(float(power), 0.0))
            for power in step_config.P
        )

        # Power-balance penalty.
        balance_constant = brake_power - traction_power
        balance_coefficients = {}
        for ess_index in range(ess_count):
            index = _variable_index(step_index, ess_index, ess_count)
            charge_power = round(
                float(step_config.P_s_max_ch[ess_index]),
                config.qubo_round_digits,
            )
            discharge_power = round(
                float(step_config.P_s_max_dis[ess_index]),
                config.qubo_round_digits,
            )
            balance_constant -= charge_power
            balance_coefficients[index] = charge_power + discharge_power

        accumulator.add_square(
            balance_constant,
            balance_coefficients,
            round(float(penalty_fn(step_config)), config.qubo_round_digits),
        )

        # Substation capacity penalty.
        substation_constant = (
            traction_power
            - brake_power
            - float(config.substation_max_power_kW)
        )
        substation_coefficients = {}
        for ess_index in range(ess_count):
            index = _variable_index(step_index, ess_index, ess_count)
            charge_power = round(
                float(step_config.P_s_max_ch[ess_index]),
                config.qubo_round_digits,
            )
            discharge_power = round(
                float(step_config.P_s_max_dis[ess_index]),
                config.qubo_round_digits,
            )
            substation_constant += charge_power
            substation_coefficients[index] = -(
                charge_power + discharge_power
            )

        accumulator.add_square(
            substation_constant,
            substation_coefficients,
            config.lambda_substation,
        )

        # SOC dynamics and SOC boundary direction penalties.
        for ess_index in range(ess_count):
            index = _variable_index(step_index, ess_index, ess_count)
            charge_power = float(step_config.P_s_max_ch[ess_index])
            discharge_power = float(step_config.P_s_max_dis[ess_index])
            capacity = float(step_config.ess_capacity_kWh[ess_index])

            delta_soc_charge = (
                charge_power
                * config.dt
                / 3600.0
                * config.eta_c
                / capacity
            )
            delta_soc_discharge = (
                discharge_power
                * config.dt
                / 3600.0
                / config.eta_d
                / capacity
            )

            cumulative_soc_constants[ess_index] += delta_soc_charge
            _add_coefficient(
                cumulative_soc_coefficients[ess_index],
                index,
                -(delta_soc_charge + delta_soc_discharge),
            )
            accumulator.add_square(
                cumulative_soc_constants[ess_index] - config.soc_target,
                cumulative_soc_coefficients[ess_index],
                config.lambda_soc_dynamic,
            )

            current_soc = float(batch_initial_soc[ess_index])
            high_risk = max(
                0.0,
                (current_soc - 0.80)
                / max(config.SOC_max - 0.80, 1e-9),
            )
            low_risk = max(
                0.0,
                (0.30 - current_soc)
                / max(0.30 - config.SOC_min, 1e-9),
            )
            accumulator.add_affine(
                high_risk,
                {index: low_risk - high_risk},
                config.lambda_soc_boundary,
            )

        # Distance-power loss surrogate.
        brake_nodes = [
            node
            for node, node_type in enumerate(step_config.node_types)
            if node_type == 0
        ]
        traction_nodes = [
            node
            for node, node_type in enumerate(step_config.node_types)
            if node_type == 1
        ]

        for ess_node in ess_nodes:
            ess_index = ess_index_by_node[ess_node]
            index = _variable_index(step_index, ess_index, ess_count)
            average_brake_distance = (
                float(np.mean([
                    step_config.distance_matrix[node][ess_node]
                    for node in brake_nodes
                ]))
                if brake_nodes
                else 0.0
            )
            average_traction_distance = (
                float(np.mean([
                    step_config.distance_matrix[node][ess_node]
                    for node in traction_nodes
                ]))
                if traction_nodes
                else 0.0
            )
            loss_scale = 1000.0 / (config.V0 * 1000.0) ** 2
            charge_loss = (
                loss_scale * config.Z_unit
                * average_brake_distance
                * float(step_config.P_s_max_ch[ess_index]) ** 2
            )
            discharge_loss = (
                loss_scale * config.Z_unit
                * average_traction_distance
                * float(step_config.P_s_max_dis[ess_index]) ** 2
            )
            accumulator.add_affine(
                charge_loss,
                {index: discharge_loss - charge_loss},
                config.lambda_loss_qubo,
            )

        # Braking-waste and grid-supply surrogate penalties.
        braking_surplus = max(brake_power - traction_power, 0.0)
        traction_deficit = max(traction_power - brake_power, 0.0)
        waste_constant = braking_surplus
        waste_coefficients = {}
        grid_coefficients = {}

        for ess_index in range(ess_count):
            index = _variable_index(step_index, ess_index, ess_count)
            charge_power = float(step_config.P_s_max_ch[ess_index])
            discharge_power = float(step_config.P_s_max_dis[ess_index])
            waste_constant -= charge_power
            waste_coefficients[index] = charge_power
            grid_coefficients[index] = -discharge_power

        accumulator.add_square(
            waste_constant,
            waste_coefficients,
            config.lambda_waste_qubo,
        )
        accumulator.add_square(
            traction_deficit,
            grid_coefficients,
            config.lambda_grid_qubo,
        )

        # Reward useful discharge explicitly. Distance efficiency ensures that
        # equal-power solutions prefer storage closer to active traction load.
        if (
            traction_deficit > 1e-12
            and config.lambda_discharge_reward_qubo > 0.0
        ):
            total_discharge_capacity = sum(
                float(step_config.P_s_max_dis[ess_index])
                for ess_index in range(ess_count)
            )
            demand_fraction = min(
                1.0,
                traction_deficit / max(total_discharge_capacity, 1e-12),
            )
            for ess_node in ess_nodes:
                ess_index = ess_index_by_node[ess_node]
                index = _variable_index(step_index, ess_index, ess_count)
                nearest_distance = min(
                    (
                        float(step_config.distance_matrix[node][ess_node])
                        for node in traction_nodes
                    ),
                    default=0.0,
                )
                distance_efficiency = 1.0 / (
                    1.0 + step_config.gamma * step_config.Z_unit * nearest_distance
                )
                discharge_reward = (
                    demand_fraction
                    * float(step_config.P_s_max_dis[ess_index])
                    * distance_efficiency
                )
                accumulator.add_affine(
                    0.0,
                    {index: -discharge_reward},
                    config.lambda_discharge_reward_qubo,
                )

        # Adjacent-step ESS mode-switch penalty.
        if step_index > 0 and config.lambda_switch > 0:
            for ess_index in range(ess_count):
                current_index = _variable_index(
                    step_index,
                    ess_index,
                    ess_count,
                )
                previous_index = _variable_index(
                    step_index - 1,
                    ess_index,
                    ess_count,
                )
                accumulator.add_square(
                    0.0,
                    {current_index: 1.0, previous_index: -1.0},
                    config.lambda_switch,
                )

        print(
            f"  [构建] 已完成时间步 {step_index + 1}/{total_steps}",
            flush=True,
        )

    print(
        f"  [矩阵] QUBO已生成，共 {variable_count} 个变量，"
        f"耗时 {perf_counter() - build_start:.2f} s，"
        f"非零系数 {np.count_nonzero(accumulator.matrix)}",
        flush=True,
    )

    return (
        accumulator.matrix,
        accumulator.offset,
        step_configs,
        step_graphs,
    )


def extract_binary_solution(solution_dict, variable_count):
    indexed_values = {}

    for name, value in solution_dict.items():
        match = re.fullmatch(r"b+\[(\d+)\]", str(name))
        if match:
            index = int(match.group(1))
            indexed_values[index] = int(round(float(value)))

    missing = [
        index
        for index in range(variable_count)
        if index not in indexed_values
    ]
    if missing:
        available = list(solution_dict.keys())[:10]
        raise KeyError(
            f"CIM result is missing QUBO indexes {missing[:10]}; "
            f"available keys start with {available}"
        )

    return np.asarray(
        [indexed_values[index] for index in range(variable_count)],
        dtype=int,
    )


def solve_qubo_with_heartbeat(solver, qubo_model, heartbeat_seconds=15):
    """Run the blocking SDK call in a daemon thread and show wait heartbeats."""

    result_queue = Queue(maxsize=1)

    def worker():
        try:
            result_queue.put(("result", solver.solve_qubo(qubo_model)))
        except BaseException as error:
            result_queue.put(("error", error))

    Thread(target=worker, daemon=True).start()
    wait_start = perf_counter()

    long_wait_notice_shown = False

    while True:
        try:
            status, payload = result_queue.get(timeout=heartbeat_seconds)
        except Empty:
            elapsed = perf_counter() - wait_start
            print(
                f"  [求解] 已等待 {elapsed:.0f} s，本地精度适配或远程任务仍在进行...",
                flush=True,
            )
            if elapsed >= 300 and not long_wait_notice_shown:
                print(
                    "  [求解] 已超过5分钟；可继续等待，Ctrl+C只会停止本地等待。",
                    flush=True,
                )
                long_wait_notice_shown = True
            continue
        except KeyboardInterrupt:
            print(
                "\n  [求解] 已停止本地等待；若已出现[上传]，远程任务可能仍在运行。"
                "使用相同配置重跑会查询同一任务。",
                flush=True,
            )
            raise

        if status == "error":
            raise payload
        return payload

class FixedBitIsingOptimizer(kw.core.OptimizerBase):
    """Quantize Ising coefficients without splitting or adding variables."""

    def __init__(self, component, bit_width=8):
        super().__init__()
        self.component = component
        self.bit_width = int(bit_width)

    def solve(self, ising_matrix=None):
        original_matrix = np.asarray(ising_matrix, dtype=float)
        quantized_matrix = kw.ising.adjust_ising_matrix_precision(
            original_matrix,
            bit_width=self.bit_width,
        )
        original_nonzero = int(np.count_nonzero(original_matrix))
        quantized_nonzero = int(np.count_nonzero(quantized_matrix))
        preserved_percent = (
            quantized_nonzero / original_nonzero * 100.0
            if original_nonzero
            else 100.0
        )
        bit_info = kw.ising.calculate_ising_matrix_bit_width(
            quantized_matrix,
            bit_width=self.bit_width,
        )
        print(
            f"  [量化] 固定{self.bit_width}位，不拆分变量；"
            f"矩阵保持 {quantized_matrix.shape[0]}×{quantized_matrix.shape[1]}",
            flush=True,
        )
        print(
            f"  [量化] 非零系数 {original_nonzero}→{quantized_nonzero} "
            f"({preserved_percent:.1f}%)；精度信息 {bit_info}",
            flush=True,
        )
        return self.component.solve(quantized_matrix)

class SubmissionLoggingOptimizer(kw.core.OptimizerBase):
    """Log the exact moment preprocessing calls the real CIM optimizer."""

    def __init__(self, component, task_name):
        super().__init__()
        self.component = component
        self.task_name = task_name
        self.created_at = perf_counter()

    def solve(self, ising_matrix=None):
        matrix = np.asarray(ising_matrix)
        print(
            f"  [上传] 本地精度适配完成，耗时 "
            f"{perf_counter() - self.created_at:.2f} s；"
            f"实际Ising矩阵 {matrix.shape[0]}×{matrix.shape[1]}",
            flush=True,
        )
        print(
            f"  [上传] 正在调用CIM平台，任务名：{self.task_name}",
            flush=True,
        )
        return self.component.solve(ising_matrix)

def _solve_qubo_with_scip(qubo_matrix):
    """Solve an upper-triangular QUBO exactly via MILP linearization."""
    variable_count = int(qubo_matrix.shape[0])
    model = Model("Batch_QUBO_SCIP")
    model.hideOutput()
    model.setRealParam(
        "limits/time",
        float(os.environ.get("ESS_QUBO_SCIP_TIME_LIMIT_S", "30")),
    )
    model.setRealParam("limits/gap", 0.0)
    binary = [model.addVar(name=f"z_{i}", vtype="B") for i in range(variable_count)]
    objective_terms = [
        float(qubo_matrix[i, i]) * binary[i]
        for i in range(variable_count)
        if abs(float(qubo_matrix[i, i])) > 1e-12
    ]
    product_count = 0
    for i in range(variable_count):
        for j in range(i + 1, variable_count):
            coefficient = float(qubo_matrix[i, j])
            if abs(coefficient) <= 1e-12:
                continue
            product = model.addVar(name=f"zz_{i}_{j}", vtype="B")
            model.addCons(product <= binary[i])
            model.addCons(product <= binary[j])
            model.addCons(product >= binary[i] + binary[j] - 1)
            objective_terms.append(coefficient * product)
            product_count += 1
    model.setObjective(quicksum(objective_terms), "minimize")
    print(
        f"  [QUBO-SCIP] {variable_count} binaries, "
        f"{product_count} products; solving locally...",
        flush=True,
    )
    solve_start = perf_counter()
    model.optimize()
    solve_time = perf_counter() - solve_start
    status = str(model.getStatus())
    if model.getNSols() == 0:
        raise RuntimeError(f"Local QUBO SCIP solve has no solution: {status}")
    solution = model.getBestSol()
    values = np.asarray(
        [int(round(model.getSolVal(solution, variable))) for variable in binary],
        dtype=int,
    )
    gap = float(model.getGap())
    print(
        f"  [QUBO-SCIP] status={status}, gap={gap:.3e}, "
        f"nodes={model.getNNodes()}, time={solve_time:.3f} s",
        flush=True,
    )
    return {
        "values": values,
        "objective": float(model.getSolObjVal(solution)),
        "solve_time_s": solve_time,
        "status": status,
        "gap": gap,
        "nodes": int(model.getNNodes()),
    }


def solve_numeric_batch_qubo(
    case_df,
    config,
    config_factory,
    update_config,
    graph_builder,
    penalty_fn,
    task_name,
):
    total_steps = len(case_df)
    ess_count = config.ess_count
    variable_count = total_steps * ess_count

    (
        qubo_matrix,
        objective_offset,
        step_configs,
        step_graphs,
    ) = build_numeric_batch_qubo(
        case_df,
        config,
        config_factory,
        update_config,
        graph_builder,
        penalty_fn,
    )

    config.qubo_var_count = variable_count
    backend = os.environ.get("ESS_QUANTUM_SOLVER_BACKEND", "cim").strip().lower()
    if backend == "scip":
        local_result = _solve_qubo_with_scip(qubo_matrix)
        z_values = local_result["values"].reshape(total_steps, ess_count)
        return {
            "z_values": z_values,
            "qubo_value": local_result["objective"] + float(objective_offset),
            "cim_call_time_s": local_result["solve_time_s"],
            "qubo_variable_count": variable_count,
            "step_configs": step_configs,
            "step_graphs": step_graphs,
            "solver_backend": "QUBO_SCIP",
            "solver_status": local_result["status"],
            "solver_gap": local_result["gap"],
            "solver_nodes": local_result["nodes"],
        }
    if backend != "cim":
        raise ValueError(f"Unsupported QUBO backend: {backend}")

    qubo_model = kw.qubo.qubo_matrix_to_qubo_model(qubo_matrix)
    kw.common.CheckpointManager.save_dir = "/tmp"

    try:
        kw.common.set_log_level("INFO")
        print(f"  [CIM] 任务名：{task_name}", flush=True)
        cim_optimizer = kw.cim.CIMOptimizer(
            task_name=task_name,
            wait=True,
        )
        submission_optimizer = SubmissionLoggingOptimizer(
            cim_optimizer,
            task_name,
        )
        optimizer = FixedBitIsingOptimizer(
            submission_optimizer,
            bit_width=config.cim_bit_width,
        )
        solver = kw.solver.SimpleSolver(optimizer)

        print(
            f"  [预处理] 开始固定{config.cim_bit_width}位量化（不拆分变量）",
            flush=True,
        )
        solver_start = perf_counter()
        solution_dict, qubo_value = solve_qubo_with_heartbeat(
            solver,
            qubo_model,
        )
        cim_call_time = perf_counter() - solver_start
        print(
            f"  [CIM] 已返回结果，等待耗时 {cim_call_time:.2f} s",
            flush=True,
        )
    finally:
        kw.common.CheckpointManager.save_dir = None

    z_values = extract_binary_solution(
        solution_dict,
        variable_count,
    ).reshape(total_steps, ess_count)

    return {
        "z_values": z_values,
        "qubo_value": float(qubo_value) + float(objective_offset),
        "cim_call_time_s": cim_call_time,
        "qubo_variable_count": variable_count,
        "step_configs": step_configs,
        "step_graphs": step_graphs,
        "solver_backend": "CIM",
        "solver_status": "completed",
        "solver_gap": float("nan"),
        "solver_nodes": float("nan"),
    }