param(
    [ValidateSet('check','smoke','classical','benchmark-cim','benchmark-scip','penalty-scip','scale-cim','scale-scip','engineering-classical','engineering-cim','engineering-analyze','verify')]
    [string]$Mode = 'check',
    [ValidateSet('classical','quantum')]
    [string]$Profile = 'classical',
    [ValidateSet('Case1','Case2','Case3','Case4')]
    [string]$Case,
    [ValidateSet('classic','quantum','all','collect')]
    [string]$ScaleScope = 'quantum',
    [switch]$Force,
    [switch]$ConfirmPlatform
)

$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPython = Join-Path $PackageRoot '.venv\Scripts\python.exe'
$Python = if (Test-Path -LiteralPath $VenvPython) { $VenvPython } else { 'python' }
$Arguments = @('-B', (Join-Path $PackageRoot 'reproduce.py'), $Mode, '--profile', $Profile, '--scale-scope', $ScaleScope)
if ($Case) { $Arguments += @('--case', $Case) }
if ($Force) { $Arguments += '--force' }
if ($ConfirmPlatform) { $Arguments += '--confirm-platform' }

& $Python @Arguments
exit $LASTEXITCODE
