import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path

# Figure 5 data: reported experiment outputs
runs = ['S1', 'S2', 'S3']
regen = 30.0139
rates = np.array([41.8157, 80.2960, 88.4299])
absorbed = regen * rates / 100
wasted = np.array([3.6156, 0.0, 0.0])
loss = np.array([2.8885, 4.8680, 3.4726])

plt.rcParams.update({
    'font.family': 'DejaVu Serif',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
})

blue, orange, green = '#2C7894', '#DD914F', '#7A8E87'
grid = '#E4EBF0'
fig, (ax1, ax2) = plt.subplots(
    1, 2, figsize=(13.4, 5.3),
    gridspec_kw={'width_ratios': [1.28, 0.85]}
)
fig.subplots_adjust(left=.055, right=.975, top=.94, bottom=.28, wspace=.21)

# Left: independent metrics
y = np.arange(3)
offset, bar_h = .23, .18
for vals, off, color, label in [
    (absorbed, -offset, blue, 'Absorbed'),
    (wasted, 0, orange, 'Discarded'),
    (loss, offset, green, 'Network loss'),
]:
    ax1.barh(y + off, vals, height=bar_h, color=color, label=label, zorder=3)
    for i, value in enumerate(vals):
        value_label = ('0' if value == 0 else (f'{value:.4f}' if value < .1 else f'{value:.2f}'))
        ax1.text(max(value, 0) + .43, y[i] + off, value_label,
                 va='center', ha='left', color=color, fontsize=10)

ax1.invert_yaxis()
ax1.set_yticks(y, runs)
ax1.set_xlim(0, 35.8)
ax1.set_xticks(np.arange(0, 36, 5))
ax1.axvline(regen, color='#90A3B5', lw=1.3, ls=(0, (5, 4)), zorder=2)
ax1.text(regen, 1.055, f'Input: {regen:.4f} kWh',
         transform=ax1.get_xaxis_transform(),
         ha='center', va='bottom',
         color='#6E8299', fontsize=9, zorder=6, clip_on=False)

# Right: regenerative-energy absorption rate
ax2.barh(y, rates, height=.14, color='#E7EDF0', zorder=2)
ax2.scatter(rates, y, s=95, color=blue, edgecolor='white', linewidth=1, zorder=4)
for yy, rr in zip(y, rates):
    ax2.text(rr + 1.8, yy, f'{rr:.4f}%', color='#075B80',
             va='center', fontweight='bold', fontsize=10)

ax2.invert_yaxis()
ax2.set_yticks(y, runs)
ax2.set_xlim(0, 112)
ax2.set_xticks(np.arange(0, 101, 20))

for ax in (ax1, ax2):
    ax.xaxis.grid(True, color=grid, linewidth=.85)
    ax.set_axisbelow(True)
    for sp in ['left', 'right', 'top']:
        ax.spines[sp].set_visible(False)
    ax.spines['bottom'].set_color('#444')
    ax.tick_params(axis='y', length=0, colors='#455671')
    ax.tick_params(axis='x', colors='#455671')

# Bottom configurations, shared legend, and panel labels
ax1.text(0, -.13, 'S1: 1B/1T/1ESS    S2: 2B/2T/5ESS    S3: 3B/3T/10ESS',
         transform=ax1.transAxes, ha='left', va='top',
         color='#405777', fontsize=9)

ax1.legend(
    handles=[
        Patch(color=blue, label='Absorbed'),
        Patch(color=orange, label='Discarded'),
        Patch(color=green, label='Network loss')
    ],
    loc='upper left', bbox_to_anchor=(0, -.21),
    frameon=False, ncol=3, fontsize=10,
    columnspacing=1.5, handlelength=1.6, borderaxespad=0
)

ax1.text(.5, -.35, '(a) Reported energy metric (kWh)',
         transform=ax1.transAxes, ha='center', va='top', fontsize=11)
ax2.text(.5, -.35, '(b) Absorption rate (%)',
         transform=ax2.transAxes, ha='center', va='top', fontsize=11)

output_dir = Path(__file__).resolve().parent
for ext in ('png', 'svg', 'pdf'):
    out = output_dir / f'Fig5_label_above.{ext}'
    fig.savefig(out, dpi=450, facecolor='white',
                bbox_inches='tight', pad_inches=.18)

plt.close(fig)
print('Saved PNG, SVG, PDF and source code.')