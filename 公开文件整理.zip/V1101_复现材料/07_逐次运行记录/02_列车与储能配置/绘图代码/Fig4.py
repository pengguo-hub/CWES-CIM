import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# Data from 消融.xlsx (Sheet1): only values updated, all design retained
train_N = np.array([3, 5, 7])
train_rates = np.array([41.8157, 68.0959, 73.2516])
ess_N = np.array([7, 11, 16])
ess_rates = np.array([73.2516, 84.7318, 88.4299])

plt.rcParams.update({
    'font.family': 'DejaVu Serif',
    'font.size': 11,
    'axes.labelsize': 12,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
})
blue = '#176C9F'
orange = '#EF7900'
fig, ax = plt.subplots(figsize=(9.05, 5.4))
fig.subplots_adjust(left=.10, right=.985, top=.95, bottom=.16)

# Keep exactly the same visual encoding as the original figure
ax.plot(train_N, train_rates, color=blue, lw=1.9, marker='o',
        markersize=6, label='Varying train counts (1 ESS)', zorder=3)
ax.plot(ess_N, ess_rates, color='#3286B5', lw=1.9, ls=(0, (4, 3)),
        marker='s', markersize=6, label='Varying ESS count (3B/3T)', zorder=3)
ax.scatter([7], [train_rates[-1]], s=105, marker='D', facecolor=blue,
           edgecolor=orange, linewidth=2, label='Shared configuration (T3/E1)', zorder=5)

ax.set_xlim(2.1, 17.2)
ax.set_ylim(40, 90)
ax.set_xticks([3, 5, 7, 11, 16])
ax.set_yticks([40, 50, 60, 70, 80, 90])
ax.set_xlabel(r'Total number of nodes, $N$')
ax.set_ylabel('Regenerative energy absorption (%)')
ax.yaxis.grid(True, ls=(0, (2.5, 3)), lw=.8, color='#D8D8D8')
ax.set_axisbelow(True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_color('#444444')
ax.spines['bottom'].set_color('#444444')
ax.tick_params(colors='#222222')
ax.legend(loc='upper left', frameon=False, fontsize=10.5, handlelength=2.7)

# Original labels and placement, with numbers updated from Excel
for x, rate, dx, dy in [
    (3, train_rates[0], 1.50, 3.15),
    (5, train_rates[1], -.55, 2.15),
    (7, train_rates[2], -.56, 2.25),
    (11, ess_rates[1], -.55, 2.15),
    (16, ess_rates[2], -.60, .25),
]:
    ax.text(x + dx, rate + dy, f'{rate:.2f}%', fontsize=11,
            ha='center', va='bottom', color='#333333')

ax.text(3.45, 42.4, 'T1: 1B/1T/1 ESS', fontsize=10.5, color='#444444')
ax.text(5.55, 64.5, 'T2: 2B/2T/1 ESS', fontsize=10.5, color='#444444')
ax.text(7.20, 58.1+10.0, 'T3/E1: 3B/3T/1 ESS', fontsize=10.5, color='#444444')
ax.text(11.25, 81.0, 'E2: 3B/3T/5 ESS', fontsize=10.5, color='#444444')
ax.text(15.6, 85.1, 'E3: 3B/3T/10 ESS', fontsize=10.5, color='#444444', ha='center')

outdir = Path(__file__).resolve().parent
for fmt in ('png', 'svg', 'pdf'):
    fig.savefig(outdir / f'Fig4_ablation_E3_below.{fmt}', dpi=450,
                facecolor='white', bbox_inches='tight', pad_inches=.15)
plt.close(fig)
print('Saved Fig4_ablation_E3_below.png/.svg/.pdf')
