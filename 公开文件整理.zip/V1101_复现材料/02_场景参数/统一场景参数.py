"""Authoritative configuration for the benchmark and controlled experiments."""

import os

def _positive_int(name, default):
    value = int(os.environ.get(name, str(default)))
    if value <= 0:
        raise ValueError(f"{name} must be positive, got {value}")
    return value


def _ess_positions(count):
    configured = os.environ.get("BENCHMARK_ESS_POSITIONS")
    if configured:
        positions = [float(value) for value in configured.split(",")]
        if len(positions) != count:
            raise ValueError(
                "BENCHMARK_ESS_POSITIONS must contain exactly "
                f"{count} comma-separated values"
            )
        return positions
    if count == 1:
        return [15.5]
    return [1.0 + 29.0 * index / (count - 1) for index in range(count)]


NUM_BRAKE = _positive_int("BENCHMARK_NUM_BRAKE", 3)
NUM_TRACTION = _positive_int("BENCHMARK_NUM_TRACTION", 3)
NUM_ESS = _positive_int("BENCHMARK_NUM_ESS", 10)

DT = float(os.environ.get("BENCHMARK_DT", "1.0"))
SIM_TIME = _positive_int("BENCHMARK_SIM_TIME", 150)
TIME_STEPS = int(SIM_TIME / DT)

# =========================
# Benchmark case configuration
# =========================

CASE_FILES = {
    "Case1": "Case1_150s_traction_dominant_10ESS.xlsx",
    "Case2": "Case2_150s_regeneration_dominant_10ESS.xlsx",
    "Case3": "Case3_150s_balanced_10ESS.xlsx",
    "Case4": "Case4_150s_dynamic_mixed_10ESS.xlsx",
}

RESULT_ROOT = os.environ.get("BENCHMARK_RESULT_ROOT", "results")

ESS_POSITIONS = _ess_positions(NUM_ESS)
ESS_CAPACITY_KWH = 1000.0
P_CH_MAX_KW = 500.0
P_DIS_MAX_KW = 500.0

SOC_INIT = 0.50
SOC_MIN = 0.20
SOC_MAX = 0.90
ETA_CH = 0.95
ETA_DIS = 0.95

DC_VOLTAGE = 1500.0
DC_VOLTAGE_MIN = 1200.0
LINE_RESISTANCE = float(
    os.environ.get("BENCHMARK_LINE_RESISTANCE_OHM_PER_KM", "0.134")
)
if LINE_RESISTANCE <= 0.0:
    raise ValueError(
        "BENCHMARK_LINE_RESISTANCE_OHM_PER_KM must be positive"
    )
P_SUB_MAX_KW = 35610.0

MILP_OBJECTIVE_WEIGHTS = {
    "charge": 2.0,
    "discharge": 0.5,
    "waste": 3.0,
    "grid": 1.0,
    "distance": 0.01,
}

# Genetic-algorithm hyperparameters. The GA imports the same physical and
# evaluation configuration above; only search-control parameters are specific
# to the optimizer. A fixed seed makes the benchmark run reproducible.
GA_RANDOM_SEED = 20260722
GA_POPULATION_SIZE = 36
GA_GENERATIONS = 45
GA_ELITE_SIZE = 4
GA_TOURNAMENT_SIZE = 3
GA_CROSSOVER_RATE = 0.85
GA_MUTATION_RATE = 0.15
GA_MUTATION_SIGMA = 0.18
GA_STAGNATION_GENERATIONS = 12
GA_LOSS_WEIGHT = 1.0
GA_SOC_BALANCE_WEIGHT = 0.05

RESULT_COLUMNS = [
    "time_s", "brake_power_kW", "traction_power_kW", "p_direct_kW",
    "ess_charge_kW", "ess_discharge_kW", "grid_power_kW",
    "wasted_power_kW", "loss_kW", "soc_average", "solve_time_ms",
    "voltage_violation", "power_violation", "feasible",
]

SUMMARY_METRICS = [
    "方法名称", "总再生能量", "有效消纳能量", "再生消纳率",
    "弃能", "电网补能", "网损", "初始SOC", "最终平均SOC",
    "最大SOC", "最小SOC", "总求解时间", "平均单步时间",
    "最大单步时间", "电压越限次数", "功率越限次数", "不可行步数",
]
