"""Quantum/QUBO settings layered on the shared 10ESS benchmark config.

Physical-system, case, ESS, SOC, and evaluation parameters belong in
``benchmark_config.py``. This module contains only settings that are specific
to the quantum/CIM execution path used by this benchmark copy.
"""

import os

# This benchmark copy is intentionally locked to the remote Kaiwu/CIM path.
# An environment variable cannot silently replace it with classic k-flip.
USE_QUANTUM_INTERFACE = True

# CIM remains the default. Local SCIP is allowed only by the dedicated
# sensitivity experiment runner, which sets an explicit opt-in flag.
QUANTUM_SOLVER_BACKEND = os.environ.get(
    "ESS_QUANTUM_SOLVER_BACKEND", "cim"
).strip().lower()
if QUANTUM_SOLVER_BACKEND not in {"cim", "scip"}:
    raise ValueError("ESS_QUANTUM_SOLVER_BACKEND must be 'cim' or 'scip'")
if (
    QUANTUM_SOLVER_BACKEND == "scip"
    and os.environ.get("ESS_ALLOW_LOCAL_QUBO_EXPERIMENT") != "1"
):
    raise ValueError(
        "Local SCIP is reserved for controlled sensitivity experiments; "
        "set ESS_ALLOW_LOCAL_QUBO_EXPERIMENT=1 explicitly"
    )

# Constraint-penalty coefficients exposed for the cross-parameter experiment.
QUBO_BALANCE_WEIGHT = float(
    os.environ.get("ESS_QUBO_BALANCE_WEIGHT", "0.001")
)
QUBO_SUBSTATION_WEIGHT = float(
    os.environ.get("ESS_QUBO_SUBSTATION_WEIGHT", "0.000001")
)
QUBO_SOC_DYNAMIC_WEIGHT = float(
    os.environ.get("ESS_QUBO_SOC_DYNAMIC_WEIGHT", "20.0")
)
QUBO_SOC_BOUNDARY_WEIGHT = float(
    os.environ.get("ESS_QUBO_SOC_BOUNDARY_WEIGHT", "5.0")
)
QUBO_WASTE_WEIGHT = float(
    os.environ.get("ESS_QUBO_WASTE_WEIGHT", "0.0005")
)
QUBO_SWITCH_WEIGHT = float(
    os.environ.get("ESS_QUBO_SWITCH_WEIGHT", "0.0001")
)

# Physical-decoder loss weight used after a real quantum partition is returned.
# The original quantum decoding value is retained by default.
DISPATCH_LOSS_WEIGHT = float(
    os.environ.get("ESS_DISPATCH_LOSS_WEIGHT", "7.5")
)
if DISPATCH_LOSS_WEIGHT < 0.0:
    raise ValueError("ESS_DISPATCH_LOSS_WEIGHT must be non-negative")

# QUBO objective calibration. Loss is an I^2R distance surrogate, while the
# grid term and explicit discharge reward distinguish solutions with the same
# regenerative-energy capture but different grid demand.
QUBO_LOSS_WEIGHT = float(os.environ.get("ESS_QUBO_LOSS_WEIGHT", "12.0"))
QUBO_GRID_WEIGHT = float(os.environ.get("ESS_QUBO_GRID_WEIGHT", "0.0015"))
QUBO_DISCHARGE_REWARD_WEIGHT = float(
    os.environ.get("ESS_QUBO_DISCHARGE_REWARD_WEIGHT", "0.20")
)
for _name, _value in {
    "ESS_QUBO_BALANCE_WEIGHT": QUBO_BALANCE_WEIGHT,
    "ESS_QUBO_SUBSTATION_WEIGHT": QUBO_SUBSTATION_WEIGHT,
    "ESS_QUBO_SOC_DYNAMIC_WEIGHT": QUBO_SOC_DYNAMIC_WEIGHT,
    "ESS_QUBO_SOC_BOUNDARY_WEIGHT": QUBO_SOC_BOUNDARY_WEIGHT,
    "ESS_QUBO_WASTE_WEIGHT": QUBO_WASTE_WEIGHT,
    "ESS_QUBO_SWITCH_WEIGHT": QUBO_SWITCH_WEIGHT,
    "ESS_QUBO_LOSS_WEIGHT": QUBO_LOSS_WEIGHT,
    "ESS_QUBO_GRID_WEIGHT": QUBO_GRID_WEIGHT,
    "ESS_QUBO_DISCHARGE_REWARD_WEIGHT": QUBO_DISCHARGE_REWARD_WEIGHT,
}.items():
    if _value < 0.0:
        raise ValueError(f"{_name} must be non-negative")

# The continuous physical decoder preserves the binary QUBO preference as a
# deterministic multi-start bias, then minimizes loss and grid supply under
# the shared benchmark constraints.
DISPATCH_QUBO_PRIORITY_BOOST = float(
    os.environ.get("ESS_DISPATCH_QUBO_PRIORITY_BOOST", "0.05")
)
DISPATCH_RANDOM_STARTS = int(
    os.environ.get("ESS_DISPATCH_RANDOM_STARTS", "3")
)
DISPATCH_RANDOM_SEED = int(
    os.environ.get("ESS_DISPATCH_RANDOM_SEED", "20260803")
)
if DISPATCH_QUBO_PRIORITY_BOOST < 0.0:
    raise ValueError("ESS_DISPATCH_QUBO_PRIORITY_BOOST must be non-negative")
if DISPATCH_RANDOM_STARTS < 0:
    raise ValueError("ESS_DISPATCH_RANDOM_STARTS must be non-negative")

# One binary ESS-mode variable per ESS and per step in the batch horizon.
# Every 150-step case therefore makes exactly 15 quantum submissions.
BATCH_SIZE = int(os.environ.get("ESS_QUBO_BATCH_SIZE", "10"))
if BATCH_SIZE <= 0:
    raise ValueError("ESS_QUBO_BATCH_SIZE must be positive")


# Numerical feasibility tolerance used by the quantum result decoder.
BALANCE_TOLERANCE_KW = 1e-5

# The shared classical runtime defines only a minimum DC voltage. ``None``
# disables an additional quantum-only upper-voltage feasibility constraint.
VOLTAGE_MAX_V = None

# Default key from Benchmark_V1_30s/config/benchmark_config.py.
DEFAULT_CASE_KEY = "Case1"

# Quantum decoder line-current limit (kA).
I_MAX_KA = 1.424
